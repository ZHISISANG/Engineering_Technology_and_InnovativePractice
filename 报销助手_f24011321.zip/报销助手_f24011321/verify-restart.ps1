# =====================================================================
# 报销助手_f24011321 重启持久化检查
#
# 回答一个问题：重启 Tomcat 之后，之前登记的数据还在不在？
# 做法：记录当前状态 -> 停止 Tomcat -> 启动 Tomcat -> 再查一次 -> 比对。
#
# 用法（在普通 PowerShell 窗口执行，不要在受限沙箱里跑）：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-restart.ps1 `
#       -BaseUrl http://localhost:8080/reimburse-jdbc
#
# 用 -BaseDir 可以检查独立 CATALINA_BASE 实例（与 run.ps1 的用法一致）。
# 退出码：0 = 数据保留，1 = 数据异常或写入失败。
# =====================================================================
param(
    [string]$BaseUrl = "http://localhost:8080/reimburse",
    [string]$TomcatHome = "D:\apache-tomcat-11.0.26",
    [string]$BaseDir = "",
    [string]$JavaHome = "",
    [string]$User = "suny",
    [string]$Password = "123456"
)

$ErrorActionPreference = "Stop"
$TomcatHome = $TomcatHome.TrimEnd('\')
if ($BaseDir) { $BaseDir = $BaseDir.TrimEnd('\') }

# 端口从 BaseUrl 里取，避免与实际监听端口不一致
$port = 8080
$m = [regex]::Match($BaseUrl, ':(\d+)')
if ($m.Success) { $port = [int]$m.Groups[1].Value }

if (-not $JavaHome) {
    $cands = Get-ChildItem 'C:\Program Files\Java' -Directory -Filter 'jdk*' -ErrorAction SilentlyContinue |
             Where-Object { Test-Path (Join-Path $_.FullName 'bin\java.exe') } | Sort-Object Name -Descending
    if (-not $cands) { throw "未找到 JDK，请用 -JavaHome 指定" }
    $JavaHome = $cands[0].FullName
}

$env:CATALINA_HOME = $TomcatHome
$env:JAVA_HOME = $JavaHome.TrimEnd('\')
$env:JRE_HOME = $env:JAVA_HOME
$env:CATALINA_BASE = if ($BaseDir) { $BaseDir } else { $TomcatHome }

function Invoke-Login {
    $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
    try {
        $r = Invoke-WebRequest -Uri ($BaseUrl + '/login') -Method Post -WebSession $session -UseBasicParsing `
            -Body ("username={0}&password={1}" -f $User, $Password) -TimeoutSec 30
        return [pscustomobject]@{ Session = $session; Status = [int]$r.StatusCode; Content = [string]$r.Content }
    } catch {
        $resp = $_.Exception.Response
        if ($resp -ne $null) {
            $text = ""
            try {
                $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                $text = $reader.ReadToEnd()
            } catch { }
            return [pscustomobject]@{ Session = $session; Status = [int]$resp.StatusCode; Content = $text }
        }
        return [pscustomobject]@{ Session = $session; Status = -1; Content = $_.Exception.Message }
    }
}

# 取"可观测状态"：本人单据数 + 当前生效的差旅费制度版本
function Get-State {
    $login = Invoke-Login
    if ($login.Status -ne 200 -or $login.Content.Contains('系统错误')) {
        return [pscustomobject]@{ Ok = $false; Docs = -1; Version = ""; Login = $login }
    }
    $my = Invoke-WebRequest -Uri ($BaseUrl + '/mydoc/list') -WebSession $login.Session -UseBasicParsing -TimeoutSec 30
    $docs = ([regex]::Matches([string]$my.Content, 'mydoc/detail\?id=')).Count
    $pl = Invoke-WebRequest -Uri ($BaseUrl + '/policy/list') -WebSession $login.Session -UseBasicParsing -TimeoutSec 30
    $version = ""
    foreach ($seg in ([string]$pl.Content -split '<tr')) {
        if ($seg.Contains('CS-2024-01')) {
            $version = [regex]::Match($seg, '>V(\d+)<').Groups[1].Value
            break
        }
    }
    return [pscustomobject]@{ Ok = $true; Docs = $docs; Version = $version; Login = $login }
}

function Wait-Port {
    param([int]$Port, [bool]$Up, [int]$Seconds = 40)
    for ($i = 0; $i -lt $Seconds; $i++) {
        Start-Sleep -Seconds 1
        $listening = $null -ne (Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
        if ($listening -eq $Up) { return $true }
    }
    return $false
}

Write-Host ""
Write-Host "========== 重启持久化检查 =========="
Write-Host ("地址：{0}" -f $BaseUrl)

Write-Host "`n[1/4] 记录重启前状态"
$before = Get-State
if (-not $before.Ok) {
    Write-Host ("  登录/查询失败（status={0}）。请确认应用已启动、账号口令正确。" -f $before.Login.Status)
    exit 1
}
Write-Host ("  本人单据 {0} 张，差旅费制度 V{1}" -f $before.Docs, $before.Version)

Write-Host "`n[2/4] 停止 Tomcat"
if (Test-Path (Join-Path $TomcatHome 'bin\shutdown.bat')) {
    & cmd.exe /c "`"$TomcatHome\bin\shutdown.bat`"" | Out-Null
} else {
    Write-Host "  找不到 shutdown.bat，跳过停止步骤"
}
if (-not (Wait-Port -Port $port -Up $false)) {
    Write-Host ("  警告：{0} 端口仍在监听，可能不是由本脚本管理的实例；继续启动步骤可能失败。" -f $port)
} else {
    Write-Host "  已停止"
}

Write-Host "`n[3/4] 启动 Tomcat"
if (Test-Path (Join-Path $TomcatHome 'bin\startup.bat')) {
    & cmd.exe /c "`"$TomcatHome\bin\startup.bat`"" | Out-Null
} else {
    Write-Host "  找不到 startup.bat，请手工启动后重新运行本脚本"
    exit 1
}
if (-not (Wait-Port -Port $port -Up $true)) {
    Write-Host ("  {0} 秒内未监听到 {1} 端口，请查看日志目录下的 catalina.*.log" -f 40, $port)
    exit 1
}
Write-Host "  已启动"

Write-Host "`n[4/4] 复查状态"
$after = Get-State
if (-not $after.Ok) {
    Write-Host ("  重启后登录/查询失败（status={0}）。" -f $after.Login.Status)
    if ($after.Login.Content.Contains('系统错误')) {
        Write-Host "  响应是 500 错误页，且登录本身需要写一条审计记录——"
        Write-Host "  这通常意味着数据库被以只读方式打开（日志里会有 JdbcStore 的只读告警），"
        Write-Host "  而不是数据丢失。请查看 logs 目录下的日志确认。"
    }
    exit 1
}
Write-Host ("  本人单据 {0} 张，差旅费制度 V{1}" -f $after.Docs, $after.Version)

Write-Host ""
Write-Host "======================================================"
$ok = ($after.Docs -eq $before.Docs) -and ($after.Version -eq $before.Version)
if ($ok) {
    Write-Host ("结论：数据已保留（单据 {0} 张，制度 V{1} 未回退到初始状态）。" -f $after.Docs, $after.Version)
    exit 0
}
Write-Host ("结论：状态不一致——重启前 单据 {0} 张 / V{1}，重启后 单据 {2} 张 / V{3}。" -f `
    $before.Docs, $before.Version, $after.Docs, $after.Version)
Write-Host "若重启后数量回到初始值（单据 4 张、V2），说明数据没有被持久化而是重新初始化了。"
exit 1
