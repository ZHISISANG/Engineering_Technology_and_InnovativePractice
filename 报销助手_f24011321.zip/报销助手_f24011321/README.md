# 报销助手_f24011321

员工自助查询**有效制度**、经授权查询**本人单据状态**的 Web 应用。制度由制度专员维护，业务事实由业务员维护，
两类数据分属不同职责、由不同角色写入，员工只读。

技术栈：JSP + Jakarta Servlet 6.0 + Tomcat 11，纯 JDK 构建（javac / jar），不依赖 Maven 与任何第三方 Web 框架。
存储提供**两份实现**：文件持久化版（JSON 文本）与数据库版（H2 嵌入式，真 JDBC + SQL 建表），同一套代码用配置切换。

---

## 一、需求与实现对应

| 需求 | 实现位置 | 说明 |
| --- | --- | --- |
| 员工自助查询有效制度 | `PolicyServlet` + `PolicyService.listEffective` | 只返回"状态=生效 且 今天落在有效期内"的制度 |
| 扩展为经授权查询本人单据状态 | `MyDocServlet` + `DocumentService.findOwn` | 服务端逐次比对单据归属与登录账号，不一致即拒并留痕 |
| 制度由专员维护 | `PolicyAdminServlet`（`/specialist/*`） | 新增、修订、发布、废止，全部写审计 |
| 业务事实由业务员维护 | `DocAdminServlet`（`/clerk/*`） | 登记单据、修正金额事由、推进状态、驳回 |

"有效制度"是算出来的，不是存出来的。同一条制度编码下允许存在多个版本，员工只能查到当前生效的那一版：

- 草稿（DRAFT）、未到生效日期、已过有效期、已废止（REPEALED）四种情形，员工一律查不到；
- 发布新版本时，同编码其它生效版本自动转为废止，避免员工搜出两条口径冲突的制度。

## 二、角色与权限

| 功能 | 员工 | 制度专员 | 业务员 | 系统管理员 |
| --- | :---: | :---: | :---: | :---: |
| 查询有效制度 | ✓ | ✓ | ✓ | ✓ |
| 查询本人单据状态 | ✓ | ✓ | ✓ | ✓ |
| 维护制度（增/修/发/废） | ✗ | ✓ | ✗ | ✗ |
| 维护业务事实（登记/改事实/推进状态） | ✗ | ✗ | ✓ | ✓ 无 |
| 账号管理与审计日志 | ✗ | ✗ | ✗ | ✓ |

职责分离是强制的：管理员也进不了制度维护与单据维护，被拦下的请求记一条"结果=拒绝"的审计。
拦截点有两处——`RoleFilter` 管模块级入口，服务层管数据级归属（`DocumentService.findOwn`），
所以直接改 URL 里的 `id` 也拿不到别人的单据。

## 三、关键设计

**制度域与业务事实域分离。** `rmb_policy` 只由专员写，`rmb_document` 只由业务员写。单据上有一个
`policy_code` 字段记录登记时依据的制度编码，用于事后追溯"这张单子按哪版制度办的"；制度改版不会回头改写已登记的单据。
当某费用类型当时没有生效制度时，该字段为空——这是正常状态，页面上会说明。

**制度的版本链与唯一生效版本。** 修订不会覆盖旧版本，而是在同编码下生成 `version + 1` 的草稿，旧版本内容原样保留；
发布时把同编码其它生效版本置为废止。演示数据里 `CS-2024-01` 就有完整的 V1→V2→V3 链条。

**授权的服务端判定。** 员工单据列表按 `owner_id` 过滤；详情页再判一次归属，不匹配抛 `AccessDeniedException`，
由 Servlet 转 403 并写 `DENIED` 审计。前端的隐藏菜单只是顺手，真正的拦截在服务层。

**审计兼作状态变更历史。** 状态推进写的审计记录（动作、时间、经办人、说明）按单据汇总，就是详情页上的"办理轨迹"，
不必再单独维护一张 history 表。

**存储抽象。** `Store` 接口 + 四个仓储接口，`FileStore` 与 `JdbcStore` 各实现一遍，
`StoreFactory` 按 `WEB-INF/config/app.properties` 里的 `storage=file|jdbc` 选择。Service、Servlet、JSP 完全共用。

## 四、目录结构

```
报销助手_f24011321
├── build.ps1                     编译 + 打包两个变体 + 部署
├── run.ps1                       构建后启动 Tomcat 并打开登录页
├── verify.ps1                    验收脚本：76 项 HTTP 断言
├── verify-restart.ps1            重启持久化检查（见第八节）
├── lib/h2-2.2.220.jar            数据库版驱动（H2，MPL 2.0）
├── docs/verify-file.log          文件版验收实测输出
├── docs/verify-jdbc.log          数据库版验收实测输出
└── src/main
    ├── java/com/reimburse
    │   ├── model/        Role、PolicyStatus、DocStatus、ExpenseType、AuditAction/Result、User、Policy、Document、AuditLog
    │   ├── util/         PasswordUtil（PBKDF2-SHA256）、Json（自研极简 JSON 读写）、Dates、Esc
    │   ├── store/        Store 接口族、AppConfig、StoreFactory、SeedData
    │   │   ├── file/     JsonTable + FileStore
    │   │   └── jdbc/     Jdbc + JdbcStore
    │   ├── service/      AuthService、PolicyService、DocumentService、UserService、AuditService
    │   └── web/          AppBootstrap、Web、7 个 Servlet、3 个 Filter
    └── webapp
        ├── css/style.css
        ├── index.jsp
        └── WEB-INF
            ├── web.xml                    过滤器链、Servlet 映射、错误页
            ├── config/app.properties      运行配置（build.ps1 按变体重写）
            ├── sql/schema-h2.sql          H2 建表脚本（运行时执行）
            ├── sql/schema-mysql.sql       等价 MySQL 8 脚本（换库参考，未实机验证）
            └── views/                     所有视图，浏览器无法直接访问，只能由 Servlet 转发
                ├── common/head.jsp footer.jsp
                ├── employee/  policy_list policy_detail my_docs doc_detail
                ├── specialist/ policy_manage policy_edit
                ├── clerk/     doc_manage doc_edit
                ├── admin/     user_manage user_edit audit_log
                ├── login.jsp profile.jsp home.jsp
                └── error/     403 404 500
```

规模：Java 47 个文件 4198 行，JSP 20 个文件 1254 行，CSS 145 行。

## 五、运行环境与启动

需要 JDK 17 以上（本机用 JDK 25 验证）与 Tomcat 11（Jakarta Servlet 6.0，本机用 11.0.26）。
默认从 `D:\apache-tomcat-11.0.26` 读取 `lib\servlet-api.jar`，路径不同时用 `-TomcatHome` 指定。

```powershell
# 若提示"在此系统上禁止运行脚本"，用 Bypass 方式调用
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1
```

脚本会编译一次、打包并部署两个应用，然后启动 Tomcat：

| 变体 | 上下文路径 | 数据位置 |
| --- | --- | --- |
| 文件持久化版 | `http://localhost:8080/reimburse/login` | `<TomcatHome>\reimburse-data\file\*.json` |
| 数据库版（H2） | `http://localhost:8080/reimburse-jdbc/login` | `<TomcatHome>\reimburse-data\jdbc\reimburse.mv.db` |

只打包不部署：`.\build.ps1 -SkipDeploy`，产物在 `target\*.war`。只构建文件版：`-SkipJdbc`。

**用独立实例运行（不影响已有应用）。** 利用 Tomcat 的 `CATALINA_BASE`，可以另起一个只属于本项目的实例：

```powershell
# 先准备一份 conf（只需一次），再指定端口
mkdir build\mybase\conf | Out-Null
copy D:\apache-tomcat-11.0.26\conf\* build\mybase\conf -Recurse
# 改 server.xml 中的 Connector 端口，然后：
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1 -BaseDir .\build\mybase
```

数据目录刻意放在 `webapps` 之外：重新部署会清空 `webapps` 下的目录，放里面重启就丢数据。
`app.properties` 里的 Windows 路径要写正斜杠（反斜杠在 properties 文件里是转义符）。

## 六、测试账号

首次启动自动初始化演示数据（口令一律为 `123456`）。**这是演示数据，口令强度不符合真实要求，生产必须改掉。**

| 账号 | 姓名 | 角色 | 部门 | 可做的事 |
| --- | --- | --- | --- | --- |
| `suny` | 孙悦 | 员工 | 市场部 | 查有效制度、查本人 4 张单据 |
| `zhouw` | 周伟 | 员工 | 研发部 | 同上，另有 1 张已支付单据可用于越权测试 |
| `xuj` | 徐佳 | 员工 | 综合办公室 | 同上 |
| `zhangq` | 张倩 | 制度专员 | 财务部 | 维护制度（含版本链、发布、废止） |
| `wangm` | 王明 | 业务员 | 财务部 | 登记单据、改事实、推进状态 |
| `zhaol` | 赵磊 | 业务员 | 财务部 | 同上 |
| `admin` | 系统管理员 | 管理员 | 信息技术部 | 账号管理、审计日志查询 |

演示数据以"今天"为基准生成相对日期，因此任何时间启动都能同时看到五种制度状态：
当前有效 3 条、已过有效期、尚未生效、草稿、已废止各 1 条。单据 10 张覆盖已提交/审核中/审核通过/已驳回/已支付。

## 七、验收

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1 `
    -BaseUrl http://localhost:8080/reimburse -Name "文件持久化版"
```

脚本用真实 HTTP 请求逐条断言，覆盖九个方面：未登录拦截、员工查有效制度（含草稿/未生效/已废止的**反向**验证）、
越权查他人单据被拒 403、职责分离、业务员登记事实、状态机与终态冻结、制度版本与生效控制、
审计留痕、每个视图至少渲染一次（兼作 JSP 编译检查）。退出码 0 表示全部通过。

实测结果（本机 Tomcat 11.0.26 + JDK 25，两个变体各自独立数据）：

| 变体 | 结果 | 原始输出 |
| --- | --- | --- |
| 文件持久化版 | 通过 76 项，失败 0 项 | `docs/verify-file.log` |
| 数据库版（H2） | 通过 76 项，失败 0 项 | `docs/verify-jdbc.log` |

注意 `verify.ps1` 会**改动数据**（新增一张单据、新增并发布一个制度版本），它是验收脚本不是只读探针，
请对验证实例执行。

数据库版另用 SQL 复核过数据平面（把库文件复制出来用 `org.h2.tools.Shell` 查询，因为嵌入式库同一时刻只允许一个 JVM 打开）：

```
账号 7 / 制度版本 8 / 单据 11 / 审计 33
CS-2024-01:  V1 REPEALED (2024-10-09 ~ 2026-09-09)
             V2 REPEALED (2026-09-10 ~ 长期)
             V3 ACTIVE   (2026-10-09 ~ 长期)      <- 验收脚本修订并发布的结果
审计结果: ALLOW 23 / DENY 10（其中越权被拒 9 条、登录失败 1 条）
```

## 八、已在沙箱内验证不了的一点

**数据库版"写入跨重启保留"这一条，本机沙箱环境下无法验证，不是代码问题。**现象与定位过程：

1. 全新创建 H2 库、同一进程内读写一切正常；关掉 Tomcat 再启动，打开同一个库文件后写入报
   `The database is read only`，登录时写审计即失败。
2. 用两个最小 JVM 进程复现：第一个进程建库并插入成功，第二个进程打开同一文件必被置只读。
   与 `DB_CLOSE_DELAY`、`DB_CLOSE_ON_EXIT`、`FILE_LOCK`、`ACCESS_MODE_DATA=rw` 均无关，
   `AUTO_SERVER=TRUE` 的报错直接印证 H2 内部把该库标记为 `readOnly`。
3. 真正的原因在环境：本机沙箱下 `java.nio.file.Files.isWritable()` 对任何文件都返回 `false`
   （`File.canWrite()` 为 `true`，实际 `RandomAccessFile` 追加写入成功），而 H2 判断"已有库文件能否写入"
   用的正是这个 NIO 判定。所以只要库文件不是本次进程创建的，H2 就会按只读打开。
   工作区与系统临时目录表现一致，因此不是工作区权限项缺失；按 `diagnose-windows-sandbox-acl` 修复权限后现象不变。

结论：**在不受沙箱限制的普通会话里，`Files.isWritable` 会返回 `true`，数据库版应能正常跨重启写入**，
但这一点我没有在本机证实，不当作已验证结论。要确认请在普通 PowerShell 窗口执行：

```powershell
# 1) 启动（数据库版），登记或推进一张单据，然后
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-restart.ps1 -BaseUrl http://localhost:8080/reimburse-jdbc
```

`verify-restart.ps1` 会记录当前单据数、停止 Tomcat、再启动、复查数量与制度版本，输出 PASS/FAIL。
在受限会话里它会明确报告"写入被环境置为只读"而不会误判成代码缺陷。

顺带说明：`JdbcStore` 启动时会检查连接是否只读，只读则打印一条明确的告警（在 `logs\catalina.*.log` 里，
logger 名为 `com.reimburse.store.jdbc.JdbcStore`），写失败时也会附上排查方向，
避免以后遇到同类问题时只看到一个没有线索的 500。

## 九、其它已知限制

- **状态变更历史**取自审计表，粒度到"某次操作"，没有独立的单据状态流水表；如需严格的审批链审计需再加一张表。
- **表单没有 CSRF 令牌**。所有写操作都是 POST，但未加防跨站请求伪造令牌；会话 Cookie 也未设 `SameSite`/`Secure`。
  对外部署前必须补上。
- **口令策略简化**：只校验长度下限 6 位，没有复杂度、失败锁定与过期策略。
- **登录不做限速**，失败仅记审计。
- **H2 数据库账号**默认 `sa` 且空口令，仅适合本机演示；对外部署应改为独立账号并设口令。
- **并发**：文件版的整表重写与数据库版的单连接串行都在方法级加锁，适合几十条数据与少量用户；
  高并发场景需要换成连接池并重新设计文件版。
- `sql/schema-mysql.sql` 只是结构对照，**未在 MySQL 上实机验证**；换库需要替换驱动 jar 并配置 `jdbc.url`。

## 十、构建产物清理

`build\`（classes、stage、verify 下的验证实例与数据）与 `target\`（war）都是生成物，可随时删除，
删除后重新执行 `run.ps1` 会重新编译并初始化数据。
