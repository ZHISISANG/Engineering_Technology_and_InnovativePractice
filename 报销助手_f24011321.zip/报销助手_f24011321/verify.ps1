# =====================================================================
# 报销助手_f24011321 验收脚本
#
# 用真实 HTTP 请求走一遍需求与权限边界，不依赖页面上的隐藏逻辑：
#   1) 员工自助查询有效制度（含"草稿/未生效/已废止查不到"的反向验证）
#   2) 经授权查询本人单据状态（含"改 id 查他人单据被拒"的越权验证）
#   3) 制度由专员维护、业务事实由业务员维护（职责分离的越权验证）
#   4) 制度版本与生效控制、单据状态机与终态冻结
#   5) 审计留痕
#
# 用法（Tomcat 已启动的前提下）：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\verify.ps1 `
#       -BaseUrl http://127.0.0.1:8080/reimburse -Name "文件持久化版"
#
# 退出码：0 = 全部通过，1 = 存在失败项。
# 注意：脚本会新增一张单据、新增并发布一个制度版本，请对验证实例执行，
#       不要拿它当生产数据的回归脚本。
# =====================================================================
param(
    [string]$BaseUrl = "http://127.0.0.1:18080/reimburse",
    [string]$Name = "运行实例"
)

$script:Pass = 0
$script:Fail = 0
$script:Failed = @()

function Check {
    param([string]$Title, [bool]$Ok, [string]$Note = "")
    if ($Ok) {
        $script:Pass++
        Write-Host ("  [通过] {0}" -f $Title)
    } else {
        $script:Fail++
        $script:Failed += $Title
        $line = "  [失败] {0}" -f $Title
        if ($Note) { $line = $line + "   <- " + $Note }
        Write-Host $line
    }
}

function Http {
    param([string]$Method, [string]$Path, $Session, [string]$Body)
    $p = @{ Uri = ($BaseUrl + $Path); Method = $Method; UseBasicParsing = $true; TimeoutSec = 30 }
    if ($Session) { $p.WebSession = $Session }
    if ($Body) { $p.Body = $Body; $p.ContentType = 'application/x-www-form-urlencoded' }
    try {
        $r = Invoke-WebRequest @p
        $finalUri = ""
        try { $finalUri = [string]$r.BaseResponse.ResponseUri.AbsoluteUri } catch { }
        return [pscustomobject]@{ Status = [int]$r.StatusCode; Content = [string]$r.Content; Location = $finalUri }
    } catch {
        $resp = $_.Exception.Response
        if ($resp -ne $null) {
            $code = [int]$resp.StatusCode
            $text = ""
            try {
                $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                $text = $reader.ReadToEnd()
            } catch { }
            return [pscustomobject]@{ Status = $code; Content = $text; Location = "" }
        }
        return [pscustomobject]@{ Status = -1; Content = $_.Exception.Message; Location = "" }
    }
}

function New-Session {
    return New-Object Microsoft.PowerShell.Commands.WebRequestSession
}

function Login {
    param([string]$User, [string]$Password)
    $s = New-Session
    $r = Http -Method 'POST' -Path '/login' -Session $s -Body ("username={0}&password={1}" -f $User, $Password)
    return [pscustomobject]@{ Session = $s; Response = $r }
}

function Count-Of {
    param([string]$Text, [string]$Needle)
    return ([regex]::Matches($Text, [regex]::Escape($Needle))).Count
}

# 取出包含指定标记的那一行（页面里每行都是 <tr>...</tr>）
function Row-Of {
    param([string]$Text, [string]$Marker)
    foreach ($seg in ($Text -split '<tr')) {
        if ($seg.Contains($Marker)) { return $seg }
    }
    return ""
}

function Escape {
    param([string]$Text)
    return [uri]::EscapeDataString($Text)
}

Write-Host ""
Write-Host ("========== 验收：{0} ==========" -f $Name)
Write-Host ("地址：{0}" -f $BaseUrl)
$today = (Get-Date).ToString('yyyy-MM-dd')

# ---------------------------------------------------------------- 登录拦截
Write-Host ""
Write-Host "【一】未登录拦截"
$anon = New-Session
$r = Http -Method 'GET' -Path '/policy/list' -Session $anon
Check "未登录访问制度查询被送到登录页" ($r.Content.Contains('login-box') -and $r.Location -match '/login$') `
    ("final={0}" -f $r.Location)
$r = Http -Method 'GET' -Path '/mydoc/list' -Session $anon
Check "未登录访问我的单据被送到登录页" ($r.Content.Contains('login-box') -and $r.Location -match '/login$') `
    ("final={0}" -f $r.Location)
$r = Http -Method 'GET' -Path '/clerk/doc/list' -Session $anon
Check "未登录访问单据维护被送到登录页" ($r.Content.Contains('login-box') -and $r.Location -match '/login$') `
    ("final={0}" -f $r.Location)
$bad = Login 'suny' 'definitely-wrong'
Check "错误口令登录失败" ($bad.Response.Content.Contains('账号或口令不正确'))

# ---------------------------------------------------------------- 员工查询制度
Write-Host ""
Write-Host "【二】员工自助查询有效制度"
$sun = Login 'suny' '123456'
Check "员工 suny 登录成功" ($sun.Response.Status -eq 200 -and $sun.Response.Content.Contains('你好'))
$sunS = $sun.Session

$pl = Http -Method 'GET' -Path '/policy/list' -Session $sunS
Check "员工可打开制度查询页" ($pl.Status -eq 200) ("status={0}" -f $pl.Status)
Check "查询结果含当前生效的差旅费制度(CS-2024-01)" ($pl.Content.Contains('CS-2024-01'))
Check "查询结果含通用单据规范(BG-2025-05)" ($pl.Content.Contains('BG-2025-05'))
Check "未生效制度(ZD-2025-03)对员工不可见" (-not $pl.Content.Contains('ZD-2025-03'))
Check "草稿制度(PX-2025-04)对员工不可见" (-not $pl.Content.Contains('PX-2025-04'))
Check "已废止制度(JT-2023-06)对员工不可见" (-not $pl.Content.Contains('JT-2023-06'))
$effCount = Count-Of $pl.Content '/policy/detail?id='
Check "有效制度条数为 3" ($effCount -eq 3) ("实际 {0} 条" -f $effCount)

$spec = Login 'zhangq' '123456'
$sp = Http -Method 'GET' -Path '/specialist/policy/list' -Session $spec.Session
Check "专员可进入制度维护（用它取出未生效制度的 id）" ($sp.Status -eq 200)
$draftRow = Row-Of $sp.Content 'ZD-2025-03'
$draftId = [regex]::Match($draftRow, '/specialist/policy/edit\?id=(\d+)').Groups[1].Value
Check "取到未生效制度的 id" ($draftId -ne "")
$deny = Http -Method 'GET' -Path ("/policy/detail?id={0}" -f $draftId) -Session $sunS
Check "员工直接拼 id 查看未生效制度被拒(403)" ($deny.Status -eq 403) ("status={0}" -f $deny.Status)

# ---------------------------------------------------------------- 本人单据
Write-Host ""
Write-Host "【三】经授权查询本人单据状态"
$my = Http -Method 'GET' -Path '/mydoc/list' -Session $sunS
Check "员工可打开我的单据页" ($my.Status -eq 200)
$mineIds = @()
foreach ($m in [regex]::Matches($my.Content, 'mydoc/detail\?id=(\d+)')) { $mineIds += [int]$m.Groups[1].Value }
$mineIds = $mineIds | Sort-Object -Unique
Check "本人单据列表非空（种子数据 4 张）" ($mineIds.Count -ge 4) ("实际 {0} 张" -f $mineIds.Count)

$clerk = Login 'wangm' '123456'
$cl = Http -Method 'GET' -Path '/clerk/doc/list' -Session $clerk.Session
Check "业务员可进入单据维护（用它取出全库单据 id）" ($cl.Status -eq 200)
$allIds = @()
foreach ($m in [regex]::Matches($cl.Content, 'doc/edit\?id=(\d+)')) { $allIds += [int]$m.Groups[1].Value }
foreach ($m in [regex]::Matches($cl.Content, 'name="id" value="(\d+)"')) { $allIds += [int]$m.Groups[1].Value }
# 排除 id=0：那是"登记单据"链接带的占位值，不是真实单据
$allIds = $allIds | Where-Object { $_ -gt 0 } | Sort-Object -Unique
$otherId = ($allIds | Where-Object { $mineIds -notcontains $_ } | Select-Object -First 1)
Check "取到一张他人单据用于越权测试" ($otherId -ne $null) `
    ("全库={0} 本人={1}" -f ($allIds -join ','), ($mineIds -join ','))

$cross = Http -Method 'GET' -Path ("/mydoc/detail?id={0}" -f $otherId) -Session $sunS
Check "员工凭 id 直接查询他人单据被拒(403)" ($cross.Status -eq 403) ("status={0}" -f $cross.Status)

$ownOne = $mineIds | Select-Object -First 1
$own = Http -Method 'GET' -Path ("/mydoc/detail?id={0}" -f $ownOne) -Session $sunS
Check "员工查询本人单据详情成功" ($own.Status -eq 200 -and $own.Content.Contains('办理轨迹'))
$nf = Http -Method 'GET' -Path '/mydoc/detail?id=99999999' -Session $sunS
Check "不存在的单据返回 404" ($nf.Status -eq 404) ("status={0}" -f $nf.Status)

# ---------------------------------------------------------------- 职责分离
Write-Host ""
Write-Host "【四】职责分离：制度归专员、事实归业务员"
Check "员工访问制度维护被拒(403)" ((Http -Method 'GET' -Path '/specialist/policy/list' -Session $sunS).Status -eq 403)
Check "员工访问单据维护被拒(403)" ((Http -Method 'GET' -Path '/clerk/doc/list' -Session $sunS).Status -eq 403)
Check "员工访问账号管理被拒(403)" ((Http -Method 'GET' -Path '/admin/user/list' -Session $sunS).Status -eq 403)
Check "专员访问单据维护被拒(403)" ((Http -Method 'GET' -Path '/clerk/doc/list' -Session $spec.Session).Status -eq 403)
Check "业务员访问制度维护被拒(403)" ((Http -Method 'GET' -Path '/specialist/policy/list' -Session $clerk.Session).Status -eq 403)
$admin = Login 'admin' '123456'
Check "管理员可进入账号管理" ((Http -Method 'GET' -Path '/admin/user/list' -Session $admin.Session).Status -eq 200)
Check "管理员也不能维护制度(403)" ((Http -Method 'GET' -Path '/specialist/policy/list' -Session $admin.Session).Status -eq 403)
Check "管理员也不能维护业务事实(403)" ((Http -Method 'GET' -Path '/clerk/doc/list' -Session $admin.Session).Status -eq 403)

# ---------------------------------------------------------------- 业务事实维护
Write-Host ""
Write-Host "【五】业务事实维护（业务员）"
$editNew = Http -Method 'GET' -Path '/clerk/doc/edit?id=0' -Session $clerk.Session
Check "业务员可打开登记单据表单" ($editNew.Status -eq 200)
$ownerId = ""
foreach ($m in [regex]::Matches($editNew.Content, '<option value="(\d+)"[^>]*>\s*([^<]*)')) {
    if ($m.Groups[2].Value -match '孙悦') { $ownerId = $m.Groups[1].Value; break }
}
Check "表单里能选到员工孙悦作为归属人" ($ownerId -ne "")

$reason = "验收脚本自动登记 " + (Get-Date).ToString('HHmmss')
$save = Http -Method 'POST' -Path '/clerk/doc/save' -Session $clerk.Session `
    -Body ("id=0&ownerId={0}&expenseType=OFFICE&amount=88.50&occurredOn={1}&policyCode=BX-2024-02&reason={2}" `
           -f $ownerId, $today, (Escape $reason))
Check "业务员登记单据成功" ($save.Status -eq 200 -and $save.Content.Contains('已登记')) ("status={0}" -f $save.Status)
Check "登记过程没有触发校验错误" (-not $save.Content.Contains('flash err'))

$my2 = Http -Method 'GET' -Path ("/mydoc/list?keyword={0}" -f (Escape $reason)) -Session $sunS
$found = Count-Of $my2.Content '/mydoc/detail?id='
Check "员工能查到刚登记到自己名下的单据" ($found -eq 1) ("实际 {0} 条" -f $found)

# 无效事实被拒：金额为 0
$badAmount = Http -Method 'POST' -Path '/clerk/doc/save' -Session $clerk.Session `
    -Body ("id=0&ownerId={0}&expenseType=OFFICE&amount=0&occurredOn={1}&reason=x" -f $ownerId, $today)
Check "金额为 0 的事实被拒" ($badAmount.Content.Contains('flash err'))

# ---------------------------------------------------------------- 状态机
Write-Host ""
Write-Host "【六】单据状态机与终态冻结"
$submittedRow = ""
foreach ($seg in ($my.Content -split '<tr')) {
    if ($seg.Contains('st-SUBMITTED')) { $submittedRow = $seg; break }
}
$submittedId = [regex]::Match($submittedRow, 'mydoc/detail\?id=(\d+)').Groups[1].Value
Check "取到一张状态为已提交的本人单据" ($submittedId -ne "")

$jump = Http -Method 'POST' -Path '/clerk/doc/progress' -Session $clerk.Session `
    -Body ("id={0}&target=PAID&note=越级尝试" -f $submittedId)
Check "状态越级推进（已提交→已支付）被拒" ($jump.Content.Contains('flash err'))

$noNote = Http -Method 'POST' -Path '/clerk/doc/progress' -Session $clerk.Session `
    -Body ("id={0}&target=REJECTED&note=" -f $submittedId)
Check "驳回不填原因被拒" ($noNote.Content.Contains('flash err'))

$okMove = Http -Method 'POST' -Path '/clerk/doc/progress' -Session $clerk.Session `
    -Body ("id={0}&target=REVIEWING&note=验收脚本推进" -f $submittedId)
Check "按顺序推进（已提交→审核中）成功" ($okMove.Content.Contains('已更新为'))

$after = Http -Method 'GET' -Path ("/mydoc/detail?id={0}" -f $submittedId) -Session $sunS
Check "员工侧看到的状态同步更新为审核中" ($after.Content.Contains('st-REVIEWING'))

$zhou = Login 'zhouw' '123456'
$zl = Http -Method 'GET' -Path '/mydoc/list' -Session $zhou.Session
$paidRow = ""
foreach ($seg in ($zl.Content -split '<tr')) {
    if ($seg.Contains('st-PAID')) { $paidRow = $seg; break }
}
$paidId = [regex]::Match($paidRow, 'mydoc/detail\?id=(\d+)').Groups[1].Value
Check "取到一张已支付的终态单据" ($paidId -ne "")
$frozen = Http -Method 'POST' -Path '/clerk/doc/save' -Session $clerk.Session `
    -Body ("id={0}&ownerId={1}&expenseType=TRAVEL&amount=1.00&occurredOn={2}&policyCode=&reason=x" `
           -f $paidId, $ownerId, $today)
Check "终态单据的业务事实已冻结，修改被拒" ($frozen.Content.Contains('flash err'))

# ---------------------------------------------------------------- 制度版本控制
Write-Host ""
Write-Host "【七】制度版本与生效控制"
$beforeRow = Row-Of $pl.Content 'CS-2024-01'
$vBefore = [int]([regex]::Match($beforeRow, '>V(\d+)<').Groups[1].Value)
$policyId = [regex]::Match($beforeRow, '/policy/detail\?id=(\d+)').Groups[1].Value
Check "取到当前生效版本号与制度 id" ($vBefore -ge 1 -and $policyId -ne "") ("V{0} id={1}" -f $vBefore, $policyId)

$rev = Http -Method 'POST' -Path '/specialist/policy/save' -Session $spec.Session `
    -Body ("id={0}&content={1}&changeNote={2}" `
           -f $policyId, (Escape "第一条 适用范围`n本条由验收脚本修订。"), (Escape "验收脚本自动修订"))
Check "专员修订制度生成新版本草稿" ($rev.Content.Contains('草稿'))

$pl2 = Http -Method 'GET' -Path '/policy/list' -Session $sunS
$vAfterRevise = [int]([regex]::Match((Row-Of $pl2.Content 'CS-2024-01'), '>V(\d+)<').Groups[1].Value)
Check "草稿未发布，员工仍只看到旧版本" ($vAfterRevise -eq $vBefore) ("员工看到 V{0}" -f $vAfterRevise)

$spl = Http -Method 'GET' -Path '/specialist/policy/list' -Session $spec.Session
$draftRow2 = Row-Of $spl.Content 'CS-2024-01'
$draftId2 = [regex]::Match($draftRow2, 'publish">[\s\S]*?name="id" value="(\d+)"').Groups[1].Value
Check "专员列表里出现待发布的草稿" ($draftId2 -ne "")

$pub = Http -Method 'POST' -Path '/specialist/policy/publish' -Session $spec.Session `
    -Body ("id={0}&effectiveFrom={1}&effectiveTo=&changeNote=" -f $draftId2, $today)
Check "专员发布草稿成功" ($pub.Content.Contains('已发布'))

$pl3 = Http -Method 'GET' -Path '/policy/list' -Session $sunS
$vAfterPublish = [int]([regex]::Match((Row-Of $pl3.Content 'CS-2024-01'), '>V(\d+)<').Groups[1].Value)
Check "发布后员工查到的是新版本" ($vAfterPublish -gt $vBefore) ("发布前 V{0} → 发布后 V{1}" -f $vBefore, $vAfterPublish)

$codeRows = 0
foreach ($seg in ($pl3.Content -split '<tr')) {
    if ($seg.Contains('CS-2024-01')) { $codeRows++ }
}
Check "同一编码在员工视图只出现一条（旧版自动废止）" ($codeRows -eq 1) ("实际 {0} 行" -f $codeRows)

$sp2 = Http -Method 'GET' -Path '/specialist/policy/list' -Session $spec.Session
$codeRowsAll = 0
foreach ($seg in ($sp2.Content -split '<tr')) {
    if ($seg.Contains('CS-2024-01')) { $codeRowsAll++ }
}
Check "专员视图保留完整版本链（历史版本仍在）" ($codeRowsAll -ge $codeRows + 1) ("专员可见 {0} 行" -f $codeRowsAll)

# ---------------------------------------------------------------- 审计
Write-Host ""
Write-Host "【八】审计留痕"
$al = Http -Method 'GET' -Path '/admin/audit/list?action=DENIED&result=DENY&limit=500' -Session $admin.Session
Check "审计页可按动作+结果筛选" ($al.Status -eq 200)
$denyCount = Count-Of $al.Content 'st-DENY'
Check "越权尝试已写入审计（结果=拒绝）" ($denyCount -ge 5) ("实际 {0} 条" -f $denyCount)
$pl4 = Http -Method 'GET' -Path '/admin/audit/list?action=LOGIN_FAIL&result=DENY&limit=50' -Session $admin.Session
Check "登录失败也留痕" ($pl4.Content.Contains('st-DENY'))
Check "员工可自助修改本人口令（页面可达）" ((Http -Method 'GET' -Path '/profile' -Session $sunS).Status -eq 200)

# ---------------------------------------------------------------- 视图覆盖
Write-Host ""
Write-Host "【九】页面可达性（每个视图至少渲染一次，兼作 JSP 编译检查）"
# 制度经过上面的改版，原来那个 id 已经是"已废止"版本；这里重新取当前生效版本的 id
$plNow = Http -Method 'GET' -Path '/policy/list' -Session $sunS
$effPolicyId = [regex]::Match($plNow.Content, '/policy/detail\?id=(\d+)').Groups[1].Value
$views = @(
    @{ Who = '员工';   S = $sunS;          P = '/home' },
    @{ Who = '员工';   S = $sunS;          P = '/policy/list' },
    @{ Who = '员工';   S = $sunS;          P = ('/policy/detail?id={0}' -f $effPolicyId) },
    @{ Who = '员工';   S = $sunS;          P = '/mydoc/list' },
    @{ Who = '员工';   S = $sunS;          P = ('/mydoc/detail?id={0}' -f $ownOne) },
    @{ Who = '员工';   S = $sunS;          P = '/profile' },
    @{ Who = '员工';   S = $sunS;          P = '/mydoc/list?status=REJECTED' },
    @{ Who = '专员';   S = $spec.Session;  P = '/home' },
    @{ Who = '专员';   S = $spec.Session;  P = '/specialist/policy/list' },
    @{ Who = '专员';   S = $spec.Session;  P = '/specialist/policy/edit?id=0' },
    @{ Who = '专员';   S = $spec.Session;  P = ('/specialist/policy/edit?id={0}' -f $policyId) },
    @{ Who = '业务员'; S = $clerk.Session; P = '/clerk/doc/list' },
    @{ Who = '业务员'; S = $clerk.Session; P = '/clerk/doc/edit?id=0' },
    @{ Who = '业务员'; S = $clerk.Session; P = ('/clerk/doc/edit?id={0}' -f $submittedId) },
    @{ Who = '业务员'; S = $clerk.Session; P = ('/clerk/doc/edit?id={0}' -f $paidId) },
    @{ Who = '业务员'; S = $clerk.Session; P = '/clerk/doc/list?status=SUBMITTED' },
    @{ Who = '管理员'; S = $admin.Session; P = '/admin/user/list' },
    @{ Who = '管理员'; S = $admin.Session; P = '/admin/user/edit?id=0' },
    @{ Who = '管理员'; S = $admin.Session; P = ('/admin/user/edit?id={0}' -f $ownerId) },
    @{ Who = '管理员'; S = $admin.Session; P = '/admin/audit/list' },
    @{ Who = '管理员'; S = $admin.Session; P = '/admin/audit/list?action=DENIED&result=DENY' }
)
foreach ($v in $views) {
    $resp = Http -Method 'GET' -Path $v.P -Session $v.S
    Check ("{0} 可渲染 {1}" -f $v.Who, $v.P) ($resp.Status -eq 200) ("status={0}" -f $resp.Status)
}

# ---------------------------------------------------------------- 汇总
Write-Host ""
Write-Host "======================================================"
Write-Host ("汇总：通过 {0} 项，失败 {1} 项" -f $script:Pass, $script:Fail)
if ($script:Fail -gt 0) {
    Write-Host "失败清单："
    foreach ($f in $script:Failed) { Write-Host ("  - " + $f) }
    exit 1
}
Write-Host "全部通过。"
exit 0
