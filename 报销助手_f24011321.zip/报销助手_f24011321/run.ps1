# 报销助手_f24011321 启动脚本：构建两个变体 -> 部署 -> 启动 Tomcat -> 打开登录页
#
# 两种用法：
#   1) 直接用主安装：      .\run.ps1
#   2) 用独立 CATALINA_BASE（不影响主安装里已有的应用，可换端口）：
#        .\run.ps1 -BaseDir .\build\verify\tomcat-base
# 若提示"无法加载脚本，因为在此系统上禁止运行脚本"，改用：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1
param(
    [string]$TomcatHome = "D:\apache-tomcat-11.0.26",
    [string]$BaseDir = "",
    [string]$JavaHome = "",
    [switch]$SkipJdbc
)

$ErrorActionPreference = "Stop"
$TomcatHome = $TomcatHome.TrimEnd('\')

# JavaHome 未指定时，从 C:\Program Files\Java 下挑一个可用的 JDK
if (-not $JavaHome) {
    $cands = Get-ChildItem 'C:\Program Files\Java' -Directory -Filter 'jdk*' -ErrorAction SilentlyContinue |
             Where-Object { Test-Path (Join-Path $_.FullName 'bin\java.exe') } |
             Sort-Object Name -Descending
    if (-not $cands) { throw "未找到 JDK，请用 -JavaHome 指定" }
    $JavaHome = $cands[0].FullName
}
$JavaHome = $JavaHome.TrimEnd('\')

if (-not (Test-Path (Join-Path $TomcatHome "bin\catalina.bat"))) {
    throw "CATALINA_HOME 无效：$TomcatHome\bin\catalina.bat 不存在"
}
if (-not (Test-Path (Join-Path $JavaHome "bin\java.exe"))) {
    throw "JAVA_HOME 无效：$JavaHome\bin\java.exe 不存在"
}

$env:CATALINA_HOME = $TomcatHome
$env:JAVA_HOME     = $JavaHome
$env:JRE_HOME      = $JavaHome

$port = 8080
$webapps = ""
$dataRoot = ""
if ($BaseDir) {
    $BaseDir = $BaseDir.TrimEnd('\')
    if (-not (Test-Path (Join-Path $BaseDir "conf\server.xml"))) {
        throw "CATALINA_BASE 无效：$BaseDir\conf\server.xml 不存在（可先复制 $TomcatHome\conf 到该目录）"
    }
    $env:CATALINA_BASE = $BaseDir
    $webapps  = Join-Path $BaseDir "webapps"
    $dataRoot = Join-Path $BaseDir "data"
    # 从 server.xml 读出实际监听端口，避免写死 8080
    $m = [regex]::Match((Get-Content (Join-Path $BaseDir "conf\server.xml") -Raw), '<Connector\s+port="(\d+)"')
    if ($m.Success) { $port = [int]$m.Groups[1].Value }
} else {
    $env:CATALINA_BASE = $TomcatHome
}

& (Join-Path $PSScriptRoot "build.ps1") -TomcatHome $TomcatHome -WebappsDir $webapps -DataRoot $dataRoot -HttpPort $port -SkipJdbc:$SkipJdbc

# 端口已在监听就认为 Tomcat 正在运行，不重复启动
$listening = $null -ne (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
if ($listening) {
    Write-Host "$port 已在监听，跳过启动（Tomcat 可能已在运行）"
} else {
    & cmd.exe /c "`"$TomcatHome\bin\startup.bat`""
    $ok = $false
    for ($i = 0; $i -lt 25; $i++) {
        Start-Sleep -Seconds 1
        if (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) { $ok = $true; break }
    }
    if ($ok) { Write-Host "Tomcat 已启动（端口 $port）" }
    else { Write-Host "警告：25 秒内未监听到 $port，请查看日志目录下的 catalina.*.log" }
}

Start-Process "http://localhost:$port/reimburse/login"
Write-Host "关闭服务器：& `"$TomcatHome\bin\shutdown.bat`"   （使用 -BaseDir 时记得带同样的环境变量）"
