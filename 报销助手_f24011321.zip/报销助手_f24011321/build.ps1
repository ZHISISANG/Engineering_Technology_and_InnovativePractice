# 报销助手_f24011321 构建脚本
#   一次编译，打包并部署两个运行变体：
#     reimburse       —— 文件持久化版（数据存 JSON 文本）
#     reimburse-jdbc  —— H2 嵌入式数据库版（数据存 .mv.db，建表语句见 WEB-INF/sql/schema-h2.sql）
#   两个变体共用同一份 Java 源码，差异只在 WEB-INF/config/app.properties 的 storage 参数
#   与是否打入 H2 驱动。这比复制两份代码更容易保持一致。
param(
    [string]$TomcatHome = "D:\apache-tomcat-11.0.26",
    [string]$WebappsDir = "",     # 默认 <TomcatHome>\webapps；指定它可部署到另一个 CATALINA_BASE
    [string]$DataRoot = "",       # 默认 <TomcatHome>\reimburse-data
    [int]$HttpPort = 8080,        # 只用于最后打印访问地址
    [switch]$SkipDeploy,          # 只打包，不复制到 webapps
    [switch]$SkipJdbc             # 只构建文件版
)

$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot

$TomcatHome = $TomcatHome.TrimEnd('\')
$servletApi = Join-Path $TomcatHome "lib\servlet-api.jar"
if (-not (Test-Path $servletApi)) {
    throw "找不到 servlet-api.jar：$servletApi"
}
if (-not $WebappsDir) { $WebappsDir = Join-Path $TomcatHome "webapps" }
if (-not $DataRoot)   { $DataRoot   = Join-Path $TomcatHome "reimburse-data" }
$WebappsDir = $WebappsDir.TrimEnd('\')
$DataRoot = $DataRoot.TrimEnd('\')

$srcJava   = Join-Path $projectRoot "src\main\java"
$srcWebapp = Join-Path $projectRoot "src\main\webapp"
$buildDir  = Join-Path $projectRoot "build"
$classesDir = Join-Path $buildDir "classes"
$stageRoot = Join-Path $buildDir "stage"
$targetDir = Join-Path $projectRoot "target"
$h2Jar     = Join-Path $projectRoot "lib\h2-2.2.220.jar"

# ---------- 1. 编译 ----------
if (Test-Path $classesDir) { Remove-Item $classesDir -Recurse -Force }
New-Item -ItemType Directory -Path $classesDir -Force | Out-Null

$sources = Get-ChildItem $srcJava -Recurse -Filter *.java | ForEach-Object { $_.FullName }
if (-not $sources) { throw "没有找到 Java 源码：$srcJava" }

# 编译期类路径只需要 Servlet API：JDBC 实现只用 java.sql，H2 驱动通过 Class.forName 字符串加载
& javac -encoding UTF-8 --release 17 -cp "$servletApi" -d $classesDir $sources
if ($LASTEXITCODE -ne 0) { throw "javac 编译失败" }
Write-Host "[1/3] 编译完成：$($sources.Count) 个源文件 -> build\classes"

# ---------- 2. 打包 ----------
New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
if (Test-Path $stageRoot) { Remove-Item $stageRoot -Recurse -Force }

function Write-Utf8NoBom {
    param([string]$Path, [string]$Text)
    # 必须无 BOM：java.util.Properties 会把 BOM 当成第一个键名的一部分
    $enc = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

$variants = @(
    [pscustomobject]@{ Name = "reimburse";      Storage = "file"; DataDir = "file" },
    [pscustomobject]@{ Name = "reimburse-jdbc"; Storage = "jdbc"; DataDir = "jdbc" }
)
if ($SkipJdbc) { $variants = $variants | Where-Object { $_.Storage -eq "file" } }

$wars = @()
foreach ($v in $variants) {
    $stage = Join-Path $stageRoot $v.Name
    New-Item -ItemType Directory -Path $stage -Force | Out-Null

    Copy-Item (Join-Path $srcWebapp "*") $stage -Recurse -Force
    # 源码里的 app.properties 只是模板，实际配置按变体生成
    Remove-Item (Join-Path $stage "WEB-INF\config\app.properties") -Force -ErrorAction SilentlyContinue

    New-Item -ItemType Directory -Path (Join-Path $stage "WEB-INF\classes") -Force | Out-Null
    Copy-Item (Join-Path $classesDir "*") (Join-Path $stage "WEB-INF\classes") -Recurse -Force

    if ($v.Storage -eq "jdbc") {
        if (-not (Test-Path $h2Jar)) { throw "数据库版需要 H2 驱动：$h2Jar" }
        New-Item -ItemType Directory -Path (Join-Path $stage "WEB-INF\lib") -Force | Out-Null
        Copy-Item $h2Jar (Join-Path $stage "WEB-INF\lib\h2-2.2.220.jar") -Force
    }

    # 数据目录放在 webapps 之外：重新部署会清空 webapps 下的目录，放里面会丢数据。
    # 只打包不部署时不去碰数据目录——那个路径可能在工作区之外，没必要动它。
    $dataDir = Join-Path $DataRoot $v.DataDir
    if (-not $SkipDeploy) {
        New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
    }

    $props = @"
# 由 build.ps1 生成，请勿手工修改（修改后重新构建会被覆盖）
# 存储方式：file = JSON 文本文件；jdbc = H2 嵌入式数据库
storage=$($v.Storage)
contextPath=$($v.Name)
dataDir=$($dataDir -replace '\\','/')
session.timeoutMinutes=30
"@
    Write-Utf8NoBom -Path (Join-Path $stage "WEB-INF\config\app.properties") -Text $props

    $war = Join-Path $targetDir "$($v.Name).war"
    if (Test-Path $war) { Remove-Item $war -Force }
    & jar --create --file $war -C $stage .
    if ($LASTEXITCODE -ne 0) { throw "打包 $($v.Name).war 失败" }
    $wars += [pscustomobject]@{ Variant = $v; War = $war; Stage = $stage; DataDir = $dataDir }
}
Write-Host "[2/3] 打包完成：$($wars.Count) 个 war -> target\"

# ---------- 3. 部署 ----------
if (-not $SkipDeploy) {
    foreach ($w in $wars) {
        $deployDir = Join-Path $WebappsDir $w.Variant.Name
        if (Test-Path $deployDir) { Remove-Item $deployDir -Recurse -Force }
        New-Item -ItemType Directory -Path $WebappsDir -Force | Out-Null
        Copy-Item $w.Stage $deployDir -Recurse -Force
        Write-Host "        部署 -> $deployDir"
    }
}
Write-Host "[3/3] 完成"
Write-Host ""
foreach ($w in $wars) {
    $label = if ($w.Variant.Storage -eq "jdbc") { "数据库版(H2)" } else { "文件持久化版" }
    Write-Host ("  {0,-9} {1,-16} http://localhost:{2}/{3}/login" -f $label, $w.Variant.Name, $HttpPort, $w.Variant.Name)
    Write-Host ("            数据目录 {0}" -f $w.DataDir)
}
