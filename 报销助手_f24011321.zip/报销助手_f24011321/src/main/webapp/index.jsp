<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %><%
    // 入口只做跳转：真正的登录逻辑在 AuthServlet
    response.sendRedirect(request.getContextPath() + "/login");
%>
