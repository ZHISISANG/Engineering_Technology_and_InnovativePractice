<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "首页"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<Policy> effectivePolicies = (List<Policy>) request.getAttribute("effectivePolicies");
    Integer effectivePolicyCount = (Integer) request.getAttribute("effectivePolicyCount");
    List<Document> ownDocuments = (List<Document>) request.getAttribute("ownDocuments");
    Map<DocStatus, Integer> ownStatusCounts = (Map<DocStatus, Integer>) request.getAttribute("ownStatusCounts");
    BigDecimal ownAmount = (BigDecimal) request.getAttribute("ownAmount");
    Integer pendingCount = (Integer) request.getAttribute("pendingCount");
    Integer allDocumentCount = (Integer) request.getAttribute("allDocumentCount");
    Integer policyTotalCount = (Integer) request.getAttribute("policyTotalCount");
    Integer policyDraftCount = (Integer) request.getAttribute("policyDraftCount");
    Integer policyActiveCount = (Integer) request.getAttribute("policyActiveCount");
    Integer userCount = (Integer) request.getAttribute("userCount");
    Long auditCount = (Long) request.getAttribute("auditCount");
    List<AuditLog> deniedLogs = (List<AuditLog>) request.getAttribute("deniedLogs");
%>

<h1><%= Esc.html(me.getDisplayName()) %>，你好</h1>
<p class="muted small">
    你当前的角色是 <strong><%= Esc.html(me.getRole().getLabel()) %></strong>。
    <% if (me.getRole() == Role.EMPLOYEE) { %>
    可以自助查询当前有效制度，并查看本人报销单据的办理状态。
    <% } else if (me.getRole().canMaintainPolicy()) { %>
    除查询外，你负责维护制度（新增、修订、发布、废止）。
    <% } else if (me.getRole().canMaintainDocument()) { %>
    除查询外，你负责维护业务事实（登记单据、修正金额与事由、推进状态）。
    <% } else { %>
    除查询外，你负责账号维护与审计日志查看。
    <% } %>
</p>

<div class="grid">
    <div class="card">
        <div class="metric"><%= effectivePolicyCount %></div>
        <div class="metric-label">当前有效制度（可被查询）</div>
    </div>
    <div class="card">
        <div class="metric"><%= ownDocuments == null ? 0 : ownDocuments.size() %></div>
        <div class="metric-label">我的单据</div>
    </div>
    <div class="card">
        <div class="metric"><%= ownAmount == null ? "0.00" : ownAmount.toPlainString() %></div>
        <div class="metric-label">我的单据金额合计（元）</div>
    </div>
    <% if (pendingCount != null) { %>
    <div class="card">
        <div class="metric"><%= pendingCount %></div>
        <div class="metric-label">待处理单据（已提交 + 审核中）</div>
    </div>
    <% } %>
</div>

<% if (me.getRole().canMaintainDocument()) { %>
<h2>业务事实维护概况</h2>
<div class="card">
    全库单据共 <strong><%= allDocumentCount %></strong> 张，其中待处理 <strong><%= pendingCount %></strong> 张。
    <a class="btn mini" href="<%= ctx %>/clerk/doc/list">进入单据维护</a>
</div>
<% } %>

<% if (me.getRole().canMaintainPolicy()) { %>
<h2>制度维护概况</h2>
<div class="card">
    制度版本共 <strong><%= policyTotalCount %></strong> 条，其中当前有效 <strong><%= policyActiveCount %></strong> 条，
    草稿待发布 <strong><%= policyDraftCount %></strong> 条。
    <a class="btn mini" href="<%= ctx %>/specialist/policy/list">进入制度维护</a>
</div>
<% } %>

<% if (me.getRole().canAdminister()) { %>
<h2>系统概况</h2>
<div class="card">
    账号 <strong><%= userCount %></strong> 个，审计记录 <strong><%= auditCount %></strong> 条。
    <a class="btn mini" href="<%= ctx %>/admin/user/list">账号管理</a>
    <a class="btn mini ghost" href="<%= ctx %>/admin/audit/list">审计日志</a>
</div>
<% if (deniedLogs != null && !deniedLogs.isEmpty()) { %>
<h3>最近的越权尝试</h3>
<table>
    <thead>
    <tr><th class="nowrap">时间</th><th class="nowrap">账号</th><th class="nowrap">对象</th><th>原因</th></tr>
    </thead>
    <tbody>
    <% for (AuditLog log : deniedLogs) { %>
    <tr>
        <td class="nowrap mono small"><%= Esc.html(Dates.format(log.getAtTime(), "-")) %></td>
        <td class="nowrap"><%= Esc.html(log.getActor()) %></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(log.getTarget(), "-")) %></td>
        <td><%= Esc.html(Esc.truncate(log.getDetail(), 60)) %></td>
    </tr>
    <% } %>
    </tbody>
</table>
<% } %>
<% } %>

<h2>我的单据状态</h2>
<% if (ownStatusCounts != null) { %>
<p class="small muted">
    <% for (Map.Entry<DocStatus, Integer> e : ownStatusCounts.entrySet()) { %>
    <span class="badge st-<%= e.getKey().name() %>"><%= Esc.html(e.getKey().getLabel()) %> <%= e.getValue() %></span>
    <% } %>
</p>
<% } %>
<table>
    <thead>
    <tr>
        <th class="nowrap">单据号</th><th class="nowrap">费用类型</th><th class="num">金额(元)</th>
        <th class="nowrap">发生日期</th><th class="nowrap">当前状态</th><th>经办说明</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <%
        int shown = 0;
        for (Document d : ownDocuments) {
            if (shown++ >= 6) break;
    %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(d.getDocNo()) %></td>
        <td class="nowrap"><%= Esc.html(d.getExpenseType().getLabel()) %></td>
        <td class="num"><%= d.getAmount().toPlainString() %></td>
        <td class="nowrap"><%= Esc.html(Dates.format(d.getOccurredOn(), "-")) %></td>
        <td class="nowrap"><span class="badge st-<%= d.getStatus().name() %>"><%= Esc.html(d.getStatus().getLabel()) %></span></td>
        <td><%= Esc.html(Esc.truncate(Esc.nvl(d.getHandleNote(), "-"), 40)) %></td>
        <td class="nowrap"><a href="<%= ctx %>/mydoc/detail?id=<%= d.getId() %>">查看</a></td>
    </tr>
    <% } %>
    <% if (ownDocuments == null || ownDocuments.isEmpty()) { %>
    <tr><td colspan="7" class="empty">你名下还没有报销单据。</td></tr>
    <% } %>
    </tbody>
</table>
<p class="small"><a href="<%= ctx %>/mydoc/list">查看我的全部单据 →</a></p>

<h2>当前有效制度</h2>
<table>
    <thead>
    <tr><th class="nowrap">编码</th><th>制度名称</th><th class="nowrap">分类</th><th class="nowrap">版本</th>
        <th class="nowrap">有效期</th><th class="nowrap">操作</th></tr>
    </thead>
    <tbody>
    <% for (Policy p : effectivePolicies) { %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(p.getCode()) %></td>
        <td><%= Esc.html(p.getTitle()) %></td>
        <td class="nowrap"><%= Esc.html(p.getCategory()) %></td>
        <td class="nowrap"><%= Esc.html(p.getVersionLabel()) %></td>
        <td class="nowrap"><%= Esc.html(p.getEffectiveLabel()) %></td>
        <td class="nowrap"><a href="<%= ctx %>/policy/detail?id=<%= p.getId() %>">查看</a></td>
    </tr>
    <% } %>
    <% if (effectivePolicies == null || effectivePolicies.isEmpty()) { %>
    <tr><td colspan="6" class="empty">当前没有生效中的制度。</td></tr>
    <% } %>
    </tbody>
</table>
<p class="small"><a href="<%= ctx %>/policy/list">进入制度自助查询 →</a></p>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
