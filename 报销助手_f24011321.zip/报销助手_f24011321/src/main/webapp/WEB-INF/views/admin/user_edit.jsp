<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "账号编辑"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    User editUser = (User) request.getAttribute("editUser");
    Boolean isNew = (Boolean) request.getAttribute("isNew");
    Role[] roles = (Role[]) request.getAttribute("roles");
    boolean creating = Boolean.TRUE.equals(isNew);
%>

<h1><%= creating ? "新增账号" : "修改账号 " + Esc.html(editUser.getUsername()) %></h1>

<form method="post" action="<%= ctx %>/admin/user/save">
    <input type="hidden" name="id" value="<%= creating ? 0 : editUser.getId() %>">

    <div class="card" style="max-width:620px">
        <div class="form-row">
            <label for="username">账号</label>
            <% if (creating) { %>
            <input type="text" id="username" name="username" placeholder="字母、数字、下划线，3-32 位">
            <div class="hint">账号一旦创建不能修改。</div>
            <% } else { %>
            <input type="text" value="<%= Esc.attr(editUser.getUsername()) %>" disabled>
            <% } %>
        </div>

        <div class="form-row">
            <label for="displayName">姓名</label>
            <input type="text" id="displayName" name="displayName"
                   value="<%= Esc.attr(editUser == null ? null : editUser.getDisplayName()) %>">
        </div>

        <div class="form-row">
            <label for="role">角色</label>
            <select id="role" name="role">
                <% for (Role r : roles) { %>
                <option value="<%= r.name() %>"<%= editUser != null && editUser.getRole() == r ? " selected" : "" %>>
                    <%= Esc.html(r.getLabel()) %>
                </option>
                <% } %>
            </select>
            <div class="hint">
                员工：查询有效制度与本人单据；制度专员：另可维护制度；
                业务员：另可维护业务事实；系统管理员：另可管理账号与审计。
            </div>
        </div>

        <div class="form-row">
            <label for="dept">部门</label>
            <input type="text" id="dept" name="dept" value="<%= Esc.attr(editUser == null ? null : editUser.getDept()) %>">
        </div>

        <div class="form-row">
            <label for="employeeNo">工号</label>
            <input type="text" id="employeeNo" name="employeeNo" value="<%= Esc.attr(editUser == null ? null : editUser.getEmployeeNo()) %>">
            <div class="hint">工号只用于展示与检索，登录仍使用账号。</div>
        </div>

        <% if (creating) { %>
        <div class="form-row">
            <label for="password">初始口令</label>
            <input type="password" id="password" name="password" autocomplete="new-password">
            <div class="hint">至少 6 位，保存时按 PBKDF2-SHA256 加盐派生后入库。</div>
        </div>
        <% } else { %>
        <div class="form-row">
            <label><input type="checkbox" name="enabled"<%= editUser.isEnabled() ? " checked" : "" %>> 启用该账号</label>
            <div class="hint">
                不勾选即停用，停用后不能登录。系统会阻止你停用自己，
                阻止你改掉或停用最后一个启用的管理员。
            </div>
        </div>
        <% } %>
    </div>

    <button type="submit">保存</button>
    <a class="btn ghost" href="<%= ctx %>/admin/user/list">返回账号列表</a>
</form>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
