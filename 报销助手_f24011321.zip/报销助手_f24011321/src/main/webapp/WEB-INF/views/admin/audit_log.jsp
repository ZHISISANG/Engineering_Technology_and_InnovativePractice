<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "审计日志"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<AuditLog> logs = (List<AuditLog>) request.getAttribute("logs");
    String action = (String) request.getAttribute("action");
    String result = (String) request.getAttribute("result");
    Integer limit = (Integer) request.getAttribute("limit");
    AuditAction[] actions = (AuditAction[]) request.getAttribute("actions");
    AuditResult[] results = (AuditResult[]) request.getAttribute("results");
    Long totalCount = (Long) request.getAttribute("totalCount");
%>

<h1>审计日志</h1>
<p class="muted small">
    登录、查询制度、查询本人单据、维护制度与业务事实、以及<strong>被拒绝的越权尝试</strong>都会留一条记录。
    目前累计 <strong><%= totalCount %></strong> 条。日志只追加、不提供修改入口。
</p>

<form class="filters" method="get" action="<%= ctx %>/admin/audit/list">
    <div class="field">
        <label for="action">动作</label>
        <select id="action" name="action">
            <option value="">全部动作</option>
            <% for (AuditAction a : actions) { %>
            <option value="<%= a.name() %>"<%= a.name().equalsIgnoreCase(Esc.nvl(action, "")) ? " selected" : "" %>><%= Esc.html(a.getLabel()) %></option>
            <% } %>
        </select>
    </div>
    <div class="field">
        <label for="result">结果</label>
        <select id="result" name="result">
            <option value="">全部结果</option>
            <% for (AuditResult r : results) { %>
            <option value="<%= r.name() %>"<%= r.name().equalsIgnoreCase(Esc.nvl(result, "")) ? " selected" : "" %>><%= Esc.html(r.getLabel()) %></option>
            <% } %>
        </select>
    </div>
    <div class="field">
        <label for="limit">最多显示</label>
        <select id="limit" name="limit">
            <% for (int n : new int[]{50, 200, 500, 1000}) { %>
            <option value="<%= n %>"<%= limit != null && limit.intValue() == n ? " selected" : "" %>><%= n %> 条</option>
            <% } %>
        </select>
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/admin/audit/list?action=DENIED&result=DENY">只看越权尝试</a>
</form>

<p class="small muted">命中 <strong><%= logs.size() %></strong> 条。</p>

<table>
    <thead>
    <tr>
        <th class="nowrap">时间</th><th class="nowrap">账号</th><th class="nowrap">角色</th>
        <th class="nowrap">动作</th><th class="nowrap">结果</th><th class="nowrap">对象</th>
        <th>详情</th><th class="nowrap">来源 IP</th>
    </tr>
    </thead>
    <tbody>
    <% for (AuditLog log : logs) { %>
    <tr>
        <td class="nowrap mono small"><%= Esc.html(Dates.format(log.getAtTime(), "-")) %></td>
        <td class="nowrap"><%= Esc.html(log.getActor()) %></td>
        <td class="nowrap small"><%= Esc.html(Esc.nvl(log.getActorRole(), "-")) %></td>
        <td class="nowrap"><%= Esc.html(log.getActionLabel()) %></td>
        <td class="nowrap">
            <span class="badge st-<%= log.getResult() == null ? "ALLOW" : log.getResult().name() %>"><%= Esc.html(log.getResultLabel()) %></span>
        </td>
        <td class="nowrap small"><%= Esc.html(Esc.nvl(log.getTarget(), "-")) %></td>
        <td class="small"><%= Esc.html(Esc.nvl(log.getDetail(), "-")) %></td>
        <td class="nowrap mono small"><%= Esc.html(Esc.nvl(log.getIp(), "-")) %></td>
    </tr>
    <% } %>
    <% if (logs.isEmpty()) { %>
    <tr><td colspan="8" class="empty">没有符合条件的记录。</td></tr>
    <% } %>
    </tbody>
</table>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
