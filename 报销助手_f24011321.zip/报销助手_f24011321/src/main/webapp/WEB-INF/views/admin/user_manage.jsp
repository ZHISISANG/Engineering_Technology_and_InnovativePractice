<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "账号管理"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<User> users = (List<User>) request.getAttribute("users");
    String keyword = (String) request.getAttribute("keyword");
    UserService userService = svc.user();
%>

<h1>账号管理</h1>
<p class="muted small">
    管理员负责账号与角色。角色决定了这个人能维护什么：
    专员维护制度，业务员维护业务事实，两者互不代管；管理员本身进不了这两个维护模块。
</p>

<form class="filters" method="get" action="<%= ctx %>/admin/user/list">
    <div class="field">
        <label for="keyword">关键字（账号 / 姓名 / 部门 / 工号）</label>
        <input type="text" id="keyword" name="keyword" value="<%= Esc.attr(keyword) %>">
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/admin/user/list">清空条件</a>
    <a class="btn" href="<%= ctx %>/admin/user/edit?id=0">新增账号</a>
</form>

<table>
    <thead>
    <tr>
        <th class="nowrap">账号</th><th class="nowrap">姓名</th><th class="nowrap">角色</th>
        <th class="nowrap">部门</th><th class="nowrap">工号</th><th class="nowrap">状态</th>
        <th class="nowrap">创建时间</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <% for (User u : users) { %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(u.getUsername()) %></td>
        <td class="nowrap"><%= Esc.html(u.getDisplayName()) %></td>
        <td class="nowrap"><%= Esc.html(u.getRole().getLabel()) %></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(u.getDept(), "-")) %></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(u.getEmployeeNo(), "-")) %></td>
        <td class="nowrap">
            <% if (u.isEnabled()) { %>
            <span class="badge st-ACTIVE">启用</span>
            <% } else { %>
            <span class="badge st-REPEALED">停用</span>
            <% } %>
        </td>
        <td class="nowrap small muted"><%= Esc.html(userService.createdAtText(u)) %></td>
        <td class="nowrap">
            <div class="actions">
                <a class="btn mini ghost" href="<%= ctx %>/admin/user/edit?id=<%= u.getId() %>">修改</a>
                <form class="inline" method="post" action="<%= ctx %>/admin/user/reset"
                      onsubmit="return confirm('确认把该账号的口令重置为你输入的新口令？');">
                    <input type="hidden" name="id" value="<%= u.getId() %>">
                    <input class="mini-text" type="password" name="newPassword" placeholder="新口令（≥6位）" autocomplete="new-password">
                    <button class="mini" type="submit">重置口令</button>
                </form>
            </div>
        </td>
    </tr>
    <% } %>
    <% if (users.isEmpty()) { %>
    <tr><td colspan="8" class="empty">没有匹配的账号。</td></tr>
    <% } %>
    </tbody>
</table>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
