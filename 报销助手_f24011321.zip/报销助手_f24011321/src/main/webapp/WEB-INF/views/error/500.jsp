<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<% String pageTitle = "系统错误"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<div class="err-page">
    <div class="code">500</div>
    <h1>处理请求时出错</h1>
    <p>请求没有完成。具体异常已经写入 Tomcat 日志，请查看
        <span class="mono">logs\localhost.*.log</span> 与 <span class="mono">logs\catalina.*.log</span>。</p>
    <p class="small muted">页面上不展示异常堆栈，避免把内部结构暴露给使用者。</p>
    <p><a class="btn ghost" href="<%= ctx %>/home">返回首页</a></p>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
