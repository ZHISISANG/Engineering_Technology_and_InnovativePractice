<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<% String pageTitle = "资源不存在"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    String reason = (String) request.getAttribute("reason");
%>
<div class="err-page">
    <div class="code">404</div>
    <h1>没有找到这个资源</h1>
    <p><%= Esc.html(Esc.nvl(reason, "请求的页面或数据不存在。")) %></p>
    <p><a class="btn ghost" href="<%= ctx %>/home">返回首页</a></p>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
