<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<% String pageTitle = "访问被拒绝"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    String reason = (String) request.getAttribute("reason");
%>
<div class="err-page">
    <div class="code">403</div>
    <h1>访问被拒绝</h1>
    <p><%= Esc.html(Esc.nvl(reason, "当前账号没有访问该资源或功能的权限。")) %></p>
    <p class="small muted">
        这次尝试已经记入审计日志（结果标记为"拒绝"），管理员可在审计日志页按"越权访问被拒绝"筛选查看。
    </p>
    <p>
        <a class="btn ghost" href="<%= ctx %>/policy/list">返回制度查询</a>
        <a class="btn ghost" href="<%= ctx %>/mydoc/list">我的单据</a>
    </p>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
