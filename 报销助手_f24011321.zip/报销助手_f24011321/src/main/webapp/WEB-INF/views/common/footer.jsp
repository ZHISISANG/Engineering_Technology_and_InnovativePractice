<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
</main>
<footer class="foot">
    报销助手_f24011321 · 当前存储：<%= Esc.html(storage) %>
</footer>
</body>
</html>
