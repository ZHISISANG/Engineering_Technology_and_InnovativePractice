<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.*, java.math.BigDecimal, java.time.LocalDate" %>
<%@ page import="com.reimburse.model.*, com.reimburse.util.*, com.reimburse.web.*, com.reimburse.service.*" %>
<%--
    公共页头：顶栏 + 按角色生成的导航 + 一次性提示。
    使用方式：在页面顶部先定义 String pageTitle，再静态包含本文件。
    所有视图都放在 /WEB-INF/views 下，浏览器不能直接访问，只能由 Servlet 转发。
--%>
<%
    User me = Web.currentUser(request);
    String ctx = request.getContextPath();
    String uri = request.getRequestURI();
    Services svc = Web.services(request);
    String storage = svc == null ? "-" : svc.storageDescription();
    String flashMessage = (String) request.getAttribute("flashMessage");
    String flashType = (String) request.getAttribute("flashType");
%>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><%= Esc.html(pageTitle) %> · 报销助手_f24011321</title>
    <link rel="stylesheet" href="<%= ctx %>/css/style.css">
</head>
<body>
<div class="topbar">
    <div class="brand">报销助手<span class="ver">f24011321</span></div>
    <div class="who">
        <% if (me != null) { %>
        <%= Esc.html(me.getDisplayName()) %>（<%= Esc.html(me.getRole().getLabel()) %>）
        <% if (!Esc.blank(me.getDept())) { %> · <%= Esc.html(me.getDept()) %><% } %>
        <% if (!Esc.blank(me.getEmployeeNo())) { %> · 工号 <%= Esc.html(me.getEmployeeNo()) %><% } %>
        <% } %>
    </div>
</div>
<% if (me != null) { %>
<nav class="nav">
    <a href="<%= ctx %>/home"<%= Esc.active(uri.endsWith("/home")) %>>首页</a>
    <a href="<%= ctx %>/policy/list"<%= Esc.active(uri.contains("/policy/")) %>>制度查询</a>
    <a href="<%= ctx %>/mydoc/list"<%= Esc.active(uri.contains("/mydoc/")) %>>我的单据</a>
    <% if (me.getRole().canMaintainPolicy()) { %>
    <a href="<%= ctx %>/specialist/policy/list"<%= Esc.active(uri.contains("/specialist/")) %>>制度维护</a>
    <% } %>
    <% if (me.getRole().canMaintainDocument()) { %>
    <a href="<%= ctx %>/clerk/doc/list"<%= Esc.active(uri.contains("/clerk/")) %>>单据维护</a>
    <% } %>
    <% if (me.getRole().canAdminister()) { %>
    <a href="<%= ctx %>/admin/user/list"<%= Esc.active(uri.contains("/admin/user")) %>>账号管理</a>
    <a href="<%= ctx %>/admin/audit/list"<%= Esc.active(uri.contains("/admin/audit")) %>>审计日志</a>
    <% } %>
    <span class="spacer"></span>
    <a href="<%= ctx %>/profile"<%= Esc.active(uri.endsWith("/profile")) %>>修改口令</a>
    <a href="<%= ctx %>/logout">退出</a>
</nav>
<% } %>
<main class="wrap">
<% if (flashMessage != null) { %>
<div class="flash <%= "ok".equals(flashType) ? "ok" : "err" %>"><%= Esc.html(flashMessage) %></div>
<% } %>
