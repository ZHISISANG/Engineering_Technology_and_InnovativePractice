<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "修改本人登录口令"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>

<h1>修改本人登录口令</h1>

<div class="card" style="max-width:520px">
    <form method="post" action="<%= ctx %>/profile">
        <div class="form-row">
            <label for="oldPassword">原口令</label>
            <input type="password" id="oldPassword" name="oldPassword" autocomplete="current-password">
        </div>
        <div class="form-row">
            <label for="newPassword">新口令</label>
            <input type="password" id="newPassword" name="newPassword" autocomplete="new-password">
            <div class="hint">至少 6 位。口令以 PBKDF2-SHA256 加盐派生后保存，数据库中不存明文。</div>
        </div>
        <button type="submit">保存</button>
    </form>
</div>

<div class="card" style="max-width:520px">
    <h3>当前账号信息</h3>
    <table>
        <tr><th style="width:120px">账号</th><td class="mono"><%= Esc.html(me.getUsername()) %></td></tr>
        <tr><th>姓名</th><td><%= Esc.html(me.getDisplayName()) %></td></tr>
        <tr><th>角色</th><td><%= Esc.html(me.getRole().getLabel()) %></td></tr>
        <tr><th>部门</th><td><%= Esc.html(Esc.nvl(me.getDept(), "-")) %></td></tr>
        <tr><th>工号</th><td><%= Esc.html(Esc.nvl(me.getEmployeeNo(), "-")) %></td></tr>
    </table>
</div>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
