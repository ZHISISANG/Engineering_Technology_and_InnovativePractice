<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="com.reimburse.util.Esc" %>
<%
    String ctx = request.getContextPath();
    String error = (String) request.getAttribute("error");
    String username = (String) request.getAttribute("username");
%>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>登录 · 报销助手_f24011321</title>
    <link rel="stylesheet" href="<%= ctx %>/css/style.css">
</head>
<body>
<div class="login-page">
    <div class="login-box">
        <h1>报销助手</h1>
        <div class="sub">制度自助查询 · 本人单据状态查询</div>

        <% if (error != null) { %>
        <div class="flash err"><%= Esc.html(error) %></div>
        <% } %>

        <form method="post" action="<%= ctx %>/login">
            <div class="form-row">
                <label for="username">账号</label>
                <input type="text" id="username" name="username" autocomplete="username"
                       value="<%= Esc.attr(username) %>" autofocus>
            </div>
            <div class="form-row">
                <label for="password">口令</label>
                <input type="password" id="password" name="password" autocomplete="current-password">
            </div>
            <button type="submit">登录</button>
        </form>

        <div class="tip">
            首次启动会自动初始化演示账号与演示制度，账号清单见项目 README。
        </div>
    </div>
</div>
</body>
</html>
