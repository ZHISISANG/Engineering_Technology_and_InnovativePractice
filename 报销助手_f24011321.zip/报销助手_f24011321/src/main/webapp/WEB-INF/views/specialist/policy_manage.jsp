<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "制度维护"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<Policy> policies = (List<Policy>) request.getAttribute("policies");
    String keyword = (String) request.getAttribute("keyword");
    String today = (String) request.getAttribute("today");
    PolicyService policyService = svc.policy();
%>

<h1>制度维护</h1>
<p class="muted small">
    你是制度专员，负责制度的准确性。<strong>制度的修改不会直接影响已登记的单据</strong>：
    单据记的是当时的业务依据，制度改版只影响后续查询与登记时取到的依据。
    同一编码下同一时刻只保留一个生效版本，发布新版本会把旧版本自动置为废止。
</p>

<form class="filters" method="get" action="<%= ctx %>/specialist/policy/list">
    <div class="field">
        <label for="keyword">关键字（名称 / 编码 / 正文）</label>
        <input type="text" id="keyword" name="keyword" value="<%= Esc.attr(keyword) %>">
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/specialist/policy/list">清空条件</a>
    <a class="btn" href="<%= ctx %>/specialist/policy/edit?id=0">新增制度</a>
</form>

<table>
    <thead>
    <tr>
        <th class="nowrap">编码</th><th>制度名称</th><th class="nowrap">分类</th><th class="nowrap">适用费用</th>
        <th class="nowrap">版本</th><th class="nowrap">状态</th><th class="nowrap">有效期</th>
        <th>对员工可见性</th><th class="nowrap">更新</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <% for (Policy p : policies) { %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(p.getCode()) %></td>
        <td><%= Esc.html(p.getTitle()) %></td>
        <td class="nowrap"><%= Esc.html(p.getCategory()) %></td>
        <td class="nowrap"><%= Esc.html(ExpenseType.labelsOf(p.getAppliesTo())) %></td>
        <td class="nowrap"><%= Esc.html(p.getVersionLabel()) %></td>
        <td class="nowrap"><span class="badge st-<%= p.getStatus().name() %>"><%= Esc.html(p.getStatus().getLabel()) %></span></td>
        <td class="nowrap small"><%= Esc.html(p.getEffectiveLabel()) %></td>
        <td class="small"><%= Esc.html(policyService.effectivenessText(p)) %></td>
        <td class="nowrap small muted">
            <%= Esc.html(Esc.nvl(p.getUpdatedBy(), "-")) %><br>
            <%= Esc.html(Dates.format(p.getUpdatedAt(), "-")) %>
        </td>
        <td class="nowrap">
            <div class="actions">
                <a class="btn mini ghost" href="<%= ctx %>/specialist/policy/edit?id=<%= p.getId() %>">修订</a>
                <% if (p.getStatus() == PolicyStatus.DRAFT) { %>
                <form class="inline" method="post" action="<%= ctx %>/specialist/policy/publish">
                    <input type="hidden" name="id" value="<%= p.getId() %>">
                    <span class="stack">
                        <input class="mini-date" type="date" name="effectiveFrom" value="<%= Esc.attr(today) %>" title="生效日期">
                        <input class="mini-date" type="date" name="effectiveTo" title="失效日期（留空表示长期有效）">
                        <button class="mini" type="submit">发布</button>
                    </span>
                </form>
                <% } %>
                <% if (p.getStatus() == PolicyStatus.ACTIVE) { %>
                <form class="inline" method="post" action="<%= ctx %>/specialist/policy/repeal">
                    <input type="hidden" name="id" value="<%= p.getId() %>">
                    <button class="mini danger" type="submit">废止</button>
                </form>
                <% } %>
            </div>
        </td>
    </tr>
    <% } %>
    <% if (policies.isEmpty()) { %>
    <tr><td colspan="10" class="empty">没有匹配的制度。</td></tr>
    <% } %>
    </tbody>
</table>

<p class="small muted">
    提示：状态为"草稿"的版本需要先填生效日期再发布；发布后该编码下其它生效版本会自动废止，
    避免员工同时搜到两条口径不一致的制度。
</p>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
