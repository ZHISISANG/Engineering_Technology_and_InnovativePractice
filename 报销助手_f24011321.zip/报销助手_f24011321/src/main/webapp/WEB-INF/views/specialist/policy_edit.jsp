<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "制度编辑"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    Policy policy = (Policy) request.getAttribute("policy");
    Boolean isNew = (Boolean) request.getAttribute("isNew");
    ExpenseType[] types = (ExpenseType[]) request.getAttribute("types");
    List<Policy> versions = (List<Policy>) request.getAttribute("versions");
    String error = (String) request.getAttribute("error");
    String today = (String) request.getAttribute("today");
    boolean creating = Boolean.TRUE.equals(isNew);
    boolean editable = creating || policy.getStatus() != PolicyStatus.ACTIVE;
%>

<h1><%= creating ? "新增制度" : "修订制度" %></h1>

<% if (error != null) { %>
<div class="flash err"><%= Esc.html(error) %></div>
<% } %>

<% if (!creating) { %>
<div class="card">
    <table>
        <tr><th style="width:110px">制度编码</th><td class="mono"><%= Esc.html(policy.getCode()) %></td></tr>
        <tr><th>制度名称</th><td><%= Esc.html(policy.getTitle()) %></td></tr>
        <tr><th>分类</th><td><%= Esc.html(policy.getCategory()) %></td></tr>
        <tr><th>适用费用类型</th><td><%= Esc.html(ExpenseType.labelsOf(policy.getAppliesTo())) %></td></tr>
        <tr><th>当前版本</th><td><%= Esc.html(policy.getVersionLabel()) %>
            <span class="badge st-<%= policy.getStatus().name() %>"><%= Esc.html(policy.getStatus().getLabel()) %></span></td></tr>
        <tr><th>有效期</th><td><%= Esc.html(policy.getEffectiveLabel()) %></td></tr>
    </table>
    <p class="hint muted small">
        编码、名称、分类、适用范围在修订时保持不变；保存后会生成
        <%= Esc.html("V" + (policy.getVersion() + 1)) %> 草稿，发布后才对员工生效，旧版本内容仍保留可追溯。
    </p>
</div>

<h3>版本链</h3>
<table>
    <thead><tr><th class="nowrap">版本</th><th class="nowrap">状态</th><th class="nowrap">有效期</th>
        <th class="nowrap">更新人</th><th class="nowrap">更新时间</th><th>修订说明</th></tr></thead>
    <tbody>
    <% for (Policy v : versions) { %>
    <tr<%= v.getId() == policy.getId() ? " style=\"background:#f7f9fb\"" : "" %>>
        <td class="nowrap"><%= Esc.html(v.getVersionLabel()) %></td>
        <td class="nowrap"><span class="badge st-<%= v.getStatus().name() %>"><%= Esc.html(v.getStatus().getLabel()) %></span></td>
        <td class="nowrap small"><%= Esc.html(v.getEffectiveLabel()) %></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(v.getUpdatedBy(), "-")) %></td>
        <td class="nowrap small muted"><%= Esc.html(Dates.format(v.getUpdatedAt(), "-")) %></td>
        <td class="small"><%= Esc.html(Esc.nvl(v.getChangeNote(), "-")) %></td>
    </tr>
    <% } %>
    </tbody>
</table>
<% } %>

<h2><%= creating ? "填写制度内容" : "填写修订后的正文" %></h2>

<% if (creating) { %>
<form method="post" action="<%= ctx %>/specialist/policy/save">
    <input type="hidden" name="id" value="0">
    <div class="card">
        <div class="form-row">
            <label for="code">制度编码</label>
            <input type="text" id="code" name="code" value="<%= Esc.attr(policy == null ? null : policy.getCode()) %>" placeholder="例如 CS-2026-07">
            <div class="hint">只能包含字母、数字和短横线。编码重复时系统会提示改用"修订"。</div>
        </div>
        <div class="form-row">
            <label for="title">制度名称</label>
            <input type="text" id="title" name="title" style="width:420px"
                   value="<%= Esc.attr(policy == null ? null : policy.getTitle()) %>" placeholder="例如 差旅费报销管理办法">
        </div>
        <div class="form-row">
            <label for="category">分类</label>
            <input type="text" id="category" name="category" value="<%= Esc.attr(policy == null ? null : policy.getCategory()) %>" placeholder="例如 报销标准">
        </div>
        <div class="form-row">
            <label>适用费用类型</label>
            <div class="checks">
                <% for (ExpenseType t : types) { %>
                <label><input type="checkbox" name="appliesTo" value="<%= t.name() %>"
                    <%= policy != null && ExpenseType.matches(policy.getAppliesTo(), t) ? "checked" : "" %>>
                    <%= Esc.html(t.getLabel()) %></label>
                <% } %>
            </div>
            <div class="hint">不勾选表示对全部费用类型通用。</div>
        </div>
        <div class="form-row">
            <label>生效日期 / 失效日期</label>
            <input class="mini-date" type="date" name="effectiveFrom" value="<%= Esc.attr(policy == null || policy.getEffectiveFrom() == null ? today : policy.getEffectiveFrom().toString()) %>">
            <input class="mini-date" type="date" name="effectiveTo" value="<%= policy == null || policy.getEffectiveTo() == null ? "" : policy.getEffectiveTo().toString() %>">
            <div class="hint">失效日期留空表示长期有效。生效日期晚于今天时，员工暂时查不到这条制度。</div>
        </div>
        <div class="form-row">
            <label><input type="checkbox" name="publishNow"> 立即发布</label>
            <div class="hint">不勾选则保存为草稿，之后在列表里点"发布"并填生效日期。</div>
        </div>
    </div>
<% } else { %>
<form method="post" action="<%= ctx %>/specialist/policy/save">
    <input type="hidden" name="id" value="<%= policy.getId() %>">
<% } %>

    <div class="form-row">
        <label for="content">制度正文</label>
        <textarea id="content" name="content" placeholder="按条款分行书写，例如：&#10;第一条 适用范围&#10;……"><%= Esc.html(policy == null ? null : policy.getContent()) %></textarea>
        <div class="hint">正文最多 4000 字，超长建议拆分为多条制度。</div>
    </div>
    <div class="form-row">
        <label for="changeNote">修订说明</label>
        <input type="text" id="changeNote" name="changeNote" style="width:520px"
               value="<%= Esc.attr(policy == null ? null : policy.getChangeNote()) %>"
               placeholder="例如：住宿费标准上调；新增伙食补助包干条款">
        <div class="hint">写清楚改了什么，员工和后续接手的人都要靠这句话理解版本差异。</div>
    </div>

    <% if (editable) { %>
    <button type="submit"><%= creating ? "保存" : "保存为新版本草稿" %></button>
    <% } else { %>
    <p class="muted">该版本处于生效状态，不能直接改写已发布的正文。保存将生成新的草稿版本，发布后替换。</p>
    <button type="submit">保存为新版本草稿</button>
    <% } %>
    <a class="btn ghost" href="<%= ctx %>/specialist/policy/list">返回列表</a>
</form>

<% if (!creating && policy.getStatus() == PolicyStatus.DRAFT) { %>
<h2>发布这个草稿</h2>
<div class="card">
    <form method="post" action="<%= ctx %>/specialist/policy/publish">
        <input type="hidden" name="id" value="<%= policy.getId() %>">
        <div class="filters">
            <div class="field">
                <label for="pubFrom">生效日期</label>
                <input type="date" id="pubFrom" name="effectiveFrom" value="<%= Esc.attr(today) %>">
            </div>
            <div class="field">
                <label for="pubTo">失效日期</label>
                <input type="date" id="pubTo" name="effectiveTo">
            </div>
            <div class="field">
                <label for="pubNote">发布说明</label>
                <input type="text" id="pubNote" name="changeNote" style="width:320px" placeholder="可留空">
            </div>
            <button type="submit">发布</button>
        </div>
        <div class="hint">发布后本版本转为"生效"，同一编码下其它生效版本会自动置为"废止"。</div>
    </form>
</div>
<% } %>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
