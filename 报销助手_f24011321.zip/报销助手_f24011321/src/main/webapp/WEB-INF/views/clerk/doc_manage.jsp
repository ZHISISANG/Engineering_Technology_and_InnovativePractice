<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "单据维护"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<Document> documents = (List<Document>) request.getAttribute("documents");
    Map<DocStatus, Integer> statusCounts = (Map<DocStatus, Integer>) request.getAttribute("statusCounts");
    BigDecimal totalAmount = (BigDecimal) request.getAttribute("totalAmount");
    String status = (String) request.getAttribute("status");
    String keyword = (String) request.getAttribute("keyword");
    String owner = (String) request.getAttribute("owner");
    DocStatus[] statuses = (DocStatus[]) request.getAttribute("statuses");
    DocumentService docService = svc.document();
    String kwEnc = Esc.blank(keyword) ? "" : java.net.URLEncoder.encode(keyword, "UTF-8");
    String ownerEnc = Esc.blank(owner) ? "" : java.net.URLEncoder.encode(owner, "UTF-8");
%>

<h1>单据维护</h1>
<p class="muted small">
    你是业务员，负责维护<strong>业务事实</strong>：登记单据、修正金额与事由、推进状态。
    制度的解释权不在这里——单据上引用的制度编码必须从当前有效制度中选。
    归属员工只在登记时确定，之后不可更改；已支付或已驳回的单据事实冻结。
</p>

<%
    // 保留当前的关键字/归属员工条件，供状态筛选链接复用
    StringBuilder keep = new StringBuilder();
    if (!Esc.blank(kwEnc)) {
        keep.append("&keyword=").append(kwEnc);
    }
    if (!Esc.blank(ownerEnc)) {
        keep.append("&owner=").append(ownerEnc);
    }
    String keepParams = keep.toString();
%>
<p class="small">
    筛选状态：
    <a href="<%= ctx %>/clerk/doc/list<%= keepParams.isEmpty() ? "" : "?" + keepParams.substring(1) %>">
        <%= Esc.blank(status) ? "<strong>全部</strong>" : "全部" %>
    </a>
    <% for (DocStatus s : statuses) {
        boolean on = s.name().equalsIgnoreCase(Esc.nvl(status, ""));
        String label = Esc.html(s.getLabel()) + " " + statusCounts.get(s);
    %>
    · <a href="<%= ctx %>/clerk/doc/list?status=<%= s.name() %><%= keepParams %>">
        <%= on ? "<strong>" + label + "</strong>" : label %>
    </a>
    <% } %>
</p>

<form class="filters" method="get" action="<%= ctx %>/clerk/doc/list">
    <% if (!Esc.blank(status)) { %><input type="hidden" name="status" value="<%= Esc.attr(status) %>"><% } %>
    <div class="field">
        <label for="keyword">关键字（单据号 / 事由 / 费用类型）</label>
        <input type="text" id="keyword" name="keyword" value="<%= Esc.attr(keyword) %>">
    </div>
    <div class="field">
        <label for="owner">归属员工</label>
        <input type="text" id="owner" name="owner" value="<%= Esc.attr(owner) %>" placeholder="姓名或单据号片段">
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/clerk/doc/list">清空条件</a>
    <a class="btn" href="<%= ctx %>/clerk/doc/edit?id=0">登记单据</a>
</form>

<p class="small muted">
    命中 <strong><%= documents.size() %></strong> 张，金额合计 <strong><%= totalAmount.toPlainString() %></strong> 元。
</p>

<table>
    <thead>
    <tr>
        <th class="nowrap">单据号</th><th class="nowrap">归属员工</th><th class="nowrap">费用类型</th>
        <th class="num">金额(元)</th><th class="nowrap">发生日期</th><th class="nowrap">状态</th>
        <th>事由</th><th class="nowrap">制度依据</th><th class="nowrap">最后更新</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <% for (Document d : documents) {
        List<DocStatus> options = docService.nextOptions(d);
    %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(d.getDocNo()) %></td>
        <td class="nowrap"><%= Esc.html(d.getOwnerName()) %></td>
        <td class="nowrap"><%= Esc.html(d.getExpenseType().getLabel()) %></td>
        <td class="num"><%= d.getAmount().toPlainString() %></td>
        <td class="nowrap"><%= Esc.html(Dates.format(d.getOccurredOn(), "-")) %></td>
        <td class="nowrap"><span class="badge st-<%= d.getStatus().name() %>"><%= Esc.html(d.getStatus().getLabel()) %></span></td>
        <td class="small"><%= Esc.html(Esc.truncate(Esc.nvl(d.getReason(), "-"), 40)) %></td>
        <td class="nowrap small mono"><%= Esc.html(Esc.nvl(d.getPolicyCode(), "—")) %></td>
        <td class="nowrap small muted"><%= Esc.html(Dates.format(d.getUpdatedAt(), "-")) %><br>
            <%= Esc.html(Esc.nvl(d.getHandler(), "-")) %></td>
        <td class="nowrap">
            <div class="actions">
                <% if (!d.getStatus().isFinal()) { %>
                <a class="btn mini ghost" href="<%= ctx %>/clerk/doc/edit?id=<%= d.getId() %>">修正事实</a>
                <% } %>
                <% if (options.isEmpty()) { %>
                <span class="muted small">终态</span>
                <% } else { %>
                <form class="inline" method="post" action="<%= ctx %>/clerk/doc/progress">
                    <input type="hidden" name="id" value="<%= d.getId() %>">
                    <span class="stack">
                        <select class="mini-select" name="target">
                            <% for (DocStatus opt : options) { %>
                            <option value="<%= opt.name() %>"><%= Esc.html(opt.getLabel()) %></option>
                            <% } %>
                        </select>
                        <input class="mini-text" type="text" name="note" placeholder="经办说明（驳回必填）">
                        <button class="mini" type="submit">推进状态</button>
                    </span>
                </form>
                <% } %>
            </div>
        </td>
    </tr>
    <% } %>
    <% if (documents.isEmpty()) { %>
    <tr><td colspan="10" class="empty">没有符合条件的单据。</td></tr>
    <% } %>
    </tbody>
</table>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
