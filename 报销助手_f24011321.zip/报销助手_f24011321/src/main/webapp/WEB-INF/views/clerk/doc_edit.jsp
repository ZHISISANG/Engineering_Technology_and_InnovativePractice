<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "登记 / 修正单据"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    Document doc = (Document) request.getAttribute("doc");
    Boolean isNew = (Boolean) request.getAttribute("isNew");
    List<User> owners = (List<User>) request.getAttribute("owners");
    ExpenseType[] types = (ExpenseType[]) request.getAttribute("types");
    List<Policy> effectivePolicies = (List<Policy>) request.getAttribute("effectivePolicies");
    String suggestedPolicy = (String) request.getAttribute("suggestedPolicy");
    Long selectedOwnerId = (Long) request.getAttribute("selectedOwnerId");
    String error = (String) request.getAttribute("error");
    String today = (String) request.getAttribute("today");
    boolean creating = Boolean.TRUE.equals(isNew);
    boolean frozen = !creating && doc.getStatus().isFinal();
    String amountText = doc == null || doc.getAmount() == null ? "" : doc.getAmount().toPlainString();
%>

<h1><%= creating ? "登记报销单据" : "修正单据业务事实" %></h1>

<% if (error != null) { %>
<div class="flash err"><%= Esc.html(error) %></div>
<% } %>

<% if (frozen) { %>
<div class="flash err">
    单据 <%= Esc.html(doc.getDocNo()) %> 当前状态为"<%= Esc.html(doc.getStatus().getLabel()) %>"，
    属于终态，业务事实已冻结，不能再修改。如需更正，请登记新的单据。
</div>
<% } %>

<div class="card">
    <table>
        <% if (!creating) { %>
        <tr><th style="width:130px">单据号</th><td class="mono"><%= Esc.html(doc.getDocNo()) %></td></tr>
        <tr><th>归属员工</th><td><%= Esc.html(doc.getOwnerName()) %>
            <span class="hint muted">（登记后不可更改）</span></td></tr>
        <tr><th>当前状态</th><td><span class="badge st-<%= doc.getStatus().name() %>"><%= Esc.html(doc.getStatus().getLabel()) %></span></td></tr>
        <tr><th>登记时间</th><td><%= Esc.html(Dates.format(doc.getCreatedAt(), "-")) %></td></tr>
        <% } else { %>
        <tr><th style="width:130px">说明</th><td>
            登记后系统自动生成单据号（BX + 发生年月 + 三位流水），初始状态为"已提交"。
        </td></tr>
        <% } %>
    </table>
</div>

<form method="post" action="<%= ctx %>/clerk/doc/save">
    <input type="hidden" name="id" value="<%= creating ? 0 : doc.getId() %>">

    <div class="card">
        <div class="form-row">
            <label for="ownerId">归属员工</label>
            <% if (creating) { %>
            <select id="ownerId" name="ownerId">
                <option value="0">— 请选择 —</option>
                <% for (User u : owners) {
                    boolean on = selectedOwnerId != null && selectedOwnerId.longValue() == u.getId();
                %>
                <option value="<%= u.getId() %>"<%= on ? " selected" : "" %>>
                    <%= Esc.html(u.getDisplayName()) %><%= Esc.blank(u.getEmployeeNo()) ? "" : "（" + Esc.html(u.getEmployeeNo()) + "）" %>
                    · <%= Esc.html(u.getDept() == null ? "-" : u.getDept()) %>
                </option>
                <% } %>
            </select>
            <div class="hint">单据状态只有这位员工本人能查；业务员可以维护事实，但改不了归属。</div>
            <% } else { %>
            <input type="text" value="<%= Esc.attr(doc.getOwnerName()) %>" disabled>
            <% } %>
        </div>

        <div class="form-row">
            <label for="expenseType">费用类型</label>
            <select id="expenseType" name="expenseType">
                <% for (ExpenseType t : types) { %>
                <option value="<%= t.name() %>"<%= doc != null && doc.getExpenseType() == t ? " selected" : "" %>><%= Esc.html(t.getLabel()) %></option>
                <% } %>
            </select>
        </div>

        <div class="form-row">
            <label for="amount">金额（元）</label>
            <input type="number" id="amount" name="amount" step="0.01" min="0.01" value="<%= Esc.attr(amountText) %>">
            <div class="hint">必须大于 0，单张单据上限 1000000 元。</div>
        </div>

        <div class="form-row">
            <label for="occurredOn">费用发生日期</label>
            <input type="date" id="occurredOn" name="occurredOn"
                   value="<%= Esc.attr(doc == null || doc.getOccurredOn() == null ? today : doc.getOccurredOn().toString()) %>">
            <div class="hint">不能晚于今天。</div>
        </div>

        <div class="form-row">
            <label for="policyCode">制度依据</label>
            <select id="policyCode" name="policyCode">
                <option value="">— 不引用制度 —</option>
                <%
                    // 已有单据用其登记的制度；新单据用按费用类型带出的建议值
                    String currentPolicy = doc != null && doc.getPolicyCode() != null
                            ? doc.getPolicyCode() : Esc.nvl(suggestedPolicy, "");
                    for (Policy p : effectivePolicies) {
                        String code = p.getCode();
                        boolean on = code != null && code.equalsIgnoreCase(currentPolicy);
                %>
                <option value="<%= Esc.attr(code) %>"<%= on ? " selected" : "" %>>
                    <%= Esc.html(code) %> · <%= Esc.html(p.getTitle()) %>
                </option>
                <% } %>
            </select>
            <div class="hint">
                只列当前有效制度。切换费用类型后系统会给出建议依据
                <%= Esc.blank(suggestedPolicy) ? "（当前无匹配制度）" : "（" + Esc.html(suggestedPolicy) + "）" %>，
                留空则由系统按费用类型自动带出。
            </div>
        </div>

        <div class="form-row">
            <label for="reason">费用事由</label>
            <textarea id="reason" name="reason" style="min-height:90px"
                      placeholder="说明业务背景，例如：赴上海参加行业展会，往返高铁及住宿 3 晚"><%= Esc.html(doc == null ? null : doc.getReason()) %></textarea>
        </div>
    </div>

    <% if (!frozen) { %>
    <button type="submit"><%= creating ? "登记单据" : "保存业务事实" %></button>
    <% } %>
    <a class="btn ghost" href="<%= ctx %>/clerk/doc/list">返回单据列表</a>
</form>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
