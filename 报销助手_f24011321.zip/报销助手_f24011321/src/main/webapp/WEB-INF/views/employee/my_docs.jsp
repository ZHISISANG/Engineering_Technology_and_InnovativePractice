<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "我的单据"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<Document> documents = (List<Document>) request.getAttribute("documents");
    Map<DocStatus, Integer> statusCounts = (Map<DocStatus, Integer>) request.getAttribute("statusCounts");
    BigDecimal totalAmount = (BigDecimal) request.getAttribute("totalAmount");
    String status = (String) request.getAttribute("status");
    String keyword = (String) request.getAttribute("keyword");
    DocStatus[] statuses = (DocStatus[]) request.getAttribute("statuses");
%>

<h1>我的单据</h1>
<p class="muted small">
    这个列表由服务端按归属人过滤：只返回归属人为 <strong><%= Esc.html(me.getDisplayName()) %></strong> 的单据。
    状态与经办说明来自业务员维护的业务事实，你只能查看，不能修改。
</p>

<%
    String kwEnc = Esc.blank(keyword) ? "" : java.net.URLEncoder.encode(keyword, "UTF-8");
    int totalCount = statusCounts == null ? 0 : sumOf(statusCounts);
%>
<p class="small">
    筛选状态：
    <a href="<%= ctx %>/mydoc/list<%= Esc.blank(kwEnc) ? "" : "?keyword=" + kwEnc %>">
        <%= Esc.blank(status) ? "<strong>全部 " + totalCount + "</strong>" : "全部 " + totalCount %>
    </a>
    <% for (DocStatus s : statuses) {
        boolean on = s.name().equalsIgnoreCase(Esc.nvl(status, ""));
        String label = Esc.html(s.getLabel()) + " " + statusCounts.get(s);
    %>
    · <a href="<%= ctx %>/mydoc/list?status=<%= s.name() %><%= Esc.blank(kwEnc) ? "" : "&keyword=" + kwEnc %>">
        <%= on ? "<strong>" + label + "</strong>" : label %>
    </a>
    <% } %>
</p>

<form class="filters" method="get" action="<%= ctx %>/mydoc/list">
    <% if (!Esc.blank(status)) { %><input type="hidden" name="status" value="<%= Esc.attr(status) %>"><% } %>
    <div class="field">
        <label for="keyword">关键字（单据号 / 事由 / 费用类型）</label>
        <input type="text" id="keyword" name="keyword" value="<%= Esc.attr(keyword) %>" placeholder="例如：差旅 或 BX">
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/mydoc/list">清空条件</a>
</form>

<p class="small muted">
    命中 <strong><%= documents.size() %></strong> 张，金额合计 <strong><%= totalAmount.toPlainString() %></strong> 元。
</p>

<table>
    <thead>
    <tr>
        <th class="nowrap">单据号</th><th class="nowrap">费用类型</th><th class="num">金额(元)</th>
        <th class="nowrap">发生日期</th><th class="nowrap">当前状态</th><th class="nowrap">经办人</th>
        <th>经办说明</th><th class="nowrap">最后更新</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <% for (Document d : documents) { %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(d.getDocNo()) %></td>
        <td class="nowrap"><%= Esc.html(d.getExpenseType().getLabel()) %></td>
        <td class="num"><%= d.getAmount().toPlainString() %></td>
        <td class="nowrap"><%= Esc.html(Dates.format(d.getOccurredOn(), "-")) %></td>
        <td class="nowrap"><span class="badge st-<%= d.getStatus().name() %>"><%= Esc.html(d.getStatus().getLabel()) %></span></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(d.getHandler(), "待受理")) %></td>
        <td><%= Esc.html(Esc.truncate(Esc.nvl(d.getHandleNote(), "-"), 50)) %></td>
        <td class="nowrap small muted"><%= Esc.html(Dates.format(d.getUpdatedAt(), "-")) %></td>
        <td class="nowrap"><a href="<%= ctx %>/mydoc/detail?id=<%= d.getId() %>">查看状态</a></td>
    </tr>
    <% } %>
    <% if (documents.isEmpty()) { %>
    <tr><td colspan="9" class="empty">没有符合条件的单据。</td></tr>
    <% } %>
    </tbody>
</table>

<%!
    /** "全部"那个标签要显示总张数 */
    private int sumOf(java.util.Map<DocStatus, Integer> counts) {
        int total = 0;
        for (Integer v : counts.values()) {
            total += v == null ? 0 : v.intValue();
        }
        return total;
    }
%>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
