<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "制度详情"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    Policy policy = (Policy) request.getAttribute("policy");
%>

<h1><%= Esc.html(policy.getTitle()) %></h1>
<p>
    <span class="badge st-ACTIVE">当前有效</span>
    <span class="mono small"><%= Esc.html(policy.getCode()) %></span>
    <span class="small muted">· <%= Esc.html(policy.getVersionLabel()) %></span>
</p>

<div class="card">
    <table>
        <tr><th style="width:110px">制度编码</th><td class="mono"><%= Esc.html(policy.getCode()) %></td></tr>
        <tr><th>版本</th><td><%= Esc.html(policy.getVersionLabel()) %></td></tr>
        <tr><th>分类</th><td><%= Esc.html(policy.getCategory()) %></td></tr>
        <tr><th>适用费用类型</th><td><%= Esc.html(ExpenseType.labelsOf(policy.getAppliesTo())) %></td></tr>
        <tr><th>有效期</th><td><%= Esc.html(policy.getEffectiveLabel()) %></td></tr>
        <tr><th>发布人</th><td><%= Esc.html(Esc.nvl(policy.getIssuer(), "-")) %></td></tr>
        <tr><th>最后更新</th><td><%= Esc.html(Dates.format(policy.getUpdatedAt(), "-")) %></td></tr>
        <tr><th>修订说明</th><td><%= Esc.html(Esc.nvl(policy.getChangeNote(), "-")) %></td></tr>
    </table>
</div>

<h2>制度正文</h2>
<div class="card pre-line"><%= Esc.html(policy.getContent()) %></div>

<p>
    <a class="btn ghost" href="<%= ctx %>/policy/list">返回制度查询</a>
    <a class="btn ghost" href="<%= ctx %>/mydoc/list">查询我的单据状态</a>
</p>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
