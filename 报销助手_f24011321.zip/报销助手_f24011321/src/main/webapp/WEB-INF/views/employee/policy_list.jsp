<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "制度自助查询"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    List<Policy> policies = (List<Policy>) request.getAttribute("policies");
    String keyword = (String) request.getAttribute("keyword");
    String type = (String) request.getAttribute("type");
    ExpenseType[] types = (ExpenseType[]) request.getAttribute("types");
    String today = (String) request.getAttribute("today");
%>

<h1>制度自助查询</h1>
<p class="muted small">
    这里只列出<strong>当前有效</strong>的制度：状态为"生效"，且今天（<%= Esc.html(today) %>）落在有效期内。
    草稿、未到生效日期、已过有效期、已废止的版本都不会出现。
</p>

<form class="filters" method="get" action="<%= ctx %>/policy/list">
    <div class="field">
        <label for="keyword">关键字（名称 / 编码 / 正文）</label>
        <input type="text" id="keyword" name="keyword" value="<%= Esc.attr(keyword) %>" placeholder="例如：住宿 或 差旅">
    </div>
    <div class="field">
        <label for="type">费用类型</label>
        <select id="type" name="type">
            <option value="">全部类型</option>
            <% for (ExpenseType t : types) { %>
            <option value="<%= t.name() %>"<%= t.name().equalsIgnoreCase(Esc.nvl(type, "")) ? " selected" : "" %>><%= Esc.html(t.getLabel()) %></option>
            <% } %>
        </select>
    </div>
    <button type="submit">查询</button>
    <a class="btn ghost" href="<%= ctx %>/policy/list">清空条件</a>
</form>

<p class="small muted">命中 <strong><%= policies.size() %></strong> 条有效制度。</p>

<table>
    <thead>
    <tr>
        <th class="nowrap">编码</th><th>制度名称</th><th class="nowrap">分类</th>
        <th class="nowrap">适用费用</th><th class="nowrap">版本</th><th class="nowrap">有效期</th>
        <th class="nowrap">发布人</th><th class="nowrap">操作</th>
    </tr>
    </thead>
    <tbody>
    <% for (Policy p : policies) { %>
    <tr>
        <td class="nowrap mono"><%= Esc.html(p.getCode()) %></td>
        <td><%= Esc.html(p.getTitle()) %></td>
        <td class="nowrap"><%= Esc.html(p.getCategory()) %></td>
        <td class="nowrap"><%= Esc.html(ExpenseType.labelsOf(p.getAppliesTo())) %></td>
        <td class="nowrap"><%= Esc.html(p.getVersionLabel()) %></td>
        <td class="nowrap"><%= Esc.html(p.getEffectiveLabel()) %></td>
        <td class="nowrap"><%= Esc.html(Esc.nvl(p.getIssuer(), "-")) %></td>
        <td class="nowrap"><a href="<%= ctx %>/policy/detail?id=<%= p.getId() %>">查看</a></td>
    </tr>
    <% } %>
    <% if (policies.isEmpty()) { %>
    <tr><td colspan="8" class="empty">没有匹配的有效制度。可以换个关键字，或清空条件看全部。</td></tr>
    <% } %>
    </tbody>
</table>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
