<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<% String pageTitle = "单据状态详情"; %>
<%@ include file="/WEB-INF/views/common/head.jsp" %>
<%
    Document doc = (Document) request.getAttribute("doc");
    Policy policyRef = (Policy) request.getAttribute("policyRef");
    Boolean policyRefEffective = (Boolean) request.getAttribute("policyRefEffective");
    List<AuditLog> history = (List<AuditLog>) request.getAttribute("history");
%>

<h1>单据 <%= Esc.html(doc.getDocNo()) %></h1>
<p>
    <span class="badge st-<%= doc.getStatus().name() %>"><%= Esc.html(doc.getStatus().getLabel()) %></span>
    <span class="small muted">归属人 <%= Esc.html(doc.getOwnerName()) %>（本人）</span>
</p>

<div class="card">
    <table>
        <tr><th style="width:120px">单据号</th><td class="mono"><%= Esc.html(doc.getDocNo()) %></td></tr>
        <tr><th>费用类型</th><td><%= Esc.html(doc.getExpenseType().getLabel()) %></td></tr>
        <tr><th>金额</th><td><strong><%= doc.getAmount().toPlainString() %></strong> 元</td></tr>
        <tr><th>费用发生日期</th><td><%= Esc.html(Dates.format(doc.getOccurredOn(), "-")) %></td></tr>
        <tr><th>费用事由</th><td><%= Esc.html(Esc.nvl(doc.getReason(), "-")) %></td></tr>
        <tr><th>当前状态</th><td><span class="badge st-<%= doc.getStatus().name() %>"><%= Esc.html(doc.getStatus().getLabel()) %></span></td></tr>
        <tr><th>经办人</th><td><%= Esc.html(Esc.nvl(doc.getHandler(), "尚未受理")) %></td></tr>
        <tr><th>经办说明</th><td><%= Esc.html(Esc.nvl(doc.getHandleNote(), "-")) %></td></tr>
        <tr><th>登记时间</th><td><%= Esc.html(Dates.format(doc.getCreatedAt(), "-")) %></td></tr>
        <tr><th>最后更新</th><td><%= Esc.html(Dates.format(doc.getUpdatedAt(), "-")) %></td></tr>
    </table>
</div>

<h2>办理轨迹</h2>
<p class="small muted">以下记录来自系统审计日志中针对这张单据的操作，按时间正序排列。</p>
<ul class="timeline">
    <% for (AuditLog log : history) { %>
    <li>
        <div class="t"><%= Esc.html(Dates.format(log.getAtTime(), "-")) %> · <%= Esc.html(log.getActor()) %>
            （<%= Esc.html(Esc.nvl(log.getActorRole(), "-")) %>）· <%= Esc.html(log.getActionLabel()) %></div>
        <div><%= Esc.html(Esc.nvl(log.getDetail(), "-")) %></div>
    </li>
    <% } %>
    <% if (history.isEmpty()) { %>
    <li><div class="muted">暂无操作记录。</div></li>
    <% } %>
</ul>

<h2>报销依据的制度</h2>
<% if (policyRef == null) { %>
<div class="card">
    <p class="muted">这张单据没有关联制度编码。通常意味着登记时该费用类型还没有生效的制度可依据。</p>
</div>
<% } else { %>
<div class="card">
    <p>
        <strong><%= Esc.html(policyRef.getTitle()) %></strong>
        <span class="mono small"><%= Esc.html(policyRef.getCode()) %></span>
        <span class="small muted">· <%= Esc.html(policyRef.getVersionLabel()) %></span>
        <% if (Boolean.TRUE.equals(policyRefEffective)) { %>
        <span class="badge st-ACTIVE">当前有效</span>
        <% } else { %>
        <span class="badge st-REPEALED">当前不适用</span>
        <% } %>
    </p>
    <p class="small muted">
        有效期 <%= Esc.html(policyRef.getEffectiveLabel()) %>
        <% if (!Boolean.TRUE.equals(policyRefEffective)) { %>
        —— 该版本目前不在有效期内或已废止，这里只作为当时登记的业务依据留痕；员工自助查询页不会列出它。
        <% } %>
    </p>
    <% if (Boolean.TRUE.equals(policyRefEffective)) { %>
    <p><a class="btn ghost" href="<%= ctx %>/policy/detail?id=<%= policyRef.getId() %>">查看制度正文</a></p>
    <% } %>
</div>
<% } %>

<p>
    <a class="btn ghost" href="<%= ctx %>/mydoc/list">返回我的单据</a>
</p>

<%@ include file="/WEB-INF/views/common/footer.jsp" %>
