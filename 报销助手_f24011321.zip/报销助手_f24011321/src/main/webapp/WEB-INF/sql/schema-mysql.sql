-- 同一套表结构的 MySQL 8 版本，供换库参考。
-- 换库时需要：把 h2-2.2.220.jar 换成对应 JDBC 驱动，并改 app.properties 里的
-- storage=jdbc 与 jdbc.url / jdbc.user / jdbc.password（见 JdbcStore.readConfig）。
-- 本项目交付时跑的是 H2，本文件未做过 MySQL 实机验证，仅作结构对照。

CREATE TABLE IF NOT EXISTS rmb_user (
    id            BIGINT       NOT NULL AUTO_INCREMENT,
    username      VARCHAR(64)  NOT NULL,
    password_hash VARCHAR(256) NOT NULL,
    salt          VARCHAR(64)  NOT NULL,
    display_name  VARCHAR(64)  NOT NULL,
    role          VARCHAR(16)  NOT NULL,
    dept          VARCHAR(64),
    employee_no   VARCHAR(32),
    enabled       TINYINT(1)   NOT NULL DEFAULT 1,
    created_at    DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_user_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rmb_policy (
    id              BIGINT        NOT NULL AUTO_INCREMENT,
    code            VARCHAR(32)   NOT NULL,
    title           VARCHAR(128)  NOT NULL,
    category        VARCHAR(32)   NOT NULL,
    applies_to      VARCHAR(64),
    content         VARCHAR(4000) NOT NULL,
    version         INT           NOT NULL,
    status          VARCHAR(16)   NOT NULL,
    effective_from  DATE          NULL,
    effective_to    DATE          NULL,
    issuer          VARCHAR(64)   NOT NULL,
    updated_by      VARCHAR(64)   NOT NULL,
    updated_at      DATETIME      NOT NULL,
    prev_version_id BIGINT        NULL,
    change_note     VARCHAR(500)  NULL,
    PRIMARY KEY (id),
    KEY idx_policy_code (code),
    KEY idx_policy_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rmb_document (
    id           BIGINT        NOT NULL AUTO_INCREMENT,
    doc_no       VARCHAR(32)   NOT NULL,
    owner_id     BIGINT        NOT NULL,
    owner_name   VARCHAR(64)   NOT NULL,
    expense_type VARCHAR(32)   NOT NULL,
    amount       DECIMAL(12,2) NOT NULL,
    occurred_on  DATE          NOT NULL,
    reason       VARCHAR(500)  NOT NULL,
    status       VARCHAR(16)   NOT NULL,
    handler      VARCHAR(64)   NULL,
    handle_note  VARCHAR(500)  NULL,
    policy_code  VARCHAR(32)   NULL,
    created_at   DATETIME      NOT NULL,
    updated_at   DATETIME      NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_doc_no (doc_no),
    KEY idx_doc_owner (owner_id),
    KEY idx_doc_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rmb_audit (
    id         BIGINT       NOT NULL AUTO_INCREMENT,
    at_time    DATETIME     NOT NULL,
    actor      VARCHAR(64)  NOT NULL,
    actor_role VARCHAR(16)  NOT NULL,
    action     VARCHAR(32)  NOT NULL,
    target     VARCHAR(128) NULL,
    result     VARCHAR(8)   NOT NULL,
    detail     VARCHAR(500) NULL,
    ip         VARCHAR(64)  NULL,
    PRIMARY KEY (id),
    KEY idx_audit_actor (actor),
    KEY idx_audit_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
