package com.reimburse.store;

/** 账号仓储。 */
public interface UserRepository {

    java.util.List<com.reimburse.model.User> findAll();

    com.reimburse.model.User findById(long id);

    com.reimburse.model.User findByUsername(String username);

    /** id <= 0 视为新增并回填 id，否则按 id 更新。 */
    void save(com.reimburse.model.User user);

    long count();
}
