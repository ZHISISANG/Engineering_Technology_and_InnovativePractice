package com.reimburse.store.jdbc;

import com.reimburse.model.AuditAction;
import com.reimburse.model.AuditLog;
import com.reimburse.model.AuditResult;
import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.PolicyStatus;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.store.AppConfig;
import com.reimburse.store.AuditRepository;
import com.reimburse.store.DocumentRepository;
import com.reimburse.store.PolicyRepository;
import com.reimburse.store.SeedData;
import com.reimburse.store.Store;
import com.reimburse.store.UserRepository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * H2 嵌入式数据库版。启动时执行 WEB-INF/sql/schema-h2.sql 建表，数据落在 dataDir 下的 .mv.db 文件里。
 * 与文件版的差别只体现在这一层：Service、Servlet、JSP 完全共用。
 */
public class JdbcStore implements Store {

    private static final java.util.logging.Logger LOG =
            java.util.logging.Logger.getLogger(JdbcStore.class.getName());

    private final Jdbc db;

    public JdbcStore(AppConfig config, String schemaSql) {
        this.db = new Jdbc(config.getJdbcUrl(), config.getJdbcUser(), config.getJdbcPassword());
        if (this.db.isReadOnly()) {
            LOG.warning("数据库以只读方式打开：" + config.getJdbcUrl()
                    + "。查询可用，但登记单据、推进状态、写审计都会失败。"
                    + "常见原因：库文件被其它进程占用、所在目录不可写，或运行环境限制了写权限。"
                    + "确认没有其它进程占用后，可删除库文件让其重建（演示数据会自动重新初始化）。");
        }
        this.db.executeScript(schemaSql);
    }

    @Override
    public UserRepository users() {
        return new JdbcUserRepository();
    }

    @Override
    public PolicyRepository policies() {
        return new JdbcPolicyRepository();
    }

    @Override
    public DocumentRepository documents() {
        return new JdbcDocumentRepository();
    }

    @Override
    public AuditRepository audits() {
        return new JdbcAuditRepository();
    }

    @Override
    public String describe() {
        return "H2 嵌入式数据库 · " + db.getUrl();
    }

    @Override
    public void initAndSeedIfEmpty() {
        SeedData.seedIfEmpty(this);
    }

    // ================= 账号 =================

    private final class JdbcUserRepository implements UserRepository {

        private static final String COLUMNS =
                "id, username, password_hash, salt, display_name, role, dept, employee_no, enabled, created_at";

        @Override
        public List<User> findAll() {
            return db.query("SELECT " + COLUMNS + " FROM rmb_user ORDER BY id", JdbcUserRepository::map);
        }

        @Override
        public User findById(long id) {
            return db.queryOne("SELECT " + COLUMNS + " FROM rmb_user WHERE id = ?", JdbcUserRepository::map, id);
        }

        @Override
        public User findByUsername(String username) {
            if (username == null) {
                return null;
            }
            return db.queryOne("SELECT " + COLUMNS + " FROM rmb_user WHERE LOWER(username) = LOWER(?)",
                    JdbcUserRepository::map, username);
        }

        @Override
        public void save(User user) {
            if (user.getId() <= 0) {
                long id = db.insert("INSERT INTO rmb_user"
                                + " (username, password_hash, salt, display_name, role, dept, employee_no, enabled, created_at)"
                                + " VALUES (?,?,?,?,?,?,?,?,?)",
                        user.getUsername(), user.getPasswordHash(), user.getSalt(), user.getDisplayName(),
                        user.getRole() == null ? null : user.getRole().name(), user.getDept(), user.getEmployeeNo(),
                        Boolean.valueOf(user.isEnabled()),
                        user.getCreatedAt() == null ? LocalDateTime.now() : user.getCreatedAt());
                user.setId(id);
            } else {
                db.update("UPDATE rmb_user SET username=?, password_hash=?, salt=?, display_name=?, role=?,"
                                + " dept=?, employee_no=?, enabled=? WHERE id=?",
                        user.getUsername(), user.getPasswordHash(), user.getSalt(), user.getDisplayName(),
                        user.getRole() == null ? null : user.getRole().name(), user.getDept(), user.getEmployeeNo(),
                        Boolean.valueOf(user.isEnabled()), user.getId());
            }
        }

        @Override
        public long count() {
            Long n = db.queryOne("SELECT COUNT(*) AS c FROM rmb_user",
                    rs -> Long.valueOf(rs.getLong("c")));
            return n == null ? 0L : n.longValue();
        }

        private static User map(ResultSet rs) throws SQLException {
            User u = new User();
            u.setId(rs.getLong("id"));
            u.setUsername(rs.getString("username"));
            u.setPasswordHash(rs.getString("password_hash"));
            u.setSalt(rs.getString("salt"));
            u.setDisplayName(rs.getString("display_name"));
            u.setRole(Enum.valueOf(Role.class, rs.getString("role")));
            u.setDept(rs.getString("dept"));
            u.setEmployeeNo(rs.getString("employee_no"));
            u.setEnabled(rs.getBoolean("enabled"));
            u.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));
            return u;
        }
    }

    // ================= 制度 =================

    private final class JdbcPolicyRepository implements PolicyRepository {

        private static final String COLUMNS = "id, code, title, category, applies_to, content, version, status,"
                + " effective_from, effective_to, issuer, updated_by, updated_at, prev_version_id, change_note";

        @Override
        public List<Policy> findAll() {
            return db.query("SELECT " + COLUMNS + " FROM rmb_policy ORDER BY code, version DESC",
                    JdbcPolicyRepository::map);
        }

        @Override
        public Policy findById(long id) {
            return db.queryOne("SELECT " + COLUMNS + " FROM rmb_policy WHERE id = ?", JdbcPolicyRepository::map, id);
        }

        @Override
        public List<Policy> findByCode(String code) {
            if (code == null) {
                return java.util.Collections.emptyList();
            }
            return db.query("SELECT " + COLUMNS + " FROM rmb_policy WHERE LOWER(code) = LOWER(?) ORDER BY version DESC",
                    JdbcPolicyRepository::map, code);
        }

        @Override
        public void save(Policy p) {
            if (p.getId() <= 0) {
                long id = db.insert("INSERT INTO rmb_policy (code, title, category, applies_to, content, version,"
                                + " status, effective_from, effective_to, issuer, updated_by, updated_at,"
                                + " prev_version_id, change_note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        p.getCode(), p.getTitle(), p.getCategory(), p.getAppliesTo(), p.getContent(),
                        Integer.valueOf(p.getVersion()), p.getStatus() == null ? null : p.getStatus().name(),
                        p.getEffectiveFrom(), p.getEffectiveTo(), p.getIssuer(), p.getUpdatedBy(),
                        p.getUpdatedAt() == null ? LocalDateTime.now() : p.getUpdatedAt(),
                        p.getPrevVersionId(), p.getChangeNote());
                p.setId(id);
            } else {
                db.update("UPDATE rmb_policy SET code=?, title=?, category=?, applies_to=?, content=?, version=?,"
                                + " status=?, effective_from=?, effective_to=?, issuer=?, updated_by=?, updated_at=?,"
                                + " prev_version_id=?, change_note=? WHERE id=?",
                        p.getCode(), p.getTitle(), p.getCategory(), p.getAppliesTo(), p.getContent(),
                        Integer.valueOf(p.getVersion()), p.getStatus() == null ? null : p.getStatus().name(),
                        p.getEffectiveFrom(), p.getEffectiveTo(), p.getIssuer(), p.getUpdatedBy(),
                        p.getUpdatedAt() == null ? LocalDateTime.now() : p.getUpdatedAt(),
                        p.getPrevVersionId(), p.getChangeNote(), p.getId());
            }
        }

        @Override
        public long count() {
            Long n = db.queryOne("SELECT COUNT(*) AS c FROM rmb_policy", rs -> Long.valueOf(rs.getLong("c")));
            return n == null ? 0L : n.longValue();
        }

        private static Policy map(ResultSet rs) throws SQLException {
            Policy p = new Policy();
            p.setId(rs.getLong("id"));
            p.setCode(rs.getString("code"));
            p.setTitle(rs.getString("title"));
            p.setCategory(rs.getString("category"));
            p.setAppliesTo(rs.getString("applies_to"));
            p.setContent(rs.getString("content"));
            p.setVersion(rs.getInt("version"));
            p.setStatus(Enum.valueOf(PolicyStatus.class, rs.getString("status")));
            p.setEffectiveFrom(rs.getObject("effective_from", LocalDate.class));
            p.setEffectiveTo(rs.getObject("effective_to", LocalDate.class));
            p.setIssuer(rs.getString("issuer"));
            p.setUpdatedBy(rs.getString("updated_by"));
            p.setUpdatedAt(rs.getObject("updated_at", LocalDateTime.class));
            p.setPrevVersionId(Jdbc.nullableLong(rs, "prev_version_id"));
            p.setChangeNote(rs.getString("change_note"));
            return p;
        }
    }

    // ================= 单据 =================

    private final class JdbcDocumentRepository implements DocumentRepository {

        private static final String COLUMNS = "id, doc_no, owner_id, owner_name, expense_type, amount, occurred_on,"
                + " reason, status, handler, handle_note, policy_code, created_at, updated_at";

        @Override
        public List<Document> findAll() {
            return db.query("SELECT " + COLUMNS + " FROM rmb_document ORDER BY occurred_on DESC, id DESC",
                    JdbcDocumentRepository::map);
        }

        @Override
        public Document findById(long id) {
            return db.queryOne("SELECT " + COLUMNS + " FROM rmb_document WHERE id = ?",
                    JdbcDocumentRepository::map, id);
        }

        @Override
        public List<Document> findByOwner(long ownerId) {
            return db.query("SELECT " + COLUMNS + " FROM rmb_document WHERE owner_id = ?"
                            + " ORDER BY occurred_on DESC, id DESC",
                    JdbcDocumentRepository::map, ownerId);
        }

        @Override
        public void save(Document d) {
            if (d.getId() <= 0) {
                long id = db.insert("INSERT INTO rmb_document (doc_no, owner_id, owner_name, expense_type, amount,"
                                + " occurred_on, reason, status, handler, handle_note, policy_code, created_at, updated_at)"
                                + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        d.getDocNo(), Long.valueOf(d.getOwnerId()), d.getOwnerName(),
                        d.getExpenseType() == null ? null : d.getExpenseType().name(), d.getAmount(),
                        d.getOccurredOn(), d.getReason(), d.getStatus() == null ? null : d.getStatus().name(),
                        d.getHandler(), d.getHandleNote(), d.getPolicyCode(),
                        d.getCreatedAt() == null ? LocalDateTime.now() : d.getCreatedAt(),
                        d.getUpdatedAt() == null ? LocalDateTime.now() : d.getUpdatedAt());
                d.setId(id);
            } else {
                db.update("UPDATE rmb_document SET doc_no=?, owner_id=?, owner_name=?, expense_type=?, amount=?,"
                                + " occurred_on=?, reason=?, status=?, handler=?, handle_note=?, policy_code=?,"
                                + " updated_at=? WHERE id=?",
                        d.getDocNo(), Long.valueOf(d.getOwnerId()), d.getOwnerName(),
                        d.getExpenseType() == null ? null : d.getExpenseType().name(), d.getAmount(),
                        d.getOccurredOn(), d.getReason(), d.getStatus() == null ? null : d.getStatus().name(),
                        d.getHandler(), d.getHandleNote(), d.getPolicyCode(),
                        d.getUpdatedAt() == null ? LocalDateTime.now() : d.getUpdatedAt(), d.getId());
            }
        }

        @Override
        public long count() {
            Long n = db.queryOne("SELECT COUNT(*) AS c FROM rmb_document", rs -> Long.valueOf(rs.getLong("c")));
            return n == null ? 0L : n.longValue();
        }

        private static Document map(ResultSet rs) throws SQLException {
            Document d = new Document();
            d.setId(rs.getLong("id"));
            d.setDocNo(rs.getString("doc_no"));
            d.setOwnerId(rs.getLong("owner_id"));
            d.setOwnerName(rs.getString("owner_name"));
            d.setExpenseType(Enum.valueOf(ExpenseType.class, rs.getString("expense_type")));
            d.setAmount(rs.getBigDecimal("amount"));
            d.setOccurredOn(rs.getObject("occurred_on", LocalDate.class));
            d.setReason(rs.getString("reason"));
            d.setStatus(Enum.valueOf(DocStatus.class, rs.getString("status")));
            d.setHandler(rs.getString("handler"));
            d.setHandleNote(rs.getString("handle_note"));
            d.setPolicyCode(rs.getString("policy_code"));
            d.setCreatedAt(rs.getObject("created_at", LocalDateTime.class));
            d.setUpdatedAt(rs.getObject("updated_at", LocalDateTime.class));
            return d;
        }
    }

    // ================= 审计 =================

    private final class JdbcAuditRepository implements AuditRepository {

        private static final String COLUMNS =
                "id, at_time, actor, actor_role, action, target, result, detail, ip";

        @Override
        public void append(AuditLog a) {
            db.insert("INSERT INTO rmb_audit (at_time, actor, actor_role, action, target, result, detail, ip)"
                            + " VALUES (?,?,?,?,?,?,?,?)",
                    a.getAtTime() == null ? LocalDateTime.now() : a.getAtTime(),
                    a.getActor(), a.getActorRole(),
                    a.getAction() == null ? null : a.getAction().name(),
                    a.getTarget(),
                    a.getResult() == null ? null : a.getResult().name(),
                    a.getDetail(), a.getIp());
        }

        @Override
        public List<AuditLog> findAll() {
            return db.query("SELECT " + COLUMNS + " FROM rmb_audit ORDER BY id DESC", JdbcAuditRepository::map);
        }

        @Override
        public List<AuditLog> recent(int limit) {
            return db.query("SELECT " + COLUMNS + " FROM rmb_audit ORDER BY id DESC LIMIT ?",
                    JdbcAuditRepository::map, Integer.valueOf(limit));
        }

        @Override
        public long count() {
            Long n = db.queryOne("SELECT COUNT(*) AS c FROM rmb_audit", rs -> Long.valueOf(rs.getLong("c")));
            return n == null ? 0L : n.longValue();
        }

        private static AuditLog map(ResultSet rs) throws SQLException {
            AuditLog a = new AuditLog();
            a.setId(rs.getLong("id"));
            a.setAtTime(rs.getObject("at_time", LocalDateTime.class));
            a.setActor(rs.getString("actor"));
            a.setActorRole(rs.getString("actor_role"));
            a.setAction(Enum.valueOf(AuditAction.class, rs.getString("action")));
            a.setTarget(rs.getString("target"));
            a.setResult(Enum.valueOf(AuditResult.class, rs.getString("result")));
            a.setDetail(rs.getString("detail"));
            a.setIp(rs.getString("ip"));
            return a;
        }
    }
}
