package com.reimburse.store.file;

import com.reimburse.model.AuditAction;
import com.reimburse.model.AuditLog;
import com.reimburse.model.AuditResult;
import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.PolicyStatus;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.store.AppConfig;
import com.reimburse.store.AuditRepository;
import com.reimburse.store.DocumentRepository;
import com.reimburse.store.PolicyRepository;
import com.reimburse.store.SeedData;
import com.reimburse.store.Store;
import com.reimburse.store.StoreException;
import com.reimburse.store.UserRepository;
import com.reimburse.util.Dates;
import com.reimburse.util.Json;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * 文件持久化版：数据目录下 users.json / policies.json / documents.json / audits.json 四个文本文件。
 * 没有外部依赖，用编辑器就能直接查看数据；代价是没有事务与并发控制，不适合真实并发写入场景。
 */
public class FileStore implements Store {

    private final Path dataDir;
    private final JsonTable userTable;
    private final JsonTable policyTable;
    private final JsonTable documentTable;
    private final JsonTable auditTable;

    public FileStore(AppConfig config) {
        this.dataDir = Paths.get(config.getDataDir()).toAbsolutePath().normalize();
        this.userTable = new JsonTable(dataDir, "users");
        this.policyTable = new JsonTable(dataDir, "policies");
        this.documentTable = new JsonTable(dataDir, "documents");
        this.auditTable = new JsonTable(dataDir, "audits");
    }

    @Override
    public UserRepository users() {
        return new FileUserRepository();
    }

    @Override
    public PolicyRepository policies() {
        return new FilePolicyRepository();
    }

    @Override
    public DocumentRepository documents() {
        return new FileDocumentRepository();
    }

    @Override
    public AuditRepository audits() {
        return new FileAuditRepository();
    }

    @Override
    public String describe() {
        return "文件持久化（JSON）· " + dataDir;
    }

    @Override
    public void initAndSeedIfEmpty() {
        SeedData.seedIfEmpty(this);
    }

    // ================= 账号 =================

    private final class FileUserRepository implements UserRepository {

        @Override
        public List<User> findAll() {
            List<User> list = new ArrayList<User>();
            for (Map<String, Object> row : userTable.all()) {
                list.add(toUser(row));
            }
            list.sort(Comparator.comparingLong(User::getId));
            return list;
        }

        @Override
        public User findById(long id) {
            Map<String, Object> row = userTable.byId(id);
            return row == null ? null : toUser(row);
        }

        @Override
        public User findByUsername(String username) {
            if (username == null) {
                return null;
            }
            for (Map<String, Object> row : userTable.all()) {
                if (username.equalsIgnoreCase(Json.str(row.get("username"), ""))) {
                    return toUser(row);
                }
            }
            return null;
        }

        @Override
        public void save(User user) {
            Map<String, Object> row = toRow(user);
            if (user.getId() <= 0) {
                user.setId(Json.lng(userTable.insert(row).get("id"), 0));
            } else {
                userTable.update(row);
            }
        }

        @Override
        public long count() {
            return userTable.count();
        }
    }

    private static User toUser(Map<String, Object> row) {
        User u = new User();
        u.setId(Json.lng(row.get("id"), 0));
        u.setUsername(Json.str(row.get("username")));
        u.setPasswordHash(Json.str(row.get("passwordHash")));
        u.setSalt(Json.str(row.get("salt")));
        u.setDisplayName(Json.str(row.get("displayName")));
        u.setRole(enumOf(Role.class, Json.str(row.get("role")), Role.EMPLOYEE));
        u.setDept(Json.str(row.get("dept")));
        u.setEmployeeNo(Json.str(row.get("employeeNo")));
        u.setEnabled(Json.bool(row.get("enabled"), true));
        u.setCreatedAt(Dates.parseDateTime(Json.str(row.get("createdAt"))));
        return u;
    }

    private static Map<String, Object> toRow(User u) {
        Map<String, Object> row = Json.obj();
        if (u.getId() > 0) {
            row.put("id", Long.valueOf(u.getId()));
        }
        row.put("username", u.getUsername());
        row.put("passwordHash", u.getPasswordHash());
        row.put("salt", u.getSalt());
        row.put("displayName", u.getDisplayName());
        row.put("role", u.getRole() == null ? null : u.getRole().name());
        row.put("dept", u.getDept());
        row.put("employeeNo", u.getEmployeeNo());
        row.put("enabled", Boolean.valueOf(u.isEnabled()));
        row.put("createdAt", Dates.format(u.getCreatedAt()));
        return row;
    }

    // ================= 制度 =================

    private final class FilePolicyRepository implements PolicyRepository {

        @Override
        public List<Policy> findAll() {
            List<Policy> list = new ArrayList<Policy>();
            for (Map<String, Object> row : policyTable.all()) {
                list.add(toPolicy(row));
            }
            return list;
        }

        @Override
        public Policy findById(long id) {
            Map<String, Object> row = policyTable.byId(id);
            return row == null ? null : toPolicy(row);
        }

        @Override
        public List<Policy> findByCode(String code) {
            List<Policy> list = new ArrayList<Policy>();
            if (code == null) {
                return list;
            }
            for (Map<String, Object> row : policyTable.all()) {
                if (code.equalsIgnoreCase(Json.str(row.get("code"), ""))) {
                    list.add(toPolicy(row));
                }
            }
            list.sort(Comparator.comparingInt(Policy::getVersion).reversed());
            return list;
        }

        @Override
        public void save(Policy policy) {
            Map<String, Object> row = toRow(policy);
            if (policy.getId() <= 0) {
                policy.setId(Json.lng(policyTable.insert(row).get("id"), 0));
            } else {
                policyTable.update(row);
            }
        }

        @Override
        public long count() {
            return policyTable.count();
        }
    }

    private static Policy toPolicy(Map<String, Object> row) {
        Policy p = new Policy();
        p.setId(Json.lng(row.get("id"), 0));
        p.setCode(Json.str(row.get("code")));
        p.setTitle(Json.str(row.get("title")));
        p.setCategory(Json.str(row.get("category")));
        p.setAppliesTo(Json.str(row.get("appliesTo")));
        p.setContent(Json.str(row.get("content")));
        p.setVersion(Json.integer(row.get("version"), 1));
        p.setStatus(enumOf(PolicyStatus.class, Json.str(row.get("status")), PolicyStatus.DRAFT));
        p.setEffectiveFrom(Dates.parseDate(Json.str(row.get("effectiveFrom"))));
        p.setEffectiveTo(Dates.parseDate(Json.str(row.get("effectiveTo"))));
        p.setIssuer(Json.str(row.get("issuer")));
        p.setUpdatedBy(Json.str(row.get("updatedBy")));
        p.setUpdatedAt(Dates.parseDateTime(Json.str(row.get("updatedAt"))));
        p.setPrevVersionId(Json.lngOrNull(row.get("prevVersionId")));
        p.setChangeNote(Json.str(row.get("changeNote")));
        return p;
    }

    private static Map<String, Object> toRow(Policy p) {
        Map<String, Object> row = Json.obj();
        if (p.getId() > 0) {
            row.put("id", Long.valueOf(p.getId()));
        }
        row.put("code", p.getCode());
        row.put("title", p.getTitle());
        row.put("category", p.getCategory());
        row.put("appliesTo", p.getAppliesTo());
        row.put("content", p.getContent());
        row.put("version", Integer.valueOf(p.getVersion()));
        row.put("status", p.getStatus() == null ? null : p.getStatus().name());
        row.put("effectiveFrom", Dates.format(p.getEffectiveFrom()));
        row.put("effectiveTo", Dates.format(p.getEffectiveTo()));
        row.put("issuer", p.getIssuer());
        row.put("updatedBy", p.getUpdatedBy());
        row.put("updatedAt", Dates.format(p.getUpdatedAt()));
        row.put("prevVersionId", p.getPrevVersionId());
        row.put("changeNote", p.getChangeNote());
        return row;
    }

    // ================= 单据 =================

    private final class FileDocumentRepository implements DocumentRepository {

        @Override
        public List<Document> findAll() {
            List<Document> list = new ArrayList<Document>();
            for (Map<String, Object> row : documentTable.all()) {
                list.add(toDocument(row));
            }
            list.sort(Comparator.comparing(Document::getOccurredOn,
                    Comparator.nullsLast(Comparator.reverseOrder())));
            return list;
        }

        @Override
        public Document findById(long id) {
            Map<String, Object> row = documentTable.byId(id);
            return row == null ? null : toDocument(row);
        }

        @Override
        public List<Document> findByOwner(long ownerId) {
            List<Document> list = new ArrayList<Document>();
            for (Document d : findAll()) {
                if (d.getOwnerId() == ownerId) {
                    list.add(d);
                }
            }
            return list;
        }

        @Override
        public void save(Document document) {
            Map<String, Object> row = toRow(document);
            if (document.getId() <= 0) {
                document.setId(Json.lng(documentTable.insert(row).get("id"), 0));
            } else {
                documentTable.update(row);
            }
        }

        @Override
        public long count() {
            return documentTable.count();
        }
    }

    private static Document toDocument(Map<String, Object> row) {
        Document d = new Document();
        d.setId(Json.lng(row.get("id"), 0));
        d.setDocNo(Json.str(row.get("docNo")));
        d.setOwnerId(Json.lng(row.get("ownerId"), 0));
        d.setOwnerName(Json.str(row.get("ownerName")));
        d.setExpenseType(enumOf(ExpenseType.class, Json.str(row.get("expenseType")), ExpenseType.OTHER));
        d.setAmount(Json.decimal(row.get("amount"), BigDecimal.ZERO));
        d.setOccurredOn(Dates.parseDate(Json.str(row.get("occurredOn"))));
        d.setReason(Json.str(row.get("reason")));
        d.setStatus(enumOf(DocStatus.class, Json.str(row.get("status")), DocStatus.SUBMITTED));
        d.setHandler(Json.str(row.get("handler")));
        d.setHandleNote(Json.str(row.get("handleNote")));
        d.setPolicyCode(Json.str(row.get("policyCode")));
        d.setCreatedAt(Dates.parseDateTime(Json.str(row.get("createdAt"))));
        d.setUpdatedAt(Dates.parseDateTime(Json.str(row.get("updatedAt"))));
        return d;
    }

    private static Map<String, Object> toRow(Document d) {
        Map<String, Object> row = Json.obj();
        if (d.getId() > 0) {
            row.put("id", Long.valueOf(d.getId()));
        }
        row.put("docNo", d.getDocNo());
        row.put("ownerId", Long.valueOf(d.getOwnerId()));
        row.put("ownerName", d.getOwnerName());
        row.put("expenseType", d.getExpenseType() == null ? null : d.getExpenseType().name());
        row.put("amount", d.getAmount());
        row.put("occurredOn", Dates.format(d.getOccurredOn()));
        row.put("reason", d.getReason());
        row.put("status", d.getStatus() == null ? null : d.getStatus().name());
        row.put("handler", d.getHandler());
        row.put("handleNote", d.getHandleNote());
        row.put("policyCode", d.getPolicyCode());
        row.put("createdAt", Dates.format(d.getCreatedAt()));
        row.put("updatedAt", Dates.format(d.getUpdatedAt()));
        return row;
    }

    // ================= 审计 =================

    private final class FileAuditRepository implements AuditRepository {

        @Override
        public void append(AuditLog log) {
            auditTable.insert(toRow(log));
        }

        @Override
        public List<AuditLog> findAll() {
            List<AuditLog> list = new ArrayList<AuditLog>();
            for (Map<String, Object> row : auditTable.all()) {
                list.add(toAudit(row));
            }
            return list;
        }

        @Override
        public List<AuditLog> recent(int limit) {
            List<AuditLog> list = findAll();
            list.sort(Comparator.comparingLong(AuditLog::getId).reversed());
            return list.size() <= limit ? list : new ArrayList<AuditLog>(list.subList(0, limit));
        }

        @Override
        public long count() {
            return auditTable.count();
        }
    }

    private static AuditLog toAudit(Map<String, Object> row) {
        AuditLog a = new AuditLog();
        a.setId(Json.lng(row.get("id"), 0));
        a.setAtTime(Dates.parseDateTime(Json.str(row.get("atTime"))));
        a.setActor(Json.str(row.get("actor")));
        a.setActorRole(Json.str(row.get("actorRole")));
        a.setAction(enumOf(AuditAction.class, Json.str(row.get("action")), null));
        a.setTarget(Json.str(row.get("target")));
        a.setResult(enumOf(AuditResult.class, Json.str(row.get("result")), AuditResult.ALLOW));
        a.setDetail(Json.str(row.get("detail")));
        a.setIp(Json.str(row.get("ip")));
        return a;
    }

    private static Map<String, Object> toRow(AuditLog a) {
        Map<String, Object> row = Json.obj();
        if (a.getId() > 0) {
            row.put("id", Long.valueOf(a.getId()));
        }
        row.put("atTime", Dates.format(a.getAtTime() == null ? LocalDateTime.now() : a.getAtTime()));
        row.put("actor", a.getActor());
        row.put("actorRole", a.getActorRole());
        row.put("action", a.getAction() == null ? null : a.getAction().name());
        row.put("target", a.getTarget());
        row.put("result", a.getResult() == null ? null : a.getResult().name());
        row.put("detail", a.getDetail());
        row.put("ip", a.getIp());
        return row;
    }

    // ================= 公共 =================

    private static <E extends Enum<E>> E enumOf(Class<E> type, String name, E dft) {
        if (name == null || name.trim().isEmpty()) {
            return dft;
        }
        try {
            return Enum.valueOf(type, name.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new StoreException("数据文件中出现未知的 " + type.getSimpleName() + " 取值：" + name);
        }
    }
}
