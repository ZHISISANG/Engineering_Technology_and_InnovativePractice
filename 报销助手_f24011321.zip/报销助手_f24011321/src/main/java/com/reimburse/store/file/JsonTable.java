package com.reimburse.store.file;

import com.reimburse.store.StoreException;
import com.reimburse.util.Json;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 以 JSON 数组文件为后端的一张表。
 *
 * 取舍：数据量是几十条量级（制度、单据），所以整表读入内存、变更后整表重写。
 * 这样实现简单、文件任何时刻都是完整 JSON，代价是并发写会串行化（下面用 lock 保证）。
 * 写盘先落临时文件再改名，避免写到一半断电留下半截文件。
 */
final class JsonTable {

    private final Path file;
    private final String name;
    private final Object lock = new Object();

    private List<Map<String, Object>> rows;
    private long nextId = 1;

    JsonTable(Path dir, String name) {
        this.name = name;
        this.file = dir.resolve(name + ".json");
    }

    List<Map<String, Object>> all() {
        synchronized (lock) {
            loadIfNeeded();
            List<Map<String, Object>> copy = new ArrayList<Map<String, Object>>(rows.size());
            for (Map<String, Object> row : rows) {
                copy.add(new LinkedHashMap<String, Object>(row));
            }
            return copy;
        }
    }

    Map<String, Object> byId(long id) {
        synchronized (lock) {
            loadIfNeeded();
            for (Map<String, Object> row : rows) {
                if (Json.lng(row.get("id"), 0) == id) {
                    return new LinkedHashMap<String, Object>(row);
                }
            }
            return null;
        }
    }

    Map<String, Object> insert(Map<String, Object> row) {
        synchronized (lock) {
            loadIfNeeded();
            row.put("id", Long.valueOf(nextId++));
            rows.add(row);
            flush();
            return row;
        }
    }

    void update(Map<String, Object> row) {
        synchronized (lock) {
            loadIfNeeded();
            long id = Json.lng(row.get("id"), 0);
            for (int i = 0; i < rows.size(); i++) {
                if (Json.lng(rows.get(i).get("id"), 0) == id) {
                    rows.set(i, row);
                    flush();
                    return;
                }
            }
            throw new StoreException(name + " 中不存在 id=" + id + " 的记录，无法更新");
        }
    }

    long count() {
        synchronized (lock) {
            loadIfNeeded();
            return rows.size();
        }
    }

    private void loadIfNeeded() {
        if (rows != null) {
            return;
        }
        List<Map<String, Object>> loaded = new ArrayList<Map<String, Object>>();
        if (Files.exists(file)) {
            try {
                String text = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
                if (!text.trim().isEmpty()) {
                    for (Object item : Json.asArray(Json.parse(text))) {
                        loaded.add(Json.asObject(item));
                    }
                }
            } catch (IOException e) {
                throw new StoreException("读取数据文件失败：" + file, e);
            }
        }
        long maxId = 0;
        for (Map<String, Object> row : loaded) {
            maxId = Math.max(maxId, Json.lng(row.get("id"), 0));
        }
        nextId = maxId + 1;
        rows = loaded;
    }

    private void flush() {
        try {
            Files.createDirectories(file.getParent());
            byte[] bytes = Json.writePretty(rows).getBytes(StandardCharsets.UTF_8);
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.write(tmp, bytes);
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            throw new StoreException("写入数据文件失败：" + file, e);
        }
    }
}
