package com.reimburse.store;

/** 存储层异常。用非受检异常，免去每层 throws 噪音，统一由 AppBootstrap / 错误页兜底。 */
public class StoreException extends RuntimeException {

    public StoreException(String message) {
        super(message);
    }

    public StoreException(String message, Throwable cause) {
        super(message, cause);
    }
}
