package com.reimburse.store;

import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.PolicyStatus;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.util.PasswordUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 演示数据。文件版与数据库版共用这一份，避免两套种子脚本各写一遍、日后不一致。
 *
 * 日期一律相对"今天"计算，不写死年月：这样无论哪天部署，制度库里都同时存在
 * "当前有效""已过有效期""尚未生效""草稿""已废止"五种情形，页面上的差异看得见。
 */
public final class SeedData {

    /** 演示口令。仅在首次初始化时使用，README 里有测试账号表。 */
    private static final String DEMO_PASSWORD = "123456";

    private SeedData() {
    }

    public static void seedIfEmpty(Store store) {
        if (store.users().count() > 0 || store.policies().count() > 0 || store.documents().count() > 0) {
            return;
        }
        LocalDate today = LocalDate.now();
        LocalDateTime now = LocalDateTime.now();

        // ---------------- 账号 ----------------
        User admin = user("admin", "系统管理员", Role.ADMIN, "信息技术部", null, now);
        User specialist = user("zhangq", "张倩", Role.SPECIALIST, "财务部", null, now);
        User clerkWang = user("wangm", "王明", Role.CLERK, "财务部", null, now);
        User clerkZhao = user("zhaol", "赵磊", Role.CLERK, "财务部", null, now);
        User sun = user("suny", "孙悦", Role.EMPLOYEE, "市场部", "E1024", now);
        User zhou = user("zhouw", "周伟", Role.EMPLOYEE, "研发部", "E1077", now);
        User xu = user("xuj", "徐佳", Role.EMPLOYEE, "综合办公室", "E1103", now);

        for (User u : new User[]{admin, specialist, clerkWang, clerkZhao, sun, zhou, xu}) {
            store.users().save(u);
        }

        // ---------------- 制度（制度域，维护者：张倩） ----------------
        String s = specialist.getUsername();

        // 差旅费：V1 已过有效期、V2 当前有效，用来验证"同一制度只应该查到有效的那一版"
        Policy travelV1 = policy("CS-2024-01", "差旅费报销管理办法", "报销标准", "TRAVEL",
                "第一条 适用范围\n本办法适用于全体员工因公出差发生的城市间交通费、住宿费、市内交通费与伙食补助费。\n"
                        + "第二条 住宿费标准\n一线城市每晚不超过 500 元，其他城市每晚不超过 350 元，凭住宿发票据实报销。\n"
                        + "第三条 城市间交通费\n优先选择经济型交通工具，高铁限二等座，机票限经济舱，超标部分自理。\n"
                        + "第四条 报销时限\n出差结束后 30 日内提交报销单据，逾期需附部门负责人说明。",
                1, PolicyStatus.REPEALED, today.minusYears(2), today.minusMonths(1), s, now.minusYears(2), null,
                "首次发布");
        store.policies().save(travelV1);

        Policy travelV2 = policy("CS-2024-01", "差旅费报销管理办法", "报销标准", "TRAVEL",
                "第一条 适用范围\n本办法适用于全体员工因公出差发生的城市间交通费、住宿费、市内交通费与伙食补助费。\n"
                        + "第二条 住宿费标准\n一线城市每晚不超过 600 元，其他城市每晚不超过 420 元，凭住宿发票据实报销。\n"
                        + "第三条 城市间交通费\n高铁限二等座，机票限经济舱；改签、退票产生的手续费需在事由中单独说明。\n"
                        + "第四条 伙食补助\n出差期间按每人每天 100 元包干，不再另行报销餐费。\n"
                        + "第五条 报销时限\n出差结束后 30 日内提交报销单据，逾期需附部门负责人说明。",
                2, PolicyStatus.ACTIVE, today.minusMonths(1).plusDays(1), null, s, now.minusMonths(1), travelV1.getId(),
                "住宿费标准上调；新增伙食补助包干条款；明确改签退票手续费的说明要求");
        store.policies().save(travelV2);

        Policy office = policy("BX-2024-02", "办公用品采购与报销细则", "采购报销", "OFFICE",
                "第一条 采购方式\n单次金额 1000 元以下的办公用品，由使用人自行采购后报销；1000 元及以上须走采购申请流程。\n"
                        + "第二条 报销凭据\n须提供增值税发票与采购清单，发票抬头必须为公司全称。\n"
                        + "第三条 不予报销的情形\n打印纸、笔等日常耗材由行政统一领用，个人采购的不予报销。",
                1, PolicyStatus.ACTIVE, today.minusMonths(8), null, s, now.minusMonths(8), null, "首次发布");
        store.policies().save(office);

        // 已发布但生效日在未来：员工现在查不到，用来验证"生效日期未到不算有效"
        Policy entertain = policy("ZD-2025-03", "业务招待费管理规定", "费用控制", "ENTERTAIN",
                "第一条 事前审批\n业务招待须事前填写招待申请单，注明招待对象、人数与预计金额，经部门负责人审批。\n"
                        + "第二条 标准\n人均不超过 200 元，白酒类消费不予报销。\n"
                        + "第三条 结算要求\n招待结束后 7 日内提交申请单与发票，无事前审批单的不予受理。",
                1, PolicyStatus.ACTIVE, today.plusMonths(2), null, s, now, null, "首次发布，自下季度起执行");
        store.policies().save(entertain);

        // 草稿：未发布，员工查不到
        Policy training = policy("PX-2025-04", "培训费报销与外出学习管理规定", "报销标准", "TRAINING",
                "第一条 适用范围\n员工参加外部培训、资格考试发生的培训费、报名费与差旅费。\n"
                        + "第二条 报销条件\n须与本人岗位相关，并事先取得部门负责人同意。\n"
                        + "第三条 服务期约定\n单次培训费用超过 5000 元的，须签订服务期协议。",
                1, PolicyStatus.DRAFT, today, null, s, now, null, "初稿，待财务负责人复核后发布");
        store.policies().save(training);

        Policy general = policy("BG-2025-05", "报销单据填写与附件规范", "单据规范", null,
                "第一条 单据要素\n报销单据须填写费用类型、发生日期、金额与事由，事由应说明业务背景。\n"
                        + "第二条 附件要求\n交通费附行程单，住宿费附发票，招待费附事前审批单。\n"
                        + "第三条 状态说明\n单据状态依次为已提交、审核中、审核通过、已支付；材料不齐的将被驳回并注明原因。\n"
                        + "第四条 查询方式\n员工可在本系统查询本人单据的当前状态与经办说明。",
                1, PolicyStatus.ACTIVE, today.minusYears(1), null, s, now.minusYears(1), null, "首次发布");
        store.policies().save(general);

        Policy traffic = policy("JT-2023-06", "市内交通费报销补充规定", "报销标准", "TRAVEL",
                "第一条 市内交通\n因公外出可乘坐公共交通据实报销，出租车费用需说明事由。\n"
                        + "第二条 生效与废止\n本规定已被《差旅费报销管理办法》替代，不再执行。",
                1, PolicyStatus.REPEALED, today.minusYears(3), today.minusYears(1), s, now.minusYears(3), null,
                "首次发布");
        store.policies().save(traffic);

        // ---------------- 单据（业务事实域，维护者：王明、赵磊） ----------------
        String w = clerkWang.getUsername();
        String z = clerkZhao.getUsername();
        String travelCode = travelV2.getCode();
        String officeCode = office.getCode();

        Document d1 = doc("BX" + ym(today.minusDays(40)) + "011", sun, ExpenseType.TRAVEL,
                new BigDecimal("2380.00"), today.minusDays(40), "赴上海参加行业展会，往返高铁及住宿 3 晚",
                DocStatus.APPROVED, w, "票据齐全，住宿未超标，核定报销 2380.00 元", travelCode,
                now.minusDays(38));
        Document d2 = doc("BX" + ym(today.minusDays(20)) + "018", sun, ExpenseType.OFFICE,
                new BigDecimal("356.80"), today.minusDays(20), "采购部门会议室白板笔与文件盒",
                DocStatus.REVIEWING, w, "发票已收，正在核对采购清单", officeCode, now.minusDays(18));
        // 招待费对应的制度尚未生效，因此这份单据没有可引用的制度编码
        Document d3 = doc("BX" + ym(today.minusDays(15)) + "023", sun, ExpenseType.ENTERTAIN,
                new BigDecimal("1280.00"), today.minusDays(15), "接待客户一行 5 人用餐",
                DocStatus.REJECTED, z, "缺少事前审批单，且业务招待费管理规定尚未生效，本次不予报销", null,
                now.minusDays(12));
        Document d4 = doc("BX" + ym(today.minusDays(5)) + "031", sun, ExpenseType.TRAVEL,
                new BigDecimal("960.00"), today.minusDays(5), "赴杭州供应商现场验收，当日往返",
                DocStatus.SUBMITTED, null, null, travelCode, now.minusDays(4));

        Document d5 = doc("BX" + ym(today.minusDays(50)) + "009", zhou, ExpenseType.TRAVEL,
                new BigDecimal("4120.50"), today.minusDays(50), "赴成都参加技术峰会，往返机票及住宿 4 晚",
                DocStatus.PAID, w, "已随第 3 批付款计划支付", travelCode, now.minusDays(45));
        Document d6 = doc("BX" + ym(today.minusDays(10)) + "026", zhou, ExpenseType.TRAINING,
                new BigDecimal("980.00"), today.minusDays(10), "参加云原生架构师认证考试报名费",
                DocStatus.SUBMITTED, null, null, null, now.minusDays(9));
        Document d7 = doc("BX" + ym(today.minusDays(30)) + "014", zhou, ExpenseType.OFFICE,
                new BigDecimal("268.00"), today.minusDays(30), "采购开发用键盘与鼠标各一套",
                DocStatus.APPROVED, z, "金额低于 1000 元，符合自行采购规定", officeCode, now.minusDays(28));

        Document d8 = doc("BX" + ym(today.minusDays(7)) + "029", xu, ExpenseType.OFFICE,
                new BigDecimal("128.00"), today.minusDays(7), "采购档案盒 20 个",
                DocStatus.SUBMITTED, null, null, officeCode, now.minusDays(6));
        Document d9 = doc("BX" + ym(today.minusDays(35)) + "013", xu, ExpenseType.TRAVEL,
                new BigDecimal("1650.00"), today.minusDays(35), "赴南京分公司协助季度盘点",
                DocStatus.APPROVED, z, "住宿 2 晚未超标，核定报销 1650.00 元", travelCode, now.minusDays(33));
        Document d10 = doc("BX" + ym(today.minusDays(60)) + "006", xu, ExpenseType.OFFICE,
                new BigDecimal("45.00"), today.minusDays(60), "重复提交的办公耗材费用",
                DocStatus.REJECTED, w, "同一批次重复报销，已驳回", officeCode, now.minusDays(58));

        for (Document d : new Document[]{d1, d2, d3, d4, d5, d6, d7, d8, d9, d10}) {
            store.documents().save(d);
        }
    }

    private static String ym(LocalDate day) {
        return String.format("%04d%02d", day.getYear(), day.getMonthValue());
    }

    private static User user(String username, String displayName, Role role, String dept, String employeeNo,
                             LocalDateTime createdAt) {
        User u = new User();
        u.setUsername(username);
        u.setDisplayName(displayName);
        u.setRole(role);
        u.setDept(dept);
        u.setEmployeeNo(employeeNo);
        u.setEnabled(true);
        u.setCreatedAt(createdAt);
        u.setSalt(PasswordUtil.newSalt());
        u.setPasswordHash(PasswordUtil.hash(DEMO_PASSWORD, u.getSalt()));
        return u;
    }

    private static Policy policy(String code, String title, String category, String appliesTo, String content,
                                 int version, PolicyStatus status, LocalDate from, LocalDate to, String issuer,
                                 LocalDateTime updatedAt, Long prevVersionId, String changeNote) {
        Policy p = new Policy();
        p.setCode(code);
        p.setTitle(title);
        p.setCategory(category);
        p.setAppliesTo(appliesTo);
        p.setContent(content);
        p.setVersion(version);
        p.setStatus(status);
        p.setEffectiveFrom(from);
        p.setEffectiveTo(to);
        p.setIssuer(issuer);
        p.setUpdatedBy(issuer);
        p.setUpdatedAt(updatedAt);
        p.setPrevVersionId(prevVersionId);
        p.setChangeNote(changeNote);
        return p;
    }

    private static Document doc(String docNo, User owner, ExpenseType type, BigDecimal amount, LocalDate occurredOn,
                               String reason, DocStatus status, String handler, String handleNote, String policyCode,
                               LocalDateTime updatedAt) {
        Document d = new Document();
        d.setDocNo(docNo);
        d.setOwnerId(owner.getId());
        d.setOwnerName(owner.getDisplayName());
        d.setExpenseType(type);
        d.setAmount(amount);
        d.setOccurredOn(occurredOn);
        d.setReason(reason);
        d.setStatus(status);
        d.setHandler(handler);
        d.setHandleNote(handleNote);
        d.setPolicyCode(policyCode);
        d.setCreatedAt(updatedAt.minusDays(1));
        d.setUpdatedAt(updatedAt);
        return d;
    }
}
