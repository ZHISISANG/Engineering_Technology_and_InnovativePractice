package com.reimburse.store;

import com.reimburse.model.AuditLog;

import java.util.List;

/**
 * 审计仓储。只追加不修改：日志能被改写就失去了追溯价值。
 */
public interface AuditRepository {

    void append(AuditLog log);

    List<AuditLog> findAll();

    /** 最近若干条，按时间倒序。 */
    List<AuditLog> recent(int limit);

    long count();
}
