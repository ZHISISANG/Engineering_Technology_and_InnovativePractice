package com.reimburse.store;

/**
 * 存储门面。文件版与数据库版各实现一次，上层的 Service 只依赖本接口，
 * 因此换存储不影响任何业务代码——这是"两份各做一份"的前提。
 */
public interface Store {

    UserRepository users();

    PolicyRepository policies();

    DocumentRepository documents();

    AuditRepository audits();

    /** 供页面显示当前使用的存储方式 */
    String describe();

    /** 首次启动灌入演示数据；已有数据时不做任何事 */
    void initAndSeedIfEmpty();
}
