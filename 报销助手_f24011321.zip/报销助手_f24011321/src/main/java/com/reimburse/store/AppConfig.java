package com.reimburse.store;

import java.util.Properties;

/**
 * 运行配置，来自 WEB-INF/config/app.properties。
 * build.ps1 会按变体重写该文件，因此部署目录里的配置才是实际生效的那份。
 */
public class AppConfig {

    private String storage = "file";
    private String contextPath = "reimburse";
    private String dataDir = ".";
    private String jdbcUrl;
    private String jdbcUser = "sa";
    private String jdbcPassword = "";
    private int sessionTimeoutMinutes = 30;

    public static AppConfig from(Properties props) {
        AppConfig c = new AppConfig();
        c.storage = props.getProperty("storage", "file").trim().toLowerCase();
        c.contextPath = props.getProperty("contextPath", "reimburse").trim();
        c.dataDir = props.getProperty("dataDir", ".").trim();

        // 数据库版默认用 dataDir 下的 H2 文件库；要换 MySQL 就在这里覆盖 url/账号
        String defaultUrl = "jdbc:h2:file:" + c.dataDir.replace('\\', '/')
                + "/reimburse;DB_CLOSE_DELAY=-1;MODE=REGULAR";
        c.jdbcUrl = props.getProperty("jdbc.url", defaultUrl).trim();
        c.jdbcUser = props.getProperty("jdbc.user", "sa").trim();
        c.jdbcPassword = props.getProperty("jdbc.password", "");
        c.sessionTimeoutMinutes = parseInt(props.getProperty("session.timeoutMinutes"), 30);
        return c;
    }

    private static int parseInt(String text, int dft) {
        if (text == null) {
            return dft;
        }
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return dft;
        }
    }

    public boolean isJdbc() {
        return "jdbc".equals(storage);
    }

    public String getStorage() { return storage; }

    public String getContextPath() { return contextPath; }

    public String getDataDir() { return dataDir; }

    public String getJdbcUrl() { return jdbcUrl; }

    public String getJdbcUser() { return jdbcUser; }

    public String getJdbcPassword() { return jdbcPassword; }

    public int getSessionTimeoutMinutes() { return sessionTimeoutMinutes; }
}
