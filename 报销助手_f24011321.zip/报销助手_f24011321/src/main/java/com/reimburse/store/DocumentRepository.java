package com.reimburse.store;

import com.reimburse.model.Document;

import java.util.List;

/** 单据仓储（业务事实域，维护者：业务员）。 */
public interface DocumentRepository {

    List<Document> findAll();

    Document findById(long id);

    /** 按归属员工取单据列表，员工查询本人单据状态就走这个方法。 */
    List<Document> findByOwner(long ownerId);

    void save(Document document);

    long count();
}
