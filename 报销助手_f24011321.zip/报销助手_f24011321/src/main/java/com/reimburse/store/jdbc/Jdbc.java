package com.reimburse.store.jdbc;

import com.reimburse.store.StoreException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

/**
 * 极简 JDBC 辅助：持有一个连接，所有方法加锁串行执行。
 *
 * 不用连接池的理由：本系统的并发就是几个人点页面，一个连接足够；
 * H2 嵌入式文件库用多连接反而更容易碰到文件锁。真要上生产再换 DataSource，改动局限在这个类。
 */
final class Jdbc {

    /** 行映射，把 ResultSet 当前行转成实体 */
    interface RowMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }

    private final Connection conn;
    private final String url;

    Jdbc(String url, String user, String password) {
        this.url = url;
        try {
            // 用字符串加载驱动，避免编译期依赖具体数据库的 jar
            Class.forName("org.h2.Driver");
            this.conn = DriverManager.getConnection(url, user, password);
            this.conn.setAutoCommit(true);
        } catch (ClassNotFoundException e) {
            throw new StoreException("未找到 H2 驱动，请确认 WEB-INF/lib 下有 h2-*.jar", e);
        } catch (SQLException e) {
            throw new StoreException("打开数据库连接失败：" + url + "（" + e.getMessage() + "）", e);
        }
    }

    String getUrl() {
        return url;
    }

    /** 执行建表脚本：去掉 -- 注释行后按分号切分逐条执行 */
    synchronized void executeScript(String script) {
        if (script == null || script.trim().isEmpty()) {
            return;
        }
        StringBuilder cleaned = new StringBuilder();
        for (String line : script.split("\r?\n")) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("--")) {
                continue;
            }
            cleaned.append(line).append('\n');
        }
        try (Statement st = conn.createStatement()) {
            for (String raw : cleaned.toString().split(";")) {
                String sql = raw.trim();
                if (!sql.isEmpty()) {
                    st.execute(sql);
                }
            }
        } catch (SQLException e) {
            throw new StoreException("执行建表脚本失败：" + e.getMessage(), e);
        }
    }

    synchronized <T> List<T> query(String sql, RowMapper<T> mapper, Object... args) {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, args);
            try (ResultSet rs = ps.executeQuery()) {
                List<T> list = new ArrayList<T>();
                while (rs.next()) {
                    list.add(mapper.map(rs));
                }
                return list;
            }
        } catch (SQLException e) {
            throw new StoreException("查询失败：" + sql + "（" + e.getMessage() + "）", e);
        }
    }

    synchronized <T> T queryOne(String sql, RowMapper<T> mapper, Object... args) {
        List<T> list = query(sql, mapper, args);
        return list.isEmpty() ? null : list.get(0);
    }

    synchronized int update(String sql, Object... args) {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, args);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new StoreException(writeFailure(sql, e), e);
        }
    }

    /** 插入并返回自增主键 */
    synchronized long insert(String sql, Object... args) {
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, args);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
                throw new StoreException("插入后未取到自增主键：" + sql);
            }
        } catch (SQLException e) {
            throw new StoreException(writeFailure(sql, e), e);
        }
    }

    /**
     * 数据库是否被以只读方式打开。
     * H2 打开"已存在的库文件"时，如果判定当前进程对文件没有写权限，会静默转成只读，
     * 之后所有写入都失败。启动时检查一次并明确告警，比事后翻一堆 500 好排查。
     */
    synchronized boolean isReadOnly() {
        try {
            return conn.isReadOnly();
        } catch (SQLException e) {
            return false;
        }
    }

    /** 写失败时补一句可执行的排查方向，避免只抛出驱动的原始报错 */
    private String writeFailure(String sql, SQLException e) {
        StringBuilder sb = new StringBuilder("写入失败：").append(sql).append("（").append(e.getMessage()).append("）");
        try {
            if (conn.isReadOnly()) {
                sb.append("。当前数据库连接为只读：库文件可能被其它进程占用、所在目录不可写，"
                        + "或运行环境限制了写权限。只读状态下查询正常，但登记单据、推进状态、写审计都会失败。");
            }
        } catch (SQLException ignored) {
            // 连状态都取不到时不再附言，保留驱动原始信息
        }
        return sb.toString();
    }

    private static void bind(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            Object v = args[i];
            int idx = i + 1;
            if (v == null) {
                ps.setNull(idx, Types.NULL);
            } else if (v instanceof java.time.LocalDate || v instanceof java.time.LocalDateTime) {
                ps.setObject(idx, v);
            } else {
                ps.setObject(idx, v);
            }
        }
    }

    /** 读取可空 BIGINT：H2 对 NULL 返回 0，需要用 wasNull 区分 */
    static Long nullableLong(ResultSet rs, String column) throws SQLException {
        long v = rs.getLong(column);
        return rs.wasNull() ? null : Long.valueOf(v);
    }
}
