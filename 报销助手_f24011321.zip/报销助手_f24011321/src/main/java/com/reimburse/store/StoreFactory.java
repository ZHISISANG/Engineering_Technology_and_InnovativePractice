package com.reimburse.store;

import com.reimburse.store.file.FileStore;
import com.reimburse.store.jdbc.JdbcStore;

/**
 * 按配置造出对应实现。新增一种存储只需在这里加一个分支，Service 与页面不用动。
 */
public final class StoreFactory {

    private StoreFactory() {
    }

    public static Store create(AppConfig config, String h2SchemaSql) {
        if (config.isJdbc()) {
            return new JdbcStore(config, h2SchemaSql);
        }
        return new FileStore(config);
    }
}
