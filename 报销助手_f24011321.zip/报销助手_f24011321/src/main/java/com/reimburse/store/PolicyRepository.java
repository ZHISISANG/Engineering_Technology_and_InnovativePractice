package com.reimburse.store;

import com.reimburse.model.Policy;

import java.util.List;

/** 制度仓储（制度域，维护者：专员）。 */
public interface PolicyRepository {

    List<Policy> findAll();

    Policy findById(long id);

    /** 同一制度编码的全部历史版本，按版本号倒序。 */
    List<Policy> findByCode(String code);

    void save(Policy policy);

    long count();
}
