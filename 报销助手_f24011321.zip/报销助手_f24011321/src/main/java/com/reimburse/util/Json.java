package com.reimburse.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 极简 JSON 读写，供文件版存储使用。
 * 之所以自己写而不引 Gson/Jackson：本项目要求零外部依赖，只用到对象、数组、字符串、数字、布尔、null
 * 这几种结构，约 200 行可控。写入时非 ASCII 字符不转义，便于直接用文本编辑器查看数据文件。
 */
public final class Json {

    private Json() {
    }

    /** 新建有序 Map，作为 JSON 对象的载体 */
    public static Map<String, Object> obj() {
        return new LinkedHashMap<String, Object>();
    }

    // ---------------- 写 ----------------

    public static String writePretty(Object value) {
        StringBuilder sb = new StringBuilder();
        writeValue(sb, value, 0, 2);
        return sb.toString();
    }

    private static void writeValue(StringBuilder sb, Object value, int depth, int indent) {
        if (value == null) {
            sb.append("null");
        } else if (value instanceof String) {
            writeString(sb, (String) value);
        } else if (value instanceof Boolean) {
            sb.append(value.toString());
        } else if (value instanceof Number) {
            sb.append(numberText((Number) value));
        } else if (value instanceof Map) {
            writeObject(sb, (Map<?, ?>) value, depth, indent);
        } else if (value instanceof Iterable) {
            writeArray(sb, (Iterable<?>) value, depth, indent);
        } else {
            writeString(sb, value.toString());
        }
    }

    private static void writeObject(StringBuilder sb, Map<?, ?> map, int depth, int indent) {
        if (map.isEmpty()) {
            sb.append("{}");
            return;
        }
        sb.append('{');
        boolean first = true;
        for (Map.Entry<?, ?> e : map.entrySet()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            newline(sb, depth + 1, indent);
            writeString(sb, String.valueOf(e.getKey()));
            sb.append(':');
            if (indent >= 0) {
                sb.append(' ');
            }
            writeValue(sb, e.getValue(), depth + 1, indent);
        }
        newline(sb, depth, indent);
        sb.append('}');
    }

    private static void writeArray(StringBuilder sb, Iterable<?> list, int depth, int indent) {
        java.util.Iterator<?> it = list.iterator();
        if (!it.hasNext()) {
            sb.append("[]");
            return;
        }
        sb.append('[');
        boolean first = true;
        while (it.hasNext()) {
            if (!first) {
                sb.append(',');
            }
            first = false;
            newline(sb, depth + 1, indent);
            writeValue(sb, it.next(), depth + 1, indent);
        }
        newline(sb, depth, indent);
        sb.append(']');
    }

    private static void newline(StringBuilder sb, int depth, int indent) {
        if (indent < 0) {
            return;
        }
        sb.append('\n');
        for (int i = 0; i < depth * indent; i++) {
            sb.append(' ');
        }
    }

    private static String numberText(Number n) {
        if (n instanceof BigDecimal) {
            return ((BigDecimal) n).toPlainString();
        }
        if (n instanceof Double || n instanceof Float) {
            double d = n.doubleValue();
            if (!Double.isInfinite(d) && !Double.isNaN(d) && d == Math.rint(d) && Math.abs(d) < 1e15) {
                return String.valueOf((long) d);
            }
            return BigDecimal.valueOf(d).toPlainString();
        }
        return n.toString();
    }

    private static void writeString(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
    }

    // ---------------- 读 ----------------

    public static Object parse(String text) {
        if (text == null) {
            throw new IllegalArgumentException("JSON 文本为空");
        }
        Parser p = new Parser(text);
        p.skipWs();
        if (p.eof()) {
            throw new IllegalArgumentException("JSON 文本为空");
        }
        Object value = p.value();
        p.skipWs();
        if (!p.eof()) {
            throw p.error("解析结束后仍有多余内容");
        }
        return value;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asObject(Object value) {
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        throw new IllegalArgumentException("期望 JSON 对象，实际是 " + typeName(value));
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asArray(Object value) {
        if (value instanceof List) {
            return (List<Object>) value;
        }
        throw new IllegalArgumentException("期望 JSON 数组，实际是 " + typeName(value));
    }

    public static String str(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    /** 取字符串，为空时给默认值 */
    public static String str(Object value, String dft) {
        String s = str(value);
        return s == null || s.isEmpty() ? dft : s;
    }

    public static long lng(Object value, long dft) {
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        if (value instanceof String) {
            try {
                return Long.parseLong(((String) value).trim());
            } catch (NumberFormatException ignored) {
                return dft;
            }
        }
        return dft;
    }

    public static Long lngOrNull(Object value) {
        return value == null ? null : Long.valueOf(lng(value, 0L));
    }

    public static int integer(Object value, int dft) {
        return (int) lng(value, dft);
    }

    public static boolean bool(Object value, boolean dft) {
        if (value instanceof Boolean) {
            return (Boolean) value;
        }
        if (value instanceof String) {
            return Boolean.parseBoolean(((String) value).trim());
        }
        return dft;
    }

    public static BigDecimal decimal(Object value, BigDecimal dft) {
        if (value == null) {
            return dft;
        }
        if (value instanceof BigDecimal) {
            return (BigDecimal) value;
        }
        if (value instanceof Number) {
            return new BigDecimal(value.toString());
        }
        try {
            return new BigDecimal(String.valueOf(value).trim());
        } catch (NumberFormatException ignored) {
            return dft;
        }
    }

    private static String typeName(Object value) {
        return value == null ? "null" : value.getClass().getSimpleName();
    }

    /** 递归下降解析器。只处理标准 JSON 的一个子集，但对本项目的结构完全够用。 */
    private static final class Parser {
        private final String s;
        private int pos;

        Parser(String s) {
            this.s = s;
        }

        boolean eof() {
            return pos >= s.length();
        }

        void skipWs() {
            while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) {
                pos++;
            }
        }

        char peek() {
            if (eof()) {
                throw error("意外结束");
            }
            return s.charAt(pos);
        }

        IllegalArgumentException error(String msg) {
            return new IllegalArgumentException("JSON 解析失败：" + msg + "（位置 " + pos + "）");
        }

        void expect(char c) {
            if (eof() || s.charAt(pos) != c) {
                throw error("期望 '" + c + "'");
            }
            pos++;
        }

        Object value() {
            skipWs();
            char c = peek();
            switch (c) {
                case '{': return object();
                case '[': return array();
                case '"': return string();
                case 't': literal("true"); return Boolean.TRUE;
                case 'f': literal("false"); return Boolean.FALSE;
                case 'n': literal("null"); return null;
                default:  return number();
            }
        }

        void literal(String word) {
            if (!s.startsWith(word, pos)) {
                throw error("非法字面量，期望 " + word);
            }
            pos += word.length();
        }

        Map<String, Object> object() {
            expect('{');
            Map<String, Object> map = new LinkedHashMap<String, Object>();
            skipWs();
            if (peek() == '}') {
                pos++;
                return map;
            }
            while (true) {
                skipWs();
                String key = string();
                skipWs();
                expect(':');
                map.put(key, value());
                skipWs();
                char c = peek();
                if (c == ',') {
                    pos++;
                } else if (c == '}') {
                    pos++;
                    return map;
                } else {
                    throw error("对象中期望 ',' 或 '}'");
                }
            }
        }

        List<Object> array() {
            expect('[');
            List<Object> list = new ArrayList<Object>();
            skipWs();
            if (peek() == ']') {
                pos++;
                return list;
            }
            while (true) {
                list.add(value());
                skipWs();
                char c = peek();
                if (c == ',') {
                    pos++;
                } else if (c == ']') {
                    pos++;
                    return list;
                } else {
                    throw error("数组中期望 ',' 或 ']'");
                }
            }
        }

        String string() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (eof()) {
                    throw error("字符串未闭合");
                }
                char c = s.charAt(pos++);
                if (c == '"') {
                    return sb.toString();
                }
                if (c != '\\') {
                    sb.append(c);
                    continue;
                }
                if (eof()) {
                    throw error("转义字符未完成");
                }
                char e = s.charAt(pos++);
                switch (e) {
                    case '"':  sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/':  sb.append('/'); break;
                    case 'b':  sb.append('\b'); break;
                    case 'f':  sb.append('\f'); break;
                    case 'n':  sb.append('\n'); break;
                    case 'r':  sb.append('\r'); break;
                    case 't':  sb.append('\t'); break;
                    case 'u':
                        if (pos + 4 > s.length()) {
                            throw error("\\u 转义不完整");
                        }
                        sb.append((char) Integer.parseInt(s.substring(pos, pos + 4), 16));
                        pos += 4;
                        break;
                    default:
                        throw error("无法识别的转义 \\" + e);
                }
            }
        }

        Object number() {
            int start = pos;
            if (!eof() && (peek() == '-' || peek() == '+')) {
                pos++;
            }
            boolean fractional = false;
            while (!eof()) {
                char c = s.charAt(pos);
                if (c >= '0' && c <= '9') {
                    pos++;
                } else if (c == '.' || c == 'e' || c == 'E' || c == '-' || c == '+') {
                    fractional = true;
                    pos++;
                } else {
                    break;
                }
            }
            String text = s.substring(start, pos);
            if (text.isEmpty() || "-".equals(text)) {
                throw error("非法数字");
            }
            try {
                return fractional ? (Object) Double.valueOf(text) : (Object) Long.valueOf(text);
            } catch (NumberFormatException e) {
                throw error("非法数字 " + text);
            }
        }
    }
}
