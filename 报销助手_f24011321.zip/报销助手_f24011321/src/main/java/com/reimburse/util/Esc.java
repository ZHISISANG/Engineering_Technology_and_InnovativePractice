package com.reimburse.util;

/**
 * 页面输出用的转义与小工具。JSP 用脚本片段输出，所有动态内容都必须过 Esc.html，
 * 否则制度正文、单据事由里的尖括号会破坏页面结构（XSS）。
 */
public final class Esc {

    private Esc() {
    }

    public static String html(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '&':  sb.append("&amp;"); break;
                case '<':  sb.append("&lt;"); break;
                case '>':  sb.append("&gt;"); break;
                case '"':  sb.append("&quot;"); break;
                case '\'': sb.append("&#39;"); break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    /** 多行文本转成 HTML：先转义，再把换行变成 &lt;br&gt; */
    public static String nvl(String text) {
        return text == null ? "" : text;
    }

    public static String nvl(String text, String dft) {
        return text == null || text.trim().isEmpty() ? dft : text;
    }

    public static boolean blank(String text) {
        return text == null || text.trim().isEmpty();
    }

    public static String truncate(String text, int max) {
        if (text == null) {
            return "";
        }
        String one = text.replace("\r", " ").replace("\n", " ");
        return one.length() <= max ? one : one.substring(0, max) + "…";
    }

    /** 标记当前导航项 */
    public static String active(boolean on) {
        return on ? " class=\"on\"" : "";
    }

    /** 把查询串里的关键字回填到输入框 */
    public static String attr(String text) {
        return html(text);
    }
}
