package com.reimburse.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** 日期时间与存储、页面之间的转换。存储统一用 yyyy-MM-dd 与 yyyy-MM-dd HH:mm:ss 两种文本格式。 */
public final class Dates {

    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATETIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private Dates() {
    }

    public static LocalDate today() {
        return LocalDate.now();
    }

    public static LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(text.trim(), DATE);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static LocalDateTime parseDateTime(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        try {
            return LocalDateTime.parse(text.trim(), DATETIME);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String format(LocalDate date) {
        return date == null ? null : date.format(DATE);
    }

    /** 带默认值：页面上一律用这个，避免空值显示成 "null" */
    public static String format(LocalDate date, String dft) {
        String s = format(date);
        return s == null ? dft : s;
    }

    public static String format(LocalDateTime time) {
        return time == null ? null : time.format(DATETIME);
    }

    public static String format(LocalDateTime time, String dft) {
        String s = format(time);
        return s == null ? dft : s;
    }
}
