package com.reimburse.service;

/** 表单校验失败。带上出错原因，回显到页面上，不写审计（这是输入问题，不是越权）。 */
public class ValidationException extends RuntimeException {

    public ValidationException(String message) {
        super(message);
    }
}
