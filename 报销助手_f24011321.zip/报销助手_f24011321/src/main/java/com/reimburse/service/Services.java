package com.reimburse.service;

import com.reimburse.store.Store;

/**
 * 服务集合。放在 ServletContext 里供所有 Servlet/Filter 取用，
 * 避免每个 Servlet 都自己 new 一遍（那会导致每个请求都重建仓储）。
 */
public class Services {

    public static final String CONTEXT_ATTRIBUTE = "com.reimburse.services";

    private final Store store;
    private final AuditService audit;
    private final AuthService auth;
    private final PolicyService policy;
    private final DocumentService document;
    private final UserService user;

    public Services(Store store) {
        this.store = store;
        this.audit = new AuditService(store);
        this.policy = new PolicyService(store);
        this.document = new DocumentService(store, policy);
        this.user = new UserService(store);
        this.auth = new AuthService(store, audit);
    }

    public Store store() { return store; }
    public AuditService audit() { return audit; }
    public AuthService auth() { return auth; }
    public PolicyService policy() { return policy; }
    public DocumentService document() { return document; }
    public UserService user() { return user; }

    public String storageDescription() {
        return store.describe();
    }
}
