package com.reimburse.service;

import com.reimburse.model.AuditAction;
import com.reimburse.model.AuditLog;
import com.reimburse.model.AuditResult;
import com.reimburse.model.User;
import com.reimburse.store.Store;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 审计。登录、查询制度、查询本人单据、维护、以及被拒绝的越权尝试都写一条。
 * 服务层只收字符串 IP，不依赖 Servlet API。
 */
public class AuditService {

    private final Store store;

    public AuditService(Store store) {
        this.store = store;
    }

    public void record(User actor, AuditAction action, String target, AuditResult result, String detail, String ip) {
        AuditLog log = new AuditLog();
        log.setAtTime(LocalDateTime.now());
        log.setActor(actor == null ? "匿名" : actor.getUsername());
        log.setActorRole(actor == null || actor.getRole() == null ? "-" : actor.getRole().name());
        log.setAction(action);
        log.setTarget(target);
        log.setResult(result);
        log.setDetail(detail);
        log.setIp(ip);
        store.audits().append(log);
    }

    public void allow(User actor, AuditAction action, String target, String detail, String ip) {
        record(actor, action, target, AuditResult.ALLOW, detail, ip);
    }

    public void deny(User actor, AuditAction action, String target, String detail, String ip) {
        record(actor, action, target, AuditResult.DENY, detail, ip);
    }

    public List<AuditLog> recent(int limit) {
        return store.audits().recent(limit);
    }

    /** 只看被拒绝的访问尝试，越权排查时最常用 */
    public List<AuditLog> denied(int limit) {
        List<AuditLog> out = new ArrayList<AuditLog>();
        for (AuditLog log : store.audits().findAll()) {
            if (log.getResult() == AuditResult.DENY) {
                out.add(log);
                if (out.size() >= limit) {
                    break;
                }
            }
        }
        return out;
    }

    public long count() {
        return store.audits().count();
    }

    /**
     * 某个对象的操作轨迹，按时间正序。
     * 单据详情页用它渲染"谁在什么时候把状态推到了哪一步"——审计表顺带承担了状态变更历史，
     * 不用再单独建一张 history 表。
     */
    public List<AuditLog> historyFor(String target) {
        List<AuditLog> out = new ArrayList<AuditLog>();
        if (target == null) {
            return out;
        }
        for (AuditLog log : store.audits().findAll()) {
            if (log.getResult() == AuditResult.ALLOW && target.equals(log.getTarget())) {
                out.add(log);
            }
        }
        out.sort((a, b) -> Long.compare(a.getId(), b.getId()));
        return out;
    }
}
