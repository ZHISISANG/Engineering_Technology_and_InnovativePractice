package com.reimburse.service;

import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.PolicyStatus;
import com.reimburse.model.User;
import com.reimburse.store.Store;
import com.reimburse.util.Esc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 制度域服务。维护者：制度专员。
 *
 * 两条贯穿全项目的规则在这里落地：
 *   1) "有效"是算出来的，不是存出来的 —— status == ACTIVE 且今天落在有效期内。
 *      因此草稿、尚未生效、已过有效期、已废止四种情况自动被挡在员工视野之外。
 *   2) 同一制度编码在同一时刻只允许一个生效版本 —— 发布新版本会把旧的置为废止，
 *      避免员工搜出两条互相矛盾的口径。
 */
public class PolicyService {

    private static final Pattern CODE_PATTERN = Pattern.compile("[A-Za-z0-9-]{2,32}");

    private final Store store;

    public PolicyService(Store store) {
        this.store = store;
    }

    // ==================== 员工侧：只读有效制度 ====================

    /**
     * 员工自助查询。关键字匹配标题/编码/正文，费用类型匹配"该制度是否管这类费用"。
     * 注意：appliesTo 为空的制度视为通用制度，任何费用类型都能查到它。
     */
    public List<Policy> listEffective(String keyword, String expenseTypeCode) {
        LocalDate today = LocalDate.now();
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        List<Policy> out = new ArrayList<Policy>();
        for (Policy p : store.policies().findAll()) {
            if (!isEffective(p, today)) {
                continue;
            }
            if (!kw.isEmpty() && !matchesKeyword(p, kw)) {
                continue;
            }
            if (!Esc.blank(expenseTypeCode) && !matchesExpenseType(p, expenseTypeCode)) {
                continue;
            }
            out.add(p);
        }
        out.sort(Comparator.comparing(Policy::getCode));
        return out;
    }

    private boolean matchesKeyword(Policy p, String lowerKeyword) {
        return contains(p.getTitle(), lowerKeyword)
                || contains(p.getCode(), lowerKeyword)
                || contains(p.getCategory(), lowerKeyword)
                || contains(p.getContent(), lowerKeyword);
    }

    private static boolean contains(String text, String lowerKeyword) {
        return text != null && text.toLowerCase().contains(lowerKeyword);
    }

    /** 通用制度（appliesTo 为空）对所有费用类型都适用 */
    private boolean matchesExpenseType(Policy p, String expenseTypeCode) {
        if (Esc.blank(p.getAppliesTo())) {
            return true;
        }
        return ExpenseType.matches(p.getAppliesTo(), ExpenseType.of(expenseTypeCode));
    }

    public boolean isEffective(Policy p) {
        return isEffective(p, LocalDate.now());
    }

    private boolean isEffective(Policy p, LocalDate today) {
        return p != null && p.getStatus() == PolicyStatus.ACTIVE && p.covers(today);
    }

    /** 员工查看详情用：不是有效制度就返回 null，由调用方转 403 */
    public Policy findEffectiveById(long id) {
        Policy p = store.policies().findById(id);
        return isEffective(p) ? p : null;
    }

    public Policy findById(long id) {
        return store.policies().findById(id);
    }

    /** 取某编码当前生效的版本，没有则 null */
    public Policy findEffectiveByCode(String code) {
        if (Esc.blank(code)) {
            return null;
        }
        for (Policy p : store.policies().findByCode(code)) {
            if (isEffective(p)) {
                return p;
            }
        }
        return null;
    }

    /** 取某编码最新的一版（可能是草稿、未生效或已废止），用于追溯说明 */
    public Policy findLatestByCode(String code) {
        if (Esc.blank(code)) {
            return null;
        }
        List<Policy> all = store.policies().findByCode(code);
        return all.isEmpty() ? null : all.get(0);
    }

    /** 某编码的全部版本，按版本号倒序，供维护页展示版本链 */
    public List<Policy> findByCode(String code) {
        if (Esc.blank(code)) {
            return new ArrayList<Policy>();
        }
        return store.policies().findByCode(code);
    }

    // ==================== 专员侧：维护 ====================

    /** 维护列表：所有版本一览，含草稿与历史版本 */
    public List<Policy> listForMaintenance(String keyword) {
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        LocalDate today = LocalDate.now();
        List<Policy> out = new ArrayList<Policy>();
        for (Policy p : store.policies().findAll()) {
            if (!kw.isEmpty() && !matchesKeyword(p, kw)) {
                continue;
            }
            out.add(p);
        }
        // 同一编码的多个版本排在一起，版本号大的在前
        out.sort(Comparator.comparing(Policy::getCode).thenComparing(Comparator.comparingInt(Policy::getVersion).reversed()));
        return out;
    }

    /** 维护页上的状态说明，解释"这条制度现在对员工是否可用" */
    public String effectivenessText(Policy p) {
        if (p == null) {
            return "-";
        }
        LocalDate today = LocalDate.now();
        if (p.getStatus() == PolicyStatus.DRAFT) {
            return "草稿未发布，员工查不到";
        }
        if (p.getStatus() == PolicyStatus.REPEALED) {
            return "已废止，员工查不到";
        }
        if (p.getEffectiveFrom() == null) {
            return "未设生效日期，员工查不到";
        }
        if (today.isBefore(p.getEffectiveFrom())) {
            return "已发布，自 " + p.getEffectiveFrom() + " 起生效，目前员工查不到";
        }
        if (p.getEffectiveTo() != null && today.isAfter(p.getEffectiveTo())) {
            return "有效期已过，员工查不到";
        }
        return "当前有效，员工可查询";
    }

    /** 新增制度。同一编码只允许一条首版，改内容必须走 revise()。 */
    public Policy create(User specialist, String code, String title, String category, String appliesTo,
                         String content, LocalDate from, LocalDate to, String changeNote, boolean publishNow) {
        validateCommon(code, title, category, content);
        if (!store.policies().findByCode(code).isEmpty()) {
            throw new ValidationException("制度编码 " + code + " 已存在。如需修改内容，请在列表中对该制度执行“修订”。");
        }
        if (publishNow) {
            requireEffectiveRange(from, to);
        } else if (from != null && to != null && to.isBefore(from)) {
            throw new ValidationException("失效日期不能早于生效日期。");
        }

        Policy p = new Policy();
        p.setCode(code);
        p.setTitle(title);
        p.setCategory(category);
        p.setAppliesTo(Esc.blank(appliesTo) ? null : appliesTo.trim());
        p.setContent(content);
        p.setVersion(1);
        p.setStatus(publishNow ? PolicyStatus.ACTIVE : PolicyStatus.DRAFT);
        p.setEffectiveFrom(from);
        p.setEffectiveTo(to);
        p.setIssuer(specialist.getUsername());
        p.setUpdatedBy(specialist.getUsername());
        p.setUpdatedAt(LocalDateTime.now());
        p.setChangeNote(Esc.nvl(changeNote, "首次发布"));
        store.policies().save(p);
        return p;
    }

    /**
     * 修订：以最新版本为基线产生下一版草稿，旧版本内容原样保留。
     * 修订必须先发布才能被员工看到，中间状态是安全的。
     */
    public Policy revise(User specialist, long sourceId, String content, String changeNote) {
        Policy source = store.policies().findById(sourceId);
        if (source == null) {
            throw new ValidationException("制度不存在：id=" + sourceId);
        }
        if (Esc.blank(content)) {
            throw new ValidationException("修订后的制度正文不能为空。");
        }
        Policy latest = findLatestByCode(source.getCode());
        Policy p = new Policy();
        p.setCode(source.getCode());
        p.setTitle(source.getTitle());
        p.setCategory(source.getCategory());
        p.setAppliesTo(source.getAppliesTo());
        p.setContent(content);
        p.setVersion(latest.getVersion() + 1);
        p.setStatus(PolicyStatus.DRAFT);
        p.setEffectiveFrom(null);
        p.setEffectiveTo(null);
        p.setIssuer(specialist.getUsername());
        p.setUpdatedBy(specialist.getUsername());
        p.setUpdatedAt(LocalDateTime.now());
        p.setPrevVersionId(Long.valueOf(latest.getId()));
        p.setChangeNote(Esc.nvl(changeNote, "第 " + p.getVersion() + " 版修订"));
        store.policies().save(p);
        return p;
    }

    /** 发布：定生效日期并转 ACTIVE，同时把同编码其它生效版本置为废止 */
    public Policy publish(User specialist, long id, LocalDate from, LocalDate to, String changeNote) {
        Policy p = store.policies().findById(id);
        if (p == null) {
            throw new ValidationException("制度不存在：id=" + id);
        }
        if (p.getStatus() == PolicyStatus.ACTIVE) {
            throw new ValidationException("《" + p.getTitle() + "》" + p.getVersionLabel() + " 已经是生效状态。");
        }
        requireEffectiveRange(from, to);

        p.setEffectiveFrom(from);
        p.setEffectiveTo(to);
        p.setStatus(PolicyStatus.ACTIVE);
        p.setUpdatedBy(specialist.getUsername());
        p.setUpdatedAt(LocalDateTime.now());
        if (!Esc.blank(changeNote)) {
            p.setChangeNote(changeNote);
        }
        store.policies().save(p);

        for (Policy other : store.policies().findByCode(p.getCode())) {
            if (other.getId() != p.getId() && other.getStatus() == PolicyStatus.ACTIVE) {
                other.setStatus(PolicyStatus.REPEALED);
                other.setUpdatedBy(specialist.getUsername());
                other.setUpdatedAt(LocalDateTime.now());
                store.policies().save(other);
            }
        }
        return p;
    }

    /** 废止：仅对生效版本有意义，草稿直接删掉更合适，这里一并允许废止 */
    public void repeal(User specialist, long id) {
        Policy p = store.policies().findById(id);
        if (p == null) {
            throw new ValidationException("制度不存在：id=" + id);
        }
        if (p.getStatus() == PolicyStatus.REPEALED) {
            throw new ValidationException("该版本已经是废止状态。");
        }
        p.setStatus(PolicyStatus.REPEALED);
        p.setUpdatedBy(specialist.getUsername());
        p.setUpdatedAt(LocalDateTime.now());
        store.policies().save(p);
    }

    // ==================== 校验 ====================

    private void validateCommon(String code, String title, String category, String content) {
        if (Esc.blank(code)) {
            throw new ValidationException("制度编码不能为空，建议用“分类缩写-年份-序号”的形式。");
        }
        if (!CODE_PATTERN.matcher(code.trim()).matches()) {
            throw new ValidationException("制度编码只能用字母、数字和短横线，长度 2 到 32 位。");
        }
        if (Esc.blank(title)) {
            throw new ValidationException("制度名称不能为空。");
        }
        if (title.trim().length() > 128) {
            throw new ValidationException("制度名称不能超过 128 个字。");
        }
        if (Esc.blank(category)) {
            throw new ValidationException("制度分类不能为空，例如“报销标准”“单据规范”。");
        }
        if (Esc.blank(content)) {
            throw new ValidationException("制度正文不能为空。");
        }
        if (content.length() > 4000) {
            throw new ValidationException("制度正文不能超过 4000 个字，超出部分建议拆分为多条制度。");
        }
    }

    private void requireEffectiveRange(LocalDate from, LocalDate to) {
        if (from == null) {
            throw new ValidationException("发布制度必须填写生效日期。");
        }
        if (to != null && to.isBefore(from)) {
            throw new ValidationException("失效日期不能早于生效日期。");
        }
    }
}
