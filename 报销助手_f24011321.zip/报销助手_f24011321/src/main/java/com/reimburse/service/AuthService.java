package com.reimburse.service;

import com.reimburse.model.AuditAction;
import com.reimburse.model.User;
import com.reimburse.store.Store;
import com.reimburse.util.PasswordUtil;

/**
 * 登录。口令用 PBKDF2 派生值比对；账号被停用或口令错误都返回失败，不区分提示，
 * 避免通过提示差异枚举出哪些账号存在。
 */
public class AuthService {

    private final Store store;
    private final AuditService audit;

    public AuthService(Store store, AuditService audit) {
        this.store = store;
        this.audit = audit;
    }

    /** 登录失败原因写进审计的 detail，页面上只显示统一提示。 */
    public User authenticate(String username, String password, String ip) {
        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            audit.deny(null, AuditAction.LOGIN_FAIL, String.valueOf(username), "账号或口令为空", ip);
            return null;
        }
        User user = store.users().findByUsername(username.trim());
        if (user == null) {
            audit.deny(null, AuditAction.LOGIN_FAIL, username.trim(), "账号不存在", ip);
            return null;
        }
        if (!user.isEnabled()) {
            audit.deny(user, AuditAction.LOGIN_FAIL, username.trim(), "账号已停用", ip);
            return null;
        }
        if (!PasswordUtil.verify(password, user.getSalt(), user.getPasswordHash())) {
            audit.deny(user, AuditAction.LOGIN_FAIL, username.trim(), "口令错误", ip);
            return null;
        }
        audit.allow(user, AuditAction.LOGIN, user.getUsername(), "登录成功，角色 " + user.getRole().getLabel(), ip);
        return user;
    }
}
