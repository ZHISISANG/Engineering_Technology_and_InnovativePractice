package com.reimburse.service;

/**
 * 越权访问。由服务层抛出，Web 层统一转成 403 页面并写审计；
 * 关键点是它在服务端判断，改 URL、改参数都绕不过去。
 */
public class AccessDeniedException extends RuntimeException {

    public AccessDeniedException(String message) {
        super(message);
    }
}
