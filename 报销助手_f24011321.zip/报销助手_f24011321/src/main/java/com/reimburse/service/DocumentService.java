package com.reimburse.service;

import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.User;
import com.reimburse.store.Store;
import com.reimburse.util.Esc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 业务事实域服务。事实的维护者是业务员；员工只能读自己的那份。
 *
 * 授权在这里把关：findOwn() 会比对单据归属与登录账号，不一致就抛 AccessDeniedException。
 * 页面上隐藏链接只是顺手，真正的拦截在这一层——直接拼 URL 也一样被挡住。
 */
public class DocumentService {

    /** 单张单据金额上限，防止把小数点打错造成明显失真的业务事实 */
    private static final BigDecimal MAX_AMOUNT = new BigDecimal("1000000");

    private final Store store;
    private final PolicyService policyService;

    public DocumentService(Store store, PolicyService policyService) {
        this.store = store;
        this.policyService = policyService;
    }

    // ==================== 员工侧：经授权查询本人单据 ====================

    /** 本人单据列表。statusFilter/keyword 为空表示不过滤。 */
    public List<Document> listOwn(User actor, String statusFilter, String keyword) {
        List<Document> out = new ArrayList<Document>();
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        for (Document d : store.documents().findByOwner(actor.getId())) {
            if (!Esc.blank(statusFilter) && d.getStatus() != DocStatus.valueOf(statusFilter.trim().toUpperCase())) {
                continue;
            }
            if (!kw.isEmpty() && !matches(d, kw)) {
                continue;
            }
            out.add(d);
        }
        return out;
    }

    /**
     * 查看本人单据详情。这是"经授权查询"的判定点：
     * 单据不存在返回 null（转 404），存在但不属于当前账号抛越权（转 403 并审计）。
     */
    public Document findOwn(User actor, long docId) {
        Document d = store.documents().findById(docId);
        if (d == null) {
            return null;
        }
        if (d.getOwnerId() != actor.getId()) {
            throw new AccessDeniedException("单据 " + d.getDocNo() + " 的归属人不是当前账号（"
                    + actor.getDisplayName() + "），无权查看其状态。");
        }
        return d;
    }

    private static boolean matches(Document d, String lowerKeyword) {
        return contains(d.getDocNo(), lowerKeyword)
                || contains(d.getReason(), lowerKeyword)
                || (d.getExpenseType() != null && contains(d.getExpenseType().getLabel(), lowerKeyword));
    }

    private static boolean contains(String text, String lowerKeyword) {
        return text != null && text.toLowerCase().contains(lowerKeyword);
    }

    // ==================== 业务员侧：维护业务事实 ====================

    public List<Document> listForMaintenance(String statusFilter, String keyword, String ownerKeyword) {
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        String owner = ownerKeyword == null ? "" : ownerKeyword.trim().toLowerCase();
        List<Document> out = new ArrayList<Document>();
        for (Document d : store.documents().findAll()) {
            if (!Esc.blank(statusFilter) && d.getStatus() != DocStatus.valueOf(statusFilter.trim().toUpperCase())) {
                continue;
            }
            if (!kw.isEmpty() && !matches(d, kw)) {
                continue;
            }
            if (!owner.isEmpty() && !contains(d.getOwnerName(), owner) && !contains(d.getDocNo(), owner)) {
                continue;
            }
            out.add(d);
        }
        return out;
    }

    public Document findById(long id) {
        return store.documents().findById(id);
    }

    /** 登记单据。归属员工只能在这里确定，之后任何维护动作都不能改归属。 */
    public Document create(User clerk, long ownerId, ExpenseType type, BigDecimal amount,
                           LocalDate occurredOn, String reason, String policyCode) {
        User owner = store.users().findById(ownerId);
        if (owner == null) {
            throw new ValidationException("请选择有效的归属员工。");
        }
        if (!owner.isEnabled()) {
            throw new ValidationException("归属员工 " + owner.getDisplayName() + " 的账号已停用，不能登记单据。");
        }
        validateFacts(type, amount, occurredOn, reason);

        Document d = new Document();
        d.setDocNo(nextDocNo(occurredOn));
        d.setOwnerId(owner.getId());
        d.setOwnerName(owner.getDisplayName());
        d.setExpenseType(type);
        d.setAmount(amount);
        d.setOccurredOn(occurredOn);
        d.setReason(reason.trim());
        d.setStatus(DocStatus.SUBMITTED);
        d.setHandler(clerk.getUsername());
        d.setHandleNote("已受理，待审核");
        d.setPolicyCode(resolvePolicyCode(type, policyCode));
        d.setCreatedAt(LocalDateTime.now());
        d.setUpdatedAt(LocalDateTime.now());
        store.documents().save(d);
        return d;
    }

    /**
     * 修正业务事实。终态单据（已支付、已驳回）的事实冻结，只允许查看。
     * 注意参数里没有 ownerId —— 归属不可变更，这是防篡改而不是防误操作。
     */
    public Document updateFacts(User clerk, long id, ExpenseType type, BigDecimal amount,
                               LocalDate occurredOn, String reason, String policyCode) {
        Document d = store.documents().findById(id);
        if (d == null) {
            throw new ValidationException("单据不存在：id=" + id);
        }
        if (d.getStatus().isFinal()) {
            throw new ValidationException("单据 " + d.getDocNo() + " 已处于“" + d.getStatus().getLabel()
                    + "”，业务事实已冻结，不能再修改。");
        }
        validateFacts(type, amount, occurredOn, reason);

        d.setExpenseType(type);
        d.setAmount(amount);
        d.setOccurredOn(occurredOn);
        d.setReason(reason.trim());
        d.setPolicyCode(resolvePolicyCode(type, policyCode));
        d.setHandler(clerk.getUsername());
        d.setUpdatedAt(LocalDateTime.now());
        store.documents().save(d);
        return d;
    }

    /** 推进状态。只能沿 已提交→审核中→审核通过→已支付 走，或在非终态时驳回。 */
    public Document progress(User clerk, long id, DocStatus target, String note) {
        Document d = store.documents().findById(id);
        if (d == null) {
            throw new ValidationException("单据不存在：id=" + id);
        }
        if (target == null) {
            throw new ValidationException("请选择要推进到的状态。");
        }
        if (d.getStatus().isFinal()) {
            throw new ValidationException("单据 " + d.getDocNo() + " 已处于终态“" + d.getStatus().getLabel()
                    + "”，状态不能再变更。");
        }
        boolean isReject = target.isRejected();
        if (!isReject && target != d.getStatus().next()) {
            throw new ValidationException("状态只能按顺序推进：当前“" + d.getStatus().getLabel()
                    + "”的下一步是“" + d.getStatus().next().getLabel() + "”。");
        }
        if (isReject && Esc.blank(note)) {
            throw new ValidationException("驳回单据必须填写原因，员工要能看到为什么被驳回。");
        }

        d.setStatus(target);
        d.setHandler(clerk.getUsername());
        if (!Esc.blank(note)) {
            d.setHandleNote(note.trim());
        }
        d.setUpdatedAt(LocalDateTime.now());
        store.documents().save(d);
        return d;
    }

    /** 可推进的目标状态，给业务员表单生成下拉项 */
    public List<DocStatus> nextOptions(Document d) {
        List<DocStatus> out = new ArrayList<DocStatus>();
        if (d == null || d.getStatus().isFinal()) {
            return out;
        }
        if (d.getStatus().next() != null) {
            out.add(d.getStatus().next());
        }
        out.add(DocStatus.REJECTED);
        return out;
    }

    /** 按费用类型找当前生效的制度，用于自动带出制度依据 */
    public String suggestPolicyCode(ExpenseType type) {
        for (Policy p : policyService.listEffective(null, type == null ? null : type.name())) {
            if (ExpenseType.matches(p.getAppliesTo(), type)) {
                return p.getCode();
            }
        }
        // 没有专门制度时退回到通用制度
        for (Policy p : policyService.listEffective(null, null)) {
            if (Esc.blank(p.getAppliesTo())) {
                return p.getCode();
            }
        }
        return "";
    }

    /** 校验业务员填的制度编码是否存在；留空则按费用类型自动带出 */
    private String resolvePolicyCode(ExpenseType type, String policyCode) {
        if (Esc.blank(policyCode)) {
            String suggested = suggestPolicyCode(type);
            return Esc.blank(suggested) ? null : suggested;
        }
        if (policyService.findLatestByCode(policyCode.trim()) == null) {
            throw new ValidationException("制度编码 " + policyCode + " 不存在，请从制度列表中选择。");
        }
        return policyCode.trim();
    }

    private void validateFacts(ExpenseType type, BigDecimal amount, LocalDate occurredOn, String reason) {
        if (type == null) {
            throw new ValidationException("请选择费用类型。");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ValidationException("金额必须大于 0。");
        }
        if (amount.compareTo(MAX_AMOUNT) > 0) {
            throw new ValidationException("单张单据金额不能超过 " + MAX_AMOUNT.toPlainString() + " 元。");
        }
        if (occurredOn == null) {
            throw new ValidationException("请填写费用发生日期。");
        }
        if (occurredOn.isAfter(LocalDate.now())) {
            throw new ValidationException("费用发生日期不能晚于今天。");
        }
        if (Esc.blank(reason)) {
            throw new ValidationException("请填写费用事由，事由要能说明业务背景。");
        }
        if (reason.trim().length() > 500) {
            throw new ValidationException("费用事由不能超过 500 个字。");
        }
    }

    /** 单据号规则：BX + 发生年月 + 3 位流水，同月内递增 */
    private String nextDocNo(LocalDate occurredOn) {
        String prefix = "BX" + String.format("%04d%02d", occurredOn.getYear(), occurredOn.getMonthValue());
        for (int attempt = 0; attempt < 50; attempt++) {
            int max = 0;
            for (Document d : store.documents().findAll()) {
                String no = d.getDocNo();
                if (no != null && no.startsWith(prefix) && no.length() == prefix.length() + 3) {
                    try {
                        max = Math.max(max, Integer.parseInt(no.substring(prefix.length())));
                    } catch (NumberFormatException ignored) {
                        // 人工录入过的非常规单据号，跳过
                    }
                }
            }
            String candidate = prefix + String.format("%03d", max + 1);
            if (store.documents().findAll().stream().noneMatch(x -> candidate.equals(x.getDocNo()))) {
                return candidate;
            }
        }
        throw new ValidationException("同月单据号已用尽，请调整费用发生日期。");
    }

    // ==================== 页面上用的小统计 ====================

    public Map<DocStatus, Integer> countByStatus(List<Document> docs) {
        Map<DocStatus, Integer> map = new LinkedHashMap<DocStatus, Integer>();
        for (DocStatus s : DocStatus.values()) {
            map.put(s, Integer.valueOf(0));
        }
        for (Document d : docs) {
            map.put(d.getStatus(), Integer.valueOf(map.get(d.getStatus()).intValue() + 1));
        }
        return map;
    }

    public BigDecimal sumAmount(List<Document> docs) {
        BigDecimal total = BigDecimal.ZERO;
        for (Document d : docs) {
            if (d.getAmount() != null) {
                total = total.add(d.getAmount());
            }
        }
        return total;
    }
}
