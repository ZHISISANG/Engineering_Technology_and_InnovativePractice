package com.reimburse.service;

import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.store.Store;
import com.reimburse.util.Dates;
import com.reimburse.util.Esc;
import com.reimburse.util.PasswordUtil;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 账号管理。维护者：系统管理员。
 * 两条自保规则：管理员不能停用自己的账号，也不能把最后一个启用的管理员改掉或者停用，
 * 否则系统就没人能进后台了。
 */
public class UserService {

    private static final Pattern USERNAME_PATTERN = Pattern.compile("[A-Za-z0-9_]{3,32}");
    private static final int MIN_PASSWORD_LENGTH = 6;

    private final Store store;

    public UserService(Store store) {
        this.store = store;
    }

    public List<User> listAll(String keyword) {
        String kw = keyword == null ? "" : keyword.trim().toLowerCase();
        List<User> out = new ArrayList<User>();
        for (User u : store.users().findAll()) {
            if (!kw.isEmpty()
                    && !contains(u.getUsername(), kw)
                    && !contains(u.getDisplayName(), kw)
                    && !contains(u.getDept(), kw)
                    && !contains(u.getEmployeeNo(), kw)) {
                continue;
            }
            out.add(u);
        }
        out.sort(Comparator.comparingLong(User::getId));
        return out;
    }

    /** 业务员登记单据时可选的归属员工：账号启用的都算员工 */
    public List<User> selectableOwners() {
        List<User> out = new ArrayList<User>();
        for (User u : store.users().findAll()) {
            if (u.isEnabled()) {
                out.add(u);
            }
        }
        out.sort(Comparator.comparing(User::getDisplayName));
        return out;
    }

    public User findById(long id) {
        return store.users().findById(id);
    }

    public User create(User admin, String username, String displayName, Role role, String dept,
                       String employeeNo, String password) {
        if (Esc.blank(username) || !USERNAME_PATTERN.matcher(username.trim()).matches()) {
            throw new ValidationException("账号只能包含字母、数字和下划线，长度 3 到 32 位。");
        }
        if (store.users().findByUsername(username.trim()) != null) {
            throw new ValidationException("账号 " + username + " 已存在。");
        }
        validateProfile(displayName, role);
        validatePassword(password);

        User u = new User();
        u.setUsername(username.trim());
        u.setDisplayName(displayName.trim());
        u.setRole(role);
        u.setDept(Esc.blank(dept) ? null : dept.trim());
        u.setEmployeeNo(Esc.blank(employeeNo) ? null : employeeNo.trim());
        u.setEnabled(true);
        u.setCreatedAt(LocalDateTime.now());
        u.setSalt(PasswordUtil.newSalt());
        u.setPasswordHash(PasswordUtil.hash(password, u.getSalt()));
        store.users().save(u);
        return u;
    }

    /**
     * 修改账号资料。这里不提供改口令的入口，口令走 resetPassword()，
     * 因为"改资料"和"改凭据"是两种权限语义，混在一起容易出事。
     */
    public User update(User admin, long id, String displayName, Role role, String dept,
                       String employeeNo, boolean enabled) {
        User u = store.users().findById(id);
        if (u == null) {
            throw new ValidationException("账号不存在：id=" + id);
        }
        validateProfile(displayName, role);

        // 这个账号原本是启用状态的管理员，改动后不再是（被降级或被停用）就算"失去管理员"
        boolean losingAdmin = u.getRole() == Role.ADMIN && u.isEnabled() && (role != Role.ADMIN || !enabled);
        if (u.getId() == admin.getId() && !enabled) {
            throw new ValidationException("不能停用当前登录的管理员账号。");
        }
        if (losingAdmin && countOtherEnabledAdmins(u.getId()) == 0) {
            throw new ValidationException("系统至少要保留一个启用的管理员账号。");
        }

        u.setDisplayName(displayName.trim());
        u.setRole(role);
        u.setDept(Esc.blank(dept) ? null : dept.trim());
        u.setEmployeeNo(Esc.blank(employeeNo) ? null : employeeNo.trim());
        u.setEnabled(enabled);
        store.users().save(u);
        return u;
    }

    public void resetPassword(User admin, long id, String newPassword) {
        User u = store.users().findById(id);
        if (u == null) {
            throw new ValidationException("账号不存在：id=" + id);
        }
        validatePassword(newPassword);
        u.setSalt(PasswordUtil.newSalt());
        u.setPasswordHash(PasswordUtil.hash(newPassword, u.getSalt()));
        store.users().save(u);
    }

    /** 账号自己改口令：要先验旧口令 */
    public void changeOwnPassword(User actor, String oldPassword, String newPassword) {
        User u = store.users().findById(actor.getId());
        if (u == null) {
            throw new ValidationException("账号不存在。");
        }
        if (!PasswordUtil.verify(oldPassword, u.getSalt(), u.getPasswordHash())) {
            throw new ValidationException("原口令不正确。");
        }
        validatePassword(newPassword);
        u.setSalt(PasswordUtil.newSalt());
        u.setPasswordHash(PasswordUtil.hash(newPassword, u.getSalt()));
        store.users().save(u);
    }

    private long countOtherEnabledAdmins(long excludeId) {
        long n = 0;
        for (User u : store.users().findAll()) {
            if (u.getId() != excludeId && u.isEnabled() && u.getRole() == Role.ADMIN) {
                n++;
            }
        }
        return n;
    }

    private void validateProfile(String displayName, Role role) {
        if (Esc.blank(displayName)) {
            throw new ValidationException("姓名不能为空。");
        }
        if (displayName.trim().length() > 64) {
            throw new ValidationException("姓名不能超过 64 个字。");
        }
        if (role == null) {
            throw new ValidationException("请选择角色。");
        }
    }

    private void validatePassword(String password) {
        if (password == null || password.length() < MIN_PASSWORD_LENGTH) {
            throw new ValidationException("口令至少 " + MIN_PASSWORD_LENGTH + " 位。");
        }
        if (password.length() > 64) {
            throw new ValidationException("口令不能超过 64 位。");
        }
    }

    private static boolean contains(String text, String lowerKeyword) {
        return text != null && text.toLowerCase().contains(lowerKeyword);
    }

    /** 页面显示注册时间用 */
    public String createdAtText(User u) {
        return Dates.format(u.getCreatedAt(), "-");
    }
}
