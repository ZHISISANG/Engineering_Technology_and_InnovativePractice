package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * 员工自助查询制度（第一步需求）。
 * 列表只返回有效制度；详情也再判一次——把非有效制度的 id 直接填进 URL 同样会被拒并写审计，
 * 因为"员工只能看有效制度"是权限规则，不是页面过滤。
 */
public class PolicyServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("/policy/detail".equals(req.getServletPath())) {
            detail(req, resp);
        } else {
            list(req, resp);
        }
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);
        String keyword = Web.str(req, "keyword");
        String type = Web.str(req, "type");

        List<Policy> policies = services.policy().listEffective(keyword, type);
        services.audit().allow(user, AuditAction.QUERY_POLICY, "制度库",
                "关键字“" + Esc.nvl(keyword, "（空）") + "”，费用类型“" + typeLabel(type) + "”，命中 "
                        + policies.size() + " 条", Web.ip(req));

        req.setAttribute("policies", policies);
        req.setAttribute("keyword", keyword);
        req.setAttribute("type", type);
        req.setAttribute("types", ExpenseType.values());
        req.setAttribute("today", java.time.LocalDate.now().toString());
        Web.forward(req, resp, "employee/policy_list.jsp");
    }

    private void detail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);

        Policy policy = services.policy().findEffectiveById(id);
        if (policy == null) {
            Policy raw = services.policy().findById(id);
            if (raw == null) {
                Web.notFound(req, resp, "制度 id=" + id + " 不存在。");
                return;
            }
            services.audit().deny(user, AuditAction.DENIED, Web.targetOf(raw),
                    "尝试查看非有效制度（状态：" + raw.getStatus().getLabel() + "，有效期：" + raw.getEffectiveLabel() + "）",
                    Web.ip(req));
            Web.forbidden(req, resp, "《" + raw.getTitle() + "》当前不是有效制度（"
                    + services.policy().effectivenessText(raw) + "），员工只能查询有效制度。");
            return;
        }

        services.audit().allow(user, AuditAction.VIEW_POLICY, Web.targetOf(policy),
                "查看有效制度详情", Web.ip(req));
        req.setAttribute("policy", policy);
        Web.forward(req, resp, "employee/policy_detail.jsp");
    }

    private String typeLabel(String type) {
        return Esc.blank(type) ? "全部" : ExpenseType.of(type).getLabel();
    }
}
