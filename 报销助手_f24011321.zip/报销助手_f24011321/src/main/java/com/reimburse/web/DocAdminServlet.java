package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.service.ValidationException;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * 业务事实维护（业务员）。登记单据、修正事实、推进状态。
 *
 * 三个约束刻意做在服务端而不是靠页面限制：
 *   1) 归属员工只在登记时确定，之后不能改；
 *   2) 终态（已支付、已驳回）单据的事实冻结；
 *   3) 状态只能按顺序推进，驳回必须写原因。
 */
public class DocAdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getServletPath().endsWith("/edit")) {
            edit(req, resp);
        } else {
            list(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        if (path.endsWith("/save")) {
            save(req, resp);
        } else if (path.endsWith("/progress")) {
            progress(req, resp);
        } else {
            Web.notFound(req, resp, "未知操作：" + path);
        }
    }

    // ---------------- 列表 ----------------

    private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        String status = Web.str(req, "status");
        String keyword = Web.str(req, "keyword");
        String owner = Web.str(req, "owner");

        List<Document> documents = services.document().listForMaintenance(status, keyword, owner);
        req.setAttribute("documents", documents);
        req.setAttribute("status", status);
        req.setAttribute("keyword", keyword);
        req.setAttribute("owner", owner);
        req.setAttribute("statuses", DocStatus.values());
        req.setAttribute("statusCounts", services.document().countByStatus(
                services.document().listForMaintenance(null, null, null)));
        req.setAttribute("totalAmount", services.document().sumAmount(documents));
        Web.consumeFlash(req);
        Web.forward(req, resp, "clerk/doc_manage.jsp");
    }

    // ---------------- 登记 / 修改表单 ----------------

    private void edit(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        Document doc = id > 0 ? services.document().findById(id) : null;
        if (id > 0 && doc == null) {
            Web.notFound(req, resp, "单据 id=" + id + " 不存在。");
            return;
        }
        req.setAttribute("doc", doc);
        req.setAttribute("isNew", Boolean.valueOf(id <= 0));
        req.setAttribute("owners", services.user().selectableOwners());
        req.setAttribute("types", ExpenseType.values());
        // 制度依据只提供当前有效的制度，业务员不能把已废止的制度写成依据
        req.setAttribute("effectivePolicies", services.policy().listEffective(null, null));
        req.setAttribute("suggestedPolicy", services.document().suggestPolicyCode(
                doc == null ? ExpenseType.TRAVEL : doc.getExpenseType()));
        req.setAttribute("today", LocalDate.now().toString());
        Web.consumeFlash(req);
        Web.forward(req, resp, "clerk/doc_edit.jsp");
    }

    // ---------------- 保存业务事实 ----------------

    private void save(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        ExpenseType type = ExpenseType.of(Web.str(req, "expenseType"));
        BigDecimal amount = Web.decimal(req, "amount");
        LocalDate occurredOn = Web.date(req, "occurredOn");
        String reason = Web.str(req, "reason");
        String policyCode = Web.str(req, "policyCode");

        try {
            if (id <= 0) {
                Document created = services.document().create(actor, Web.lng(req, "ownerId", 0), type, amount,
                        occurredOn, reason, policyCode);
                services.audit().allow(actor, AuditAction.DOC_CREATE, Web.targetOf(created),
                        "登记单据：归属 " + created.getOwnerName() + "，类型 " + type.getLabel()
                                + "，金额 " + created.getAmount().toPlainString() + "，制度依据 "
                                + Esc.nvl(created.getPolicyCode(), "无"), Web.ip(req));
                Web.flash(req.getSession(), "ok", "单据 " + created.getDocNo() + " 已登记，当前状态："
                        + created.getStatus().getLabel() + "。");
            } else {
                Document before = services.document().findById(id);
                Document updated = services.document().updateFacts(actor, id, type, amount, occurredOn, reason, policyCode);
                services.audit().allow(actor, AuditAction.DOC_UPDATE, Web.targetOf(updated),
                        "修正业务事实：金额 " + amountOf(before) + " → " + updated.getAmount().toPlainString()
                                + "，类型 " + type.getLabel() + "，制度依据 "
                                + Esc.nvl(updated.getPolicyCode(), "无"), Web.ip(req));
                Web.flash(req.getSession(), "ok", "单据 " + updated.getDocNo() + " 的业务事实已更新。");
            }
            Web.redirect(req, resp, "/clerk/doc/list");
        } catch (ValidationException e) {
            backToEdit(req, resp, e.getMessage());
        }
    }

    // ---------------- 推进状态 ----------------

    private void progress(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        String targetText = Web.str(req, "target");
        try {
            DocStatus target = DocStatus.valueOf(targetText == null ? "" : targetText.trim().toUpperCase());
            Document before = services.document().findById(id);
            Document after = services.document().progress(actor, id, target, Web.str(req, "note"));
            String from = before == null ? "?" : before.getStatus().getLabel();
            services.audit().allow(actor, AuditAction.DOC_PROGRESS, Web.targetOf(after),
                    "状态 " + from + " → " + after.getStatus().getLabel() + "；经办说明："
                            + Esc.nvl(Web.str(req, "note"), "（沿用上一步说明）"), Web.ip(req));
            Web.flash(req.getSession(), "ok", "单据 " + after.getDocNo() + " 状态已更新为"
                    + after.getStatus().getLabel() + "。");
        } catch (IllegalArgumentException e) {
            Web.flash(req.getSession(), "error", "状态取值不正确。");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
        }
        Web.redirect(req, resp, "/clerk/doc/list");
    }

    // ---------------- 辅助 ----------------

    private void backToEdit(HttpServletRequest req, HttpServletResponse resp, String error)
            throws ServletException, IOException {
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        Document target = id > 0 ? services.document().findById(id) : null;
        Document form = target == null ? new Document() : target;
        form.setExpenseType(ExpenseType.of(Web.str(req, "expenseType")));
        form.setAmount(Web.decimal(req, "amount"));
        form.setOccurredOn(Web.date(req, "occurredOn"));
        form.setReason(Web.str(req, "reason"));
        form.setPolicyCode(Web.str(req, "policyCode"));

        req.setAttribute("doc", form);
        req.setAttribute("isNew", Boolean.valueOf(id <= 0));
        req.setAttribute("selectedOwnerId", Long.valueOf(Web.lng(req, "ownerId", 0)));
        req.setAttribute("error", error);
        req.setAttribute("owners", services.user().selectableOwners());
        req.setAttribute("types", ExpenseType.values());
        req.setAttribute("effectivePolicies", services.policy().listEffective(null, null));
        req.setAttribute("suggestedPolicy", Web.str(req, "policyCode"));
        req.setAttribute("today", LocalDate.now().toString());
        Web.forward(req, resp, "clerk/doc_edit.jsp");
    }

    private static String amountOf(Document d) {
        return d == null || d.getAmount() == null ? "?" : d.getAmount().toPlainString();
    }
}
