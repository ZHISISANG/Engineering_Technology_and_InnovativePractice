package com.reimburse.web;

import com.reimburse.model.Document;
import com.reimburse.model.Policy;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.store.AppConfig;
import com.reimburse.util.Dates;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Web 层公共工具：取服务、取当前登录人、参数解析、页面跳转、审计对象的命名。
 * 命名统一放在这里，是为了让"单据 XXX"这类审计目标在写入与查询两侧永远一致。
 */
public final class Web {

    public static final String SESSION_USER = "user";
    public static final String VIEW_PREFIX = "/WEB-INF/views/";

    private static final String FLASH_MESSAGE = "flash.message";
    private static final String FLASH_TYPE = "flash.type";

    private Web() {
    }

    public static Services services(ServletContext ctx) {
        return (Services) ctx.getAttribute(Services.CONTEXT_ATTRIBUTE);
    }

    public static Services services(HttpServletRequest req) {
        return services(req.getServletContext());
    }

    public static AppConfig config(ServletContext ctx) {
        return (AppConfig) ctx.getAttribute(AppBootstrap.CONFIG_ATTRIBUTE);
    }

    public static User currentUser(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return session == null ? null : (User) session.getAttribute(SESSION_USER);
    }

    public static String ip(HttpServletRequest req) {
        String forwarded = req.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.trim().isEmpty()) {
            int comma = forwarded.indexOf(',');
            return comma > 0 ? forwarded.substring(0, comma).trim() : forwarded.trim();
        }
        return req.getRemoteAddr();
    }

    // ---------------- 参数 ----------------

    public static String str(HttpServletRequest req, String name) {
        String v = req.getParameter(name);
        return v == null ? null : v.trim();
    }

    public static long lng(HttpServletRequest req, String name, long dft) {
        String v = str(req, name);
        if (Esc.blank(v)) {
            return dft;
        }
        try {
            return Long.parseLong(v);
        } catch (NumberFormatException e) {
            return dft;
        }
    }

    public static BigDecimal decimal(HttpServletRequest req, String name) {
        String v = str(req, name);
        if (Esc.blank(v)) {
            return null;
        }
        try {
            return new BigDecimal(v.replace(",", ""));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static LocalDate date(HttpServletRequest req, String name) {
        return Dates.parseDate(str(req, name));
    }

    public static boolean check(HttpServletRequest req, String name) {
        String v = str(req, name);
        return "on".equalsIgnoreCase(v) || "true".equalsIgnoreCase(v) || "1".equals(v);
    }

    // ---------------- 跳转 ----------------

    public static void forward(HttpServletRequest req, HttpServletResponse resp, String view)
            throws ServletException, IOException {
        req.getRequestDispatcher(VIEW_PREFIX + view).forward(req, resp);
    }

    public static void redirect(HttpServletRequest req, HttpServletResponse resp, String path) throws IOException {
        resp.sendRedirect(req.getContextPath() + path);
    }

    public static void forbidden(HttpServletRequest req, HttpServletResponse resp, String reason)
            throws ServletException, IOException {
        resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
        req.setAttribute("reason", reason);
        req.getRequestDispatcher(VIEW_PREFIX + "error/403.jsp").forward(req, resp);
    }

    public static void notFound(HttpServletRequest req, HttpServletResponse resp, String what)
            throws ServletException, IOException {
        resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
        req.setAttribute("reason", what);
        req.getRequestDispatcher(VIEW_PREFIX + "error/404.jsp").forward(req, resp);
    }

    // ---------------- 一次性提示 ----------------

    public static void flash(HttpSession session, String type, String message) {
        if (session != null) {
            session.setAttribute(FLASH_MESSAGE, message);
            session.setAttribute(FLASH_TYPE, type);
        }
    }

    /** 取出提示并从会话里清掉，避免刷新页面反复弹 */
    public static void consumeFlash(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) {
            return;
        }
        Object message = session.getAttribute(FLASH_MESSAGE);
        if (message != null) {
            req.setAttribute("flashMessage", message);
            req.setAttribute("flashType", session.getAttribute(FLASH_TYPE));
            session.removeAttribute(FLASH_MESSAGE);
            session.removeAttribute(FLASH_TYPE);
        }
    }

    // ---------------- 审计目标命名 ----------------

    public static String targetOf(Document d) {
        return "单据 " + d.getDocNo();
    }

    public static String targetOf(Policy p) {
        return "制度 " + p.getCode() + " " + p.getVersionLabel();
    }

    public static String targetOf(User u) {
        return "账号 " + u.getUsername();
    }
}
