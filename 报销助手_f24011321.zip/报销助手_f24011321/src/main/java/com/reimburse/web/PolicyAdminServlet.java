package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.ExpenseType;
import com.reimburse.model.Policy;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.service.ValidationException;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

/**
 * 制度维护（专员）。新增、修订、发布、废止四个动作。
 *
 * 这里体现"制度由专员维护"：映射在 /specialist/* 下，RoleFilter 已经挡住其它角色；
 * 每一步都写审计，制度的版本变化要能追溯是谁在什么时候改的。
 */
public class PolicyAdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (req.getServletPath().endsWith("/edit")) {
            edit(req, resp);
        } else {
            list(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        if (path.endsWith("/save")) {
            save(req, resp);
        } else if (path.endsWith("/publish")) {
            publish(req, resp);
        } else if (path.endsWith("/repeal")) {
            repeal(req, resp);
        } else {
            Web.notFound(req, resp, "未知操作：" + path);
        }
    }

    // ---------------- 列表 ----------------

    private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        String keyword = Web.str(req, "keyword");
        List<Policy> policies = services.policy().listForMaintenance(keyword);
        req.setAttribute("policies", policies);
        req.setAttribute("keyword", keyword);
        req.setAttribute("today", LocalDate.now().toString());
        Web.consumeFlash(req);
        Web.forward(req, resp, "specialist/policy_manage.jsp");
    }

    // ---------------- 新增 / 修订表单 ----------------

    private void edit(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        Policy policy = id > 0 ? services.policy().findById(id) : null;
        if (id > 0 && policy == null) {
            Web.notFound(req, resp, "制度 id=" + id + " 不存在。");
            return;
        }
        req.setAttribute("policy", policy);
        req.setAttribute("isNew", Boolean.valueOf(id <= 0));
        req.setAttribute("types", ExpenseType.values());
        req.setAttribute("versions", policy == null
                ? Collections.emptyList()
                : services.policy().findByCode(policy.getCode()));
        req.setAttribute("today", LocalDate.now().toString());
        Web.consumeFlash(req);
        Web.forward(req, resp, "specialist/policy_edit.jsp");
    }

    // ---------------- 保存（新增或修订） ----------------

    private void save(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        String content = Web.str(req, "content");
        String changeNote = Web.str(req, "changeNote");

        try {
            if (id <= 0) {
                LocalDate from = Web.date(req, "effectiveFrom");
                LocalDate to = Web.date(req, "effectiveTo");
                boolean publishNow = Web.check(req, "publishNow");
                String appliesTo = joinTypes(req.getParameterValues("appliesTo"));

                Policy created = services.policy().create(actor, Web.str(req, "code"), Web.str(req, "title"),
                        Web.str(req, "category"), appliesTo, content, from, to, changeNote, publishNow);
                services.audit().allow(actor, AuditAction.POLICY_CREATE, Web.targetOf(created),
                        (publishNow ? "新增并发布" : "新增草稿") + "；分类 " + created.getCategory()
                                + "；适用 " + ExpenseType.labelsOf(created.getAppliesTo()), Web.ip(req));
                Web.flash(req.getSession(), "ok", "制度《" + created.getTitle() + "》"
                        + (publishNow ? "已发布生效。" : "已保存为草稿，发布后员工才能查到。"));
            } else {
                Policy revised = services.policy().revise(actor, id, content, changeNote);
                services.audit().allow(actor, AuditAction.POLICY_REVISE, Web.targetOf(revised),
                        "基于 id=" + id + " 生成 " + revised.getVersionLabel() + " 草稿；修订说明："
                                + Esc.nvl(changeNote, "（未填）"), Web.ip(req));
                Web.flash(req.getSession(), "ok", "已生成 " + revised.getVersionLabel()
                        + " 草稿。修订内容要发布后才对员工生效。");
            }
            Web.redirect(req, resp, "/specialist/policy/list");
        } catch (ValidationException e) {
            backToEdit(req, resp, e.getMessage());
        }
    }

    // ---------------- 发布 / 废止 ----------------

    private void publish(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        try {
            Policy p = services.policy().publish(actor, id, Web.date(req, "effectiveFrom"),
                    Web.date(req, "effectiveTo"), Web.str(req, "changeNote"));
            services.audit().allow(actor, AuditAction.POLICY_PUBLISH, Web.targetOf(p),
                    "生效期 " + p.getEffectiveLabel() + "；同编码其它生效版本已自动置为废止", Web.ip(req));
            Web.flash(req.getSession(), "ok", "《" + p.getTitle() + "》" + p.getVersionLabel()
                    + " 已发布，有效期 " + p.getEffectiveLabel() + "。");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
        }
        Web.redirect(req, resp, "/specialist/policy/list");
    }

    private void repeal(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        try {
            Policy before = services.policy().findById(id);
            services.policy().repeal(actor, id);
            String target = before == null ? "制度 #" + id : Web.targetOf(before);
            services.audit().allow(actor, AuditAction.POLICY_REPEAL, target, "废止该版本，员工将不再能查到", Web.ip(req));
            Web.flash(req.getSession(), "ok", "该版本已废止。");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
        }
        Web.redirect(req, resp, "/specialist/policy/list");
    }

    // ---------------- 辅助 ----------------

    /** 表单校验失败时回填已填写的内容，避免用户重打一遍 */
    private void backToEdit(HttpServletRequest req, HttpServletResponse resp, String error)
            throws ServletException, IOException {
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        Policy source = id > 0 ? services.policy().findById(id) : null;
        Policy form = source == null ? new Policy() : source;
        if (id <= 0) {
            form.setCode(Web.str(req, "code"));
            form.setTitle(Web.str(req, "title"));
            form.setCategory(Web.str(req, "category"));
            form.setAppliesTo(joinTypes(req.getParameterValues("appliesTo")));
            form.setEffectiveFrom(Web.date(req, "effectiveFrom"));
            form.setEffectiveTo(Web.date(req, "effectiveTo"));
        }
        form.setContent(Web.str(req, "content"));
        form.setChangeNote(Web.str(req, "changeNote"));

        req.setAttribute("policy", form);
        req.setAttribute("isNew", Boolean.valueOf(id <= 0));
        req.setAttribute("error", error);
        req.setAttribute("types", ExpenseType.values());
        req.setAttribute("versions", source == null ? Collections.emptyList() : services.policy().findByCode(source.getCode()));
        req.setAttribute("today", LocalDate.now().toString());
        Web.forward(req, resp, "specialist/policy_edit.jsp");
    }

    /** 多选框值合成 "TRAVEL,OFFICE" 存一格，与制度的 applies_to 字段对应 */
    private static String joinTypes(String[] values) {
        if (values == null || values.length == 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (String v : values) {
            if (Esc.blank(v)) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(ExpenseType.of(v).name());
        }
        return sb.length() == 0 ? null : sb.toString();
    }
}
