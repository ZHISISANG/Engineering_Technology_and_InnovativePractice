package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.DocStatus;
import com.reimburse.model.Document;
import com.reimburse.model.Policy;
import com.reimburse.model.User;
import com.reimburse.service.AccessDeniedException;
import com.reimburse.service.Services;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * 经授权查询本人单据状态（第二步需求）。
 *
 * 授权判定在 DocumentService.findOwn()：单据存在但不属于当前账号 → AccessDeniedException，
 * 这里转 403 并写 DENY 审计。也就是说，把 id 改成别人的单据号，看到的只会是拒绝页。
 */
public class MyDocServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("/mydoc/detail".equals(req.getServletPath())) {
            detail(req, resp);
        } else {
            list(req, resp);
        }
    }

    private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);
        String status = Web.str(req, "status");
        String keyword = Web.str(req, "keyword");

        List<Document> documents = services.document().listOwn(user, status, keyword);
        services.audit().allow(user, AuditAction.LIST_OWN_DOC, "本人单据",
                "状态“" + statusLabel(status) + "”，关键字“" + Esc.nvl(keyword, "（空）") + "”，返回 "
                        + documents.size() + " 条（归属人 " + user.getDisplayName() + "）", Web.ip(req));

        req.setAttribute("documents", documents);
        req.setAttribute("statusCounts", services.document().countByStatus(services.document().listOwn(user, null, null)));
        req.setAttribute("totalAmount", services.document().sumAmount(documents));
        req.setAttribute("status", status);
        req.setAttribute("keyword", keyword);
        req.setAttribute("statuses", DocStatus.values());
        Web.forward(req, resp, "employee/my_docs.jsp");
    }

    private void detail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);

        Document doc;
        try {
            doc = services.document().findOwn(user, id);
        } catch (AccessDeniedException e) {
            services.audit().deny(user, AuditAction.DENIED, "单据 #" + id, e.getMessage(), Web.ip(req));
            Web.forbidden(req, resp, e.getMessage());
            return;
        }
        if (doc == null) {
            Web.notFound(req, resp, "单据 id=" + id + " 不存在。");
            return;
        }

        services.audit().allow(user, AuditAction.VIEW_OWN_DOC, Web.targetOf(doc),
                "查询本人单据状态（当前：" + doc.getStatus().getLabel() + "）", Web.ip(req));

        // 制度依据：优先给当前生效的那一版，否则给最新版本并标注"当前不适用"
        Policy effective = services.policy().findEffectiveByCode(doc.getPolicyCode());
        Policy latest = services.policy().findLatestByCode(doc.getPolicyCode());
        Policy reference = effective != null ? effective : latest;

        req.setAttribute("doc", doc);
        req.setAttribute("policyRef", reference);
        req.setAttribute("policyRefEffective", Boolean.valueOf(effective != null));
        req.setAttribute("history", services.audit().historyFor(Web.targetOf(doc)));
        Web.forward(req, resp, "employee/doc_detail.jsp");
    }

    private String statusLabel(String status) {
        if (Esc.blank(status)) {
            return "全部";
        }
        try {
            return DocStatus.valueOf(status.trim().toUpperCase()).getLabel();
        } catch (IllegalArgumentException e) {
            return "全部";
        }
    }
}
