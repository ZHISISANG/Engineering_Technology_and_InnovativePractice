package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.service.ValidationException;
import com.reimburse.store.AppConfig;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * 登录、注销、修改本人密码。
 * 登录成功后换一个新会话（旧的 invalidate 掉），避免会话固定攻击——攻击者先给受害者一个已知会话号的路子就堵住了。
 */
public class AuthServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        if ("/logout".equals(path)) {
            logout(req, resp);
            return;
        }
        if ("/profile".equals(path)) {
            Web.forward(req, resp, "profile.jsp");
            return;
        }
        if (Web.currentUser(req) != null) {
            Web.redirect(req, resp, "/home");
            return;
        }
        Web.forward(req, resp, "login.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if ("/profile".equals(req.getServletPath())) {
            saveProfile(req, resp);
            return;
        }
        login(req, resp);
    }

    private void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        String username = Web.str(req, "username");
        String password = req.getParameter("password");

        User user = services.auth().authenticate(username, password, Web.ip(req));
        if (user == null) {
            // 不区分"账号不存在"和"口令错误"，避免被用来枚举账号
            req.setAttribute("error", "账号或口令不正确，或账号已被停用。");
            req.setAttribute("username", username);
            Web.forward(req, resp, "login.jsp");
            return;
        }

        HttpSession existing = req.getSession(false);
        if (existing != null) {
            existing.invalidate();
        }
        HttpSession session = req.getSession(true);
        session.setAttribute(Web.SESSION_USER, user);
        AppConfig config = Web.config(req.getServletContext());
        if (config != null) {
            session.setMaxInactiveInterval(config.getSessionTimeoutMinutes() * 60);
        }
        Web.redirect(req, resp, "/home");
    }

    private void logout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User user = Web.currentUser(req);
        if (user != null) {
            Web.services(req).audit().allow(user, AuditAction.LOGOUT, "会话", "主动注销", Web.ip(req));
        }
        HttpSession session = req.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        Web.redirect(req, resp, "/login");
    }

    private void saveProfile(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);
        try {
            services.user().changeOwnPassword(user, req.getParameter("oldPassword"), req.getParameter("newPassword"));
            services.audit().allow(user, AuditAction.USER_RESET, Web.targetOf(user), "本人自助修改口令", Web.ip(req));
            Web.flash(req.getSession(), "ok", "口令已更新，下次登录请使用新口令。");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
        }
        Web.redirect(req, resp, "/profile");
    }
}
