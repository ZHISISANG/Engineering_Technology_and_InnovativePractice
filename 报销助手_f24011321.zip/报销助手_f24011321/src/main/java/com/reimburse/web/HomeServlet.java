package com.reimburse.web;

import com.reimburse.model.Document;
import com.reimburse.model.Policy;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.service.Services;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * 首页。四个角色看到的是同一页的不同区块：
 * 所有人都能看到"有效制度"和"我的单据"，维护入口按角色出现。
 */
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = Web.currentUser(req);
        Services services = Web.services(req);

        // 每个人都能用：有效制度 + 我的单据
        List<Policy> effective = services.policy().listEffective(null, null);
        req.setAttribute("effectivePolicies", effective.size() > 5 ? effective.subList(0, 5) : effective);
        req.setAttribute("effectivePolicyCount", Integer.valueOf(effective.size()));

        List<Document> own = services.document().listOwn(user, null, null);
        req.setAttribute("ownDocuments", own);
        req.setAttribute("ownStatusCounts", services.document().countByStatus(own));
        req.setAttribute("ownAmount", services.document().sumAmount(own));

        // 业务员：全部单据的待办规模
        if (user.getRole().canMaintainDocument()) {
            List<Document> all = services.document().listForMaintenance(null, null, null);
            req.setAttribute("allDocumentCount", Integer.valueOf(all.size()));
            req.setAttribute("pendingCount", Integer.valueOf(
                    services.document().listForMaintenance("SUBMITTED", null, null).size()
                            + services.document().listForMaintenance("REVIEWING", null, null).size()));
        }

        // 专员：制度总数、草稿数、当前有效数
        if (user.getRole().canMaintainPolicy()) {
            List<Policy> all = services.policy().listForMaintenance(null);
            int draft = 0;
            int active = 0;
            for (Policy p : all) {
                if (p.getStatus() == com.reimburse.model.PolicyStatus.DRAFT) {
                    draft++;
                }
                if (services.policy().isEffective(p)) {
                    active++;
                }
            }
            req.setAttribute("policyTotalCount", Integer.valueOf(all.size()));
            req.setAttribute("policyDraftCount", Integer.valueOf(draft));
            req.setAttribute("policyActiveCount", Integer.valueOf(active));
        }

        // 管理员：账号数与最近的越权尝试
        if (user.getRole().canAdminister()) {
            req.setAttribute("userCount", Integer.valueOf(services.user().listAll(null).size()));
            req.setAttribute("deniedLogs", services.audit().denied(5));
            req.setAttribute("auditCount", Long.valueOf(services.audit().count()));
        }

        req.setAttribute("storage", services.storageDescription());
        req.setAttribute("roles", Role.values());
        Web.consumeFlash(req);
        Web.forward(req, resp, "home.jsp");
    }
}
