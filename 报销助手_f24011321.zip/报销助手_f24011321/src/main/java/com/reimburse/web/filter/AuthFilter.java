package com.reimburse.web.filter;

import com.reimburse.web.Web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * 登录拦截：没登录就送回登录页。
 * 白名单只放登录接口、入口跳转页和样式表——数据页面一律在 /WEB-INF/views 下，
 * 浏览器无法直接请求，只能由 Servlet 转发出来。
 */
public class AuthFilter implements Filter {

    private static final String[] PUBLIC_PATHS = {"/login", "/index.jsp", "/css/", "/favicon.ico"};

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String path = req.getRequestURI().substring(req.getContextPath().length());
        if (isPublic(path) || Web.currentUser(req) != null) {
            chain.doFilter(request, response);
            return;
        }
        Web.redirect(req, resp, "/login");
    }

    private boolean isPublic(String path) {
        for (String prefix : PUBLIC_PATHS) {
            if (path.equals(prefix) || path.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }
}
