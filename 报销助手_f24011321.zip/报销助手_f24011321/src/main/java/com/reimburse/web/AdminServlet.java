package com.reimburse.web;

import com.reimburse.model.AuditAction;
import com.reimburse.model.AuditLog;
import com.reimburse.model.AuditResult;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.service.ValidationException;
import com.reimburse.util.Esc;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 账号维护与审计查询（管理员）。
 * 管理员在这里有权限，但进不了 /specialist/* 和 /clerk/*——职责分离不是靠自觉。
 */
public class AdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        if (path.endsWith("/audit/list")) {
            auditList(req, resp);
        } else if (path.endsWith("/user/edit")) {
            userEdit(req, resp);
        } else {
            userList(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String path = req.getServletPath();
        if (path.endsWith("/user/save")) {
            userSave(req, resp);
        } else if (path.endsWith("/user/reset")) {
            userReset(req, resp);
        } else {
            Web.notFound(req, resp, "未知操作：" + path);
        }
    }

    // ---------------- 账号 ----------------

    private void userList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        String keyword = Web.str(req, "keyword");
        req.setAttribute("users", services.user().listAll(keyword));
        req.setAttribute("keyword", keyword);
        req.setAttribute("roles", Role.values());
        Web.consumeFlash(req);
        Web.forward(req, resp, "admin/user_manage.jsp");
    }

    private void userEdit(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        User user = id > 0 ? services.user().findById(id) : null;
        if (id > 0 && user == null) {
            Web.notFound(req, resp, "账号 id=" + id + " 不存在。");
            return;
        }
        req.setAttribute("editUser", user);
        req.setAttribute("isNew", Boolean.valueOf(id <= 0));
        req.setAttribute("roles", Role.values());
        Web.consumeFlash(req);
        Web.forward(req, resp, "admin/user_edit.jsp");
    }

    private void userSave(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        try {
            Role role = parseRole(Web.str(req, "role"));
            if (id <= 0) {
                User created = services.user().create(actor, Web.str(req, "username"), Web.str(req, "displayName"),
                        role, Web.str(req, "dept"), Web.str(req, "employeeNo"), req.getParameter("password"));
                services.audit().allow(actor, AuditAction.USER_SAVE, Web.targetOf(created),
                        "新增账号，角色 " + role.getLabel() + "，部门 " + Esc.nvl(created.getDept(), "-"), Web.ip(req));
                Web.flash(req.getSession(), "ok", "账号 " + created.getUsername() + " 已创建。");
            } else {
                User before = services.user().findById(id);
                User updated = services.user().update(actor, id, Web.str(req, "displayName"), role,
                        Web.str(req, "dept"), Web.str(req, "employeeNo"), Web.check(req, "enabled"));
                services.audit().allow(actor, AuditAction.USER_SAVE, Web.targetOf(updated),
                        "修改账号：角色 " + roleOf(before) + " → " + role.getLabel()
                                + "，启用 " + enabledOf(before) + " → " + (updated.isEnabled() ? "是" : "否"), Web.ip(req));
                Web.flash(req.getSession(), "ok", "账号 " + updated.getUsername() + " 已更新。");
            }
            Web.redirect(req, resp, "/admin/user/list");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
            Web.redirect(req, resp, "/admin/user/edit?id=" + id);
        }
    }

    private void userReset(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User actor = Web.currentUser(req);
        Services services = Web.services(req);
        long id = Web.lng(req, "id", 0);
        try {
            User target = services.user().findById(id);
            services.user().resetPassword(actor, id, req.getParameter("newPassword"));
            services.audit().allow(actor, AuditAction.USER_RESET,
                    target == null ? "账号 #" + id : Web.targetOf(target),
                    "管理员重置口令", Web.ip(req));
            Web.flash(req.getSession(), "ok", "口令已重置。");
        } catch (ValidationException e) {
            Web.flash(req.getSession(), "error", e.getMessage());
        }
        Web.redirect(req, resp, "/admin/user/list");
    }

    // ---------------- 审计 ----------------

    private void auditList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Services services = Web.services(req);
        String action = Web.str(req, "action");
        String result = Web.str(req, "result");
        int limit = (int) Web.lng(req, "limit", 200);

        List<AuditLog> logs = new ArrayList<AuditLog>();
        for (AuditLog log : services.audit().recent(limit)) {
            if (!Esc.blank(action) && (log.getAction() == null || !action.equalsIgnoreCase(log.getAction().name()))) {
                continue;
            }
            if (!Esc.blank(result) && (log.getResult() == null || !result.equalsIgnoreCase(log.getResult().name()))) {
                continue;
            }
            logs.add(log);
        }
        req.setAttribute("logs", logs);
        req.setAttribute("action", action);
        req.setAttribute("result", result);
        req.setAttribute("limit", Integer.valueOf(limit));
        req.setAttribute("actions", AuditAction.values());
        req.setAttribute("results", AuditResult.values());
        req.setAttribute("totalCount", Long.valueOf(services.audit().count()));
        Web.consumeFlash(req);
        Web.forward(req, resp, "admin/audit_log.jsp");
    }

    // ---------------- 辅助 ----------------

    private static Role parseRole(String text) {
        try {
            return Role.valueOf(text == null ? "" : text.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new ValidationException("请选择有效的角色。");
        }
    }

    private static String roleOf(User u) {
        return u == null || u.getRole() == null ? "?" : u.getRole().getLabel();
    }

    private static String enabledOf(User u) {
        return u == null ? "?" : (u.isEnabled() ? "是" : "否");
    }
}
