package com.reimburse.web.filter;

import com.reimburse.model.AuditAction;
import com.reimburse.model.Role;
import com.reimburse.model.User;
import com.reimburse.service.Services;
import com.reimburse.web.Web;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * 角色拦截：/specialist/* 只给专员，/clerk/* 只给业务员，/admin/* 只给管理员。
 *
 * 这里是职责分离的执行点：管理员也进不了制度维护和业务事实维护。
 * 被拦下的请求会写一条 DENY 审计——"谁试过动不该动的功能"要留痕。
 */
public class RoleFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        User user = Web.currentUser(req);
        if (user == null) {
            // 未登录由 AuthFilter 处理，这里不重复拦
            chain.doFilter(request, response);
            return;
        }

        String path = req.getRequestURI().substring(req.getContextPath().length());
        Role required = requiredRole(path);
        if (required != null && user.getRole() != required) {
            Services services = Web.services(req);
            services.audit().deny(user, AuditAction.DENIED, "功能 " + path,
                    "角色“" + user.getRole().getLabel() + "”无权访问“" + required.getLabel() + "”的功能模块",
                    Web.ip(req));
            Web.forbidden(req, resp, "当前账号角色为“" + user.getRole().getLabel()
                    + "”，不能访问“" + required.getLabel() + "”的功能模块。");
            return;
        }
        chain.doFilter(request, response);
    }

    private Role requiredRole(String path) {
        if (path.startsWith("/specialist/")) {
            return Role.SPECIALIST;
        }
        if (path.startsWith("/clerk/")) {
            return Role.CLERK;
        }
        if (path.startsWith("/admin/")) {
            return Role.ADMIN;
        }
        return null;
    }
}
