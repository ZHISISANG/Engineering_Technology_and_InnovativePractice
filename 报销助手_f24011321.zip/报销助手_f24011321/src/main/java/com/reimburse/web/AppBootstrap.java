package com.reimburse.web;

import com.reimburse.service.Services;
import com.reimburse.store.AppConfig;
import com.reimburse.store.Store;
import com.reimburse.store.StoreException;
import com.reimburse.store.StoreFactory;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * 启动入口（web.xml 里注册为 listener）。做三件事：
 *   1) 读 WEB-INF/config/app.properties，决定用文件版还是数据库版；
 *   2) 数据库版要执行 WEB-INF/sql/schema-h2.sql 建表；
 *   3) 首次启动灌入演示数据，然后把手里的 Store 包成 Services 放进 ServletContext。
 * 这些只做一次，请求进来时直接用现成的 Store——文件版和数据库版都不适合每请求重建。
 */
public class AppBootstrap implements ServletContextListener {

    public static final String CONFIG_ATTRIBUTE = "com.reimburse.config";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext ctx = sce.getServletContext();
        AppConfig config = new AppConfig();
        try {
            Properties props = new Properties();
            InputStream in = ctx.getResourceAsStream("/WEB-INF/config/app.properties");
            if (in != null) {
                try (InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                    props.load(reader);
                }
            }
            config = AppConfig.from(props);

            String schema = readText(ctx, "/WEB-INF/sql/schema-h2.sql");
            Store store = StoreFactory.create(config, schema);
            store.initAndSeedIfEmpty();

            ctx.setAttribute(CONFIG_ATTRIBUTE, config);
            ctx.setAttribute(Services.CONTEXT_ATTRIBUTE, new Services(store));
            ctx.log("报销助手启动完成 | 存储=" + config.getStorage() + " | 数据目录=" + config.getDataDir()
                    + " | 账号数=" + store.users().count()
                    + " | 制度数=" + store.policies().count()
                    + " | 单据数=" + store.documents().count());
        } catch (IOException e) {
            throw new StoreException("读取配置或建表脚本失败", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        sce.getServletContext().log("报销助手已停止");
    }

    private static String readText(ServletContext ctx, String path) throws IOException {
        InputStream in = ctx.getResourceAsStream(path);
        if (in == null) {
            return "";
        }
        try (InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[4096];
            int n;
            while ((n = reader.read(buf)) > 0) {
                sb.append(buf, 0, n);
            }
            return sb.toString();
        }
    }
}
