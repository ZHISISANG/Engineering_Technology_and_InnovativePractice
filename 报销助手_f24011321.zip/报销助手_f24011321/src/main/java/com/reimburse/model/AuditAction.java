package com.reimburse.model;

/**
 * 审计动作。查询类与维护类分开命名，便于在审计日志里区分
 * "谁查了制度"、"谁改了业务事实"、"谁试图越权"。
 */
public enum AuditAction {
    LOGIN("登录成功"),
    LOGIN_FAIL("登录失败"),
    LOGOUT("注销"),
    QUERY_POLICY("查询有效制度"),
    VIEW_POLICY("查看制度详情"),
    LIST_OWN_DOC("查询本人单据列表"),
    VIEW_OWN_DOC("查询本人单据状态"),
    DENIED("越权访问被拒绝"),
    POLICY_CREATE("新增制度"),
    POLICY_REVISE("修订制度"),
    POLICY_PUBLISH("发布制度"),
    POLICY_REPEAL("废止制度"),
    DOC_CREATE("登记单据"),
    DOC_UPDATE("修改单据事实"),
    DOC_PROGRESS("推进单据状态"),
    USER_SAVE("维护账号"),
    USER_RESET("重置密码");

    private final String label;

    AuditAction(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
