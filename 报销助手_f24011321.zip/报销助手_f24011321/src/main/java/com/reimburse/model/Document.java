package com.reimburse.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 报销单据，属于"业务事实"。ownerId 是归属员工，员工只能查自己的单据；
 * 业务员维护金额、事由、状态等客观事实，但不能改归属。
 * policyCode 指向当时适用的制度，用于事后说明"这条单据按哪版制度办的"。
 */
public class Document {
    private long id;
    private String docNo;
    private long ownerId;
    private String ownerName;
    private ExpenseType expenseType = ExpenseType.OTHER;
    private BigDecimal amount = BigDecimal.ZERO;
    private LocalDate occurredOn;
    private String reason;
    private DocStatus status = DocStatus.SUBMITTED;
    private String handler;
    private String handleNote;
    private String policyCode;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getDocNo() { return docNo; }
    public void setDocNo(String docNo) { this.docNo = docNo; }

    public long getOwnerId() { return ownerId; }
    public void setOwnerId(long ownerId) { this.ownerId = ownerId; }

    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }

    public ExpenseType getExpenseType() { return expenseType; }
    public void setExpenseType(ExpenseType expenseType) { this.expenseType = expenseType; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public LocalDate getOccurredOn() { return occurredOn; }
    public void setOccurredOn(LocalDate occurredOn) { this.occurredOn = occurredOn; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public DocStatus getStatus() { return status; }
    public void setStatus(DocStatus status) { this.status = status; }

    public String getHandler() { return handler; }
    public void setHandler(String handler) { this.handler = handler; }

    public String getHandleNote() { return handleNote; }
    public void setHandleNote(String handleNote) { this.handleNote = handleNote; }

    public String getPolicyCode() { return policyCode; }
    public void setPolicyCode(String policyCode) { this.policyCode = policyCode; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public boolean isOwnedBy(User user) {
        return user != null && user.getId() == ownerId;
    }
}
