package com.reimburse.model;

/** 审计结果。DENY 记录的是被服务端拦下的越权尝试，不是前端隐藏菜单。 */
public enum AuditResult {
    ALLOW("放行"),
    DENY("拒绝");

    private final String label;

    AuditResult(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
