package com.reimburse.model;

/** 费用类型。制度的 appliesTo 用同一套代码，用来把制度和单据挂上关系。 */
public enum ExpenseType {
    TRAVEL("差旅费"),
    OFFICE("办公费"),
    ENTERTAIN("业务招待费"),
    TRAINING("培训费"),
    OTHER("其他");

    private final String label;

    ExpenseType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static ExpenseType of(String name) {
        if (name == null) {
            return OTHER;
        }
        for (ExpenseType t : values()) {
            if (t.name().equalsIgnoreCase(name.trim())) {
                return t;
            }
        }
        return OTHER;
    }

    /** 制度 appliesTo 字段的解析：支持 "TRAVEL,OFFICE" 这种多值写法。 */
    public static boolean matches(String appliesTo, ExpenseType type) {
        if (appliesTo == null || appliesTo.trim().isEmpty() || type == null) {
            return false;
        }
        for (String part : appliesTo.split(",")) {
            if (part.trim().equalsIgnoreCase(type.name())) {
                return true;
            }
        }
        return false;
    }

    /** 把 "TRAVEL,OFFICE" 显示成"差旅费、办公费"；空值表示不限费用类型。 */
    public static String labelsOf(String appliesTo) {
        if (appliesTo == null || appliesTo.trim().isEmpty()) {
            return "全部费用类型";
        }
        StringBuilder sb = new StringBuilder();
        for (String part : appliesTo.split(",")) {
            if (part.trim().isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append('、');
            }
            sb.append(of(part).getLabel());
        }
        return sb.length() == 0 ? "全部费用类型" : sb.toString();
    }
}
