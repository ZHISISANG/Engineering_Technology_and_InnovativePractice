package com.reimburse.model;

/** 单据状态。推进顺序见 DocStatus.next()。 */
public enum DocStatus {
    SUBMITTED("已提交"),
    REVIEWING("审核中"),
    APPROVED("审核通过"),
    REJECTED("已驳回"),
    PAID("已支付");

    private final String label;

    DocStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** 正常流转的下一步；REJECTED 与 PAID 是终态，没有下一步。 */
    public DocStatus next() {
        switch (this) {
            case SUBMITTED: return REVIEWING;
            case REVIEWING: return APPROVED;
            case APPROVED:  return PAID;
            default:        return null;
        }
    }

    /** 终态不可再流转，业务员只能在非终态单据上推进。 */
    public boolean isFinal() {
        return this == REJECTED || this == PAID;
    }

    public boolean isRejected() {
        return this == REJECTED;
    }
}
