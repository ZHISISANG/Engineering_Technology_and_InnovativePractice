package com.reimburse.model;

/** 制度状态。员工能查到的只有 ACTIVE，且还要落在有效期内。 */
public enum PolicyStatus {
    DRAFT("草稿"),
    ACTIVE("生效"),
    REPEALED("已废止");

    private final String label;

    PolicyStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
