package com.reimburse.model;

import java.time.LocalDateTime;

/** 审计记录。一次查询、一次维护、一次被拒绝的越权尝试都是一条记录。 */
public class AuditLog {
    private long id;
    private LocalDateTime atTime;
    private String actor;
    private String actorRole;
    private AuditAction action;
    private String target;
    private AuditResult result = AuditResult.ALLOW;
    private String detail;
    private String ip;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public LocalDateTime getAtTime() { return atTime; }
    public void setAtTime(LocalDateTime atTime) { this.atTime = atTime; }

    public String getActor() { return actor; }
    public void setActor(String actor) { this.actor = actor; }

    public String getActorRole() { return actorRole; }
    public void setActorRole(String actorRole) { this.actorRole = actorRole; }

    public AuditAction getAction() { return action; }
    public void setAction(AuditAction action) { this.action = action; }

    public String getTarget() { return target; }
    public void setTarget(String target) { this.target = target; }

    public AuditResult getResult() { return result; }
    public void setResult(AuditResult result) { this.result = result; }

    public String getDetail() { return detail; }
    public void setDetail(String detail) { this.detail = detail; }

    public String getIp() { return ip; }
    public void setIp(String ip) { this.ip = ip; }

    public String getActionLabel() {
        return action == null ? "" : action.getLabel();
    }

    public String getResultLabel() {
        return result == null ? "" : result.getLabel();
    }
}
