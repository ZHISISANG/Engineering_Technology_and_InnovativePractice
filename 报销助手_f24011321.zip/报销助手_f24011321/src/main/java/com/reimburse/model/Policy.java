package com.reimburse.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 制度。同一 code 可以有多个版本：修订时旧版本置 REPEALED，新版本从 DRAFT 走发布流程。
 * "有效" = status == ACTIVE 且今天落在 [effectiveFrom, effectiveTo] 区间内（effectiveTo 为空表示长期有效）。
 */
public class Policy {
    private long id;
    private String code;
    private String title;
    private String category;
    private String appliesTo;
    private String content;
    private int version = 1;
    private PolicyStatus status = PolicyStatus.DRAFT;
    private LocalDate effectiveFrom;
    private LocalDate effectiveTo;
    private String issuer;
    private String updatedBy;
    private LocalDateTime updatedAt;
    private Long prevVersionId;
    private String changeNote;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getAppliesTo() { return appliesTo; }
    public void setAppliesTo(String appliesTo) { this.appliesTo = appliesTo; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public PolicyStatus getStatus() { return status; }
    public void setStatus(PolicyStatus status) { this.status = status; }

    public LocalDate getEffectiveFrom() { return effectiveFrom; }
    public void setEffectiveFrom(LocalDate effectiveFrom) { this.effectiveFrom = effectiveFrom; }

    public LocalDate getEffectiveTo() { return effectiveTo; }
    public void setEffectiveTo(LocalDate effectiveTo) { this.effectiveTo = effectiveTo; }

    public String getIssuer() { return issuer; }
    public void setIssuer(String issuer) { this.issuer = issuer; }

    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Long getPrevVersionId() { return prevVersionId; }
    public void setPrevVersionId(Long prevVersionId) { this.prevVersionId = prevVersionId; }

    public String getChangeNote() { return changeNote; }
    public void setChangeNote(String changeNote) { this.changeNote = changeNote; }

    /** 有效期是否覆盖指定日期。生效日已到、失效日未过（或未设置）即为覆盖。 */
    public boolean covers(LocalDate day) {
        if (day == null || effectiveFrom == null) {
            return false;
        }
        if (day.isBefore(effectiveFrom)) {
            return false;
        }
        return effectiveTo == null || !day.isAfter(effectiveTo);
    }

    /** 展示用的版本号，例如 V2 */
    public String getVersionLabel() {
        return "V" + version;
    }

    /** 展示用的有效期文本 */
    public String getEffectiveLabel() {
        String from = effectiveFrom == null ? "未定" : effectiveFrom.toString();
        String to = effectiveTo == null ? "长期有效" : effectiveTo.toString();
        return from + " 至 " + to;
    }
}
