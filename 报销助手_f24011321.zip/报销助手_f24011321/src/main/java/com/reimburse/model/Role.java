package com.reimburse.model;

/** 系统角色。员工只有查询权，制度与业务事实分别由专员、业务员维护。 */
public enum Role {
    EMPLOYEE("员工"),
    SPECIALIST("制度专员"),
    CLERK("业务员"),
    ADMIN("系统管理员");

    private final String label;

    Role(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** 制度域维护权（新增、修订、发布、废止） */
    public boolean canMaintainPolicy() {
        return this == SPECIALIST;
    }

    /** 业务事实维护权（登记单据、推进状态） */
    public boolean canMaintainDocument() {
        return this == CLERK;
    }

    /** 账号与审计管理权 */
    public boolean canAdminister() {
        return this == ADMIN;
    }
}
