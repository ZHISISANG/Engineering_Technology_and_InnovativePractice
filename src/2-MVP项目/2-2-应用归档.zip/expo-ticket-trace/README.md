# expo-ticket-trace

**展商咨询工单的版本可追溯只读试点工具**：只读、只出草稿、可审计。

它回答一个具体问题：*这条咨询当时依据的是哪一版规则、由谁确认、哪些还没确认、能不能对外？*

> 项目源自《展商咨询知识与服务转派》需求发现材料（访谈 36/36 覆盖、6 个角色、6 条待验证需求）。
> 材料里的企业与人物均为演练设定，`900 次咨询 / 55% 重复` 是虚构基线，**不是真实经营数据**。

---

## 如何打开应用

应用分两个入口，**按账号角色隔离**：咨询员只能进咨询员界面，审核方/管理员只能进后台。

| 角色（账号） | 入口 | 登录后落地 | 页面内容 | 被拒绝 |
| --- | --- | --- | --- | --- |
| 咨询员（agent） | `/login` | `/chat` | 会话侧栏、新建会话、问答与引用、`/drafts` 我的草稿 | 访问 `/admin` → 403 |
| 审核方 / 管理员（reviewer / admin） | `/admin/login` | `/admin` | 概览、知识库、提示词、对话审计、设置、审计链 | 访问 `/chat`、`/drafts` → 303 回 `/admin` |

- 两个入口互相链接；账号走错入口会提示「请使用咨询员入口」/「请使用后台入口」。
- 右上角「退出」（`POST /logout`）清除会话并回到 `/login`。
- 咨询员界面不显示后台导航；`/drafts` 只读展示本人草稿（带「未确认 · 不可对外」，系统没有发送通道）。

工具有两种用法：**Web 服务**（问答与后台，阶段 2）和**命令行流水线**（阶段 1，零依赖）。只想看效果，用 Web；只想验证判定与审计，用命令行。

### Web 服务（推荐先看这个）

需要 Python 3.11+，并额外安装 Web 依赖（约 3 个包）：

```bash
python -m pip install -e ".[web]"

expo-trace web --port 8000
# 等价写法：PYTHONPATH=src python -m expo_trace web --port 8000
```

启动后终端打印 `Web 服务：http://127.0.0.1:8000/chat`，浏览器打开：

| 地址 | 用途 |
| --- | --- |
| http://127.0.0.1:8000/chat | 咨询问答：带版本引用的回答、拒答与转人工 |
| http://127.0.0.1:8000/admin | 管理后台：概览、对话审计、知识库、提示词、审计链 |
| http://127.0.0.1:8000/healthz | 探活（返回 `{"status":"ok"}`） |
| http://127.0.0.1:8000/api/v1/health | 运行状态：数据目录、是否暂停、供应商 |

登录账号 `admin`（审核方）/ `reviewer`（审核方）/ `agent`（咨询员），**初始密码 `demo-1234`**（可用环境变量 `EXPO_SEED_PASSWORD` 覆盖）。登录页也会显示该密码，便于本地试用；正式部署请改掉。

停止服务：终端 `Ctrl+C`。常用参数：`--port`（默认 8000）、`--db runs/web/app.db`、`--run-dir runs/final`、`--reload`（开发热重载）。

### 命令行流水线（零第三方依赖）

```bash
PYTHONPATH=src python -m expo_trace run --export data/demo/export --run-dir runs/demo
PYTHONPATH=src python -m expo_trace status --run-dir runs/demo
```

### 起不来时

| 现象 | 处理 |
| --- | --- |
| `未安装 Web 依赖。请执行：pip install -e ".[web]"`（退出码 2） | 先装 Web 依赖，或用上面的命令行方式 |
| `错误：运行目录缺少 output/tickets.jsonl`（退出码 2） | `--run-dir` 指错了：先跑一次 `run` 生成产物，或去掉 `--run-dir` 用默认目录 |
| `端口被占用` | 换端口，如 `--port 8010` |
| 打开 `/chat` 跳到登录页 | 正常：未登录会跳到 `/login`（审核方与管理员用 `/admin/login`） |

---

## 为什么需要它

现场的三处断点不是“回复慢”，而是**对不上**：

| 断点 | 现场表现 | 后果 |
| --- | --- | --- |
| 时间对不上 | 先用群消息答复，事后补填表格 | 台账时间 ≠ 业务发生时间（f13） |
| 版本对不上 | 问答引用旧通知、旧展位说明 | 时间/费用口径不一致（f10 / f11） |
| 编号对不上 | 服务台、业务台账、文件库各记一段 | 工单无法关联，版本断链（f30） |

文件名里的“最新版”“最终版”不能作为判断依据。这个工具把判定改成**有效期覆盖 + 确认状态 + 作废状态 + 替代链**，并把每一次判断的依据留在运行目录里。

---

## 它做什么 / 不做什么

| 做 | 不做 |
| --- | --- |
| 读取**单批次**脱敏只读导出，保留原始行 | 不写回任何源系统，不提供写接口 |
| 标注“当前 / 过期 / 未确认”，列出判定依据与已排除版本 | 不回答展商问题，不生成对外承诺 |
| 组装带来源、行号、版本的回复**草稿**，固定“未确认 · 不可对外” | 不自动发布、不发外部消息 |
| 把无法确认的工单连同原因、责任人、时限放进人工队列 | 不默认通过、不猜版本、不悄悄重试 |
| 记录确认项与审计哈希链，输出三项并列指标 | 不判断业务对错，不替代审批 |
| 读取失败时用上次快照续跑，并标注快照时间 | 不编造缺失数据 |

收费、报价、退款、参展资格属于**不可逆边界**：草稿会被标记为禁止直接对外，必须由业务负责人与审核方确认。

---

## 交件对照表

文件按课程清单的编号与标题命名；`docs/` 放分析类文档，`src/` 放代码与归档，`test/` 放测试交付。

| 编号 | 要求 | 交付物 |
| --- | --- | --- |
| docs 1 | 六人访谈记录 md / json / csv | [1-六人访谈记录.md](docs/1-六人访谈记录.md) · [.json](docs/1-六人访谈记录.json) · [.csv](docs/1-六人访谈记录.csv) |
| docs 2 | 项目基本简报（4 个文件） | [2-1-客户简报](docs/2-项目基本简报/2-1-客户简报.md) · [2-2-现状信息请求表](docs/2-项目基本简报/2-2-现状信息请求表.md) · [2-3-业务发现访谈问题库](docs/2-项目基本简报/2-3-业务发现访谈问题库.md) · [2-4-利益相关者资料与分工](docs/2-项目基本简报/2-4-利益相关者资料与分工.md) |
| docs 3 | 典型事件（可直接下载 txt + 整理 docx） | [3-典型事件采访记录.txt](docs/3-典型事件采访记录.txt) · [3-典型事件整理.docx](docs/3-典型事件整理.docx) |
| docs 4 | 行业分析 md + docx | [4-行业分析.md](docs/4-行业分析.md) · [4-行业分析.docx](docs/4-行业分析.docx) |
| docs 5 | 两份流程图（改造前 / 改造后） | [5-流程图-改造前.png](docs/5-流程图-改造前.png) · [5-流程图-改造后.png](docs/5-流程图-改造后.png) |
| docs 6 | 需求定义文档（痛点 / AI 改造 / 优先级 / 边界 / 规格 / 追溯矩阵 / 验收） | [6-需求分析方案.md](docs/6-需求分析方案.md) · [6-需求分析方案.docx](docs/6-需求分析方案.docx) |
| docs 7 | 详细项目设计方案 | [7-详细项目设计方案.docx](docs/7-详细项目设计方案.docx) · 另见 [05-设计方案.docx](docs/solution-v1/05-设计方案.docx)、[架构选型方案.docx](docs/architecture-v2/01-架构选型方案.docx) |
| docs 8 | 报价（低 / 中 / 高 + 投入产出） | [8-报价方案.md](docs/8-报价方案.md) · [8-报价方案.docx](docs/8-报价方案.docx) · [报价单.xlsx](docs/solution-v1/04-报价单.xlsx) |
| docs 9 | 上线交付运行手册 | [9-运行手册.docx](docs/9-运行手册.docx) |
| src 1 | 问答助手归档 | [src/1-问答助手归档/](src/1-问答助手归档)：README + 可下载 zip |
| src 2 | MVP：工程架构 / Agent 框架 / 知识库 / ≥3 处人工确认 | [src/2-MVP项目/](src/2-MVP项目)：说明 + [2-1-人工确认点](src/2-MVP项目/2-1-人工确认点.md)；代码在 [src/expo_trace/](src/expo_trace) |
| test 1 | 测试方案 md + docx | [1-测试方案.md](test/1-测试方案.md) · [1-测试方案.docx](test/1-测试方案.docx) |
| test 2 | 五份场景过程 docx | [2-1-正常](test/2-1-正常场景测试.docx) · [2-2-边界](test/2-2-边界场景测试.docx) · [2-3-对抗](test/2-3-对抗场景测试.docx) · [2-4-权限](test/2-4-权限场景测试.docx) · [2-5-故障](test/2-5-故障场景测试.docx) |
| test 3 | MVP 上线部署地址 | [3-MVP部署地址.md](test/3-MVP部署地址.md) · [3-部署说明.docx](test/3-部署说明.docx) |
| 附加 | 项目说明文件（三格式合并版） | [说明文件.md](docs/说明文件.md) · [.json](docs/说明文件.json) · [.csv](docs/说明文件.csv) |

---

## 命令行快速跑通

要求 Python **3.11+**，运行时**零第三方依赖**。

```bash
git clone <your-repo-url> expo-ticket-trace
cd expo-ticket-trace

# 方式一：免安装（推荐先试）
PYTHONPATH=src python -m expo_trace run

# 方式二：安装命令行入口（需要本机有 setuptools；无网络也可用方式一）
pip install -e .
expo-trace run
```

Windows PowerShell：

```powershell
$env:PYTHONPATH="src"; python -m expo_trace run --run-dir runs/demo --now "2026-10-20 10:00"
```

真实输出（演示数据，固定运行时间）：

```text
运行目录：runs/demo
输入：5 个文件（sha256 已记录）
降级：否
工单：16  可出草稿：5  人工队列：9  阻塞：2
问题：14（error 12 / warn 2）
指标：工时 452 分钟 · 返工 0 次 · 确认完整率 0.0%
验收（工具侧）：工具侧覆盖 6/6；业务验收未执行（80 条抽查为人工动作）
产物：runs/demo/output/report.md
```

打开 `runs/demo/output/report.md` 看周报，`runs/demo/output/checklist.md` 看一线缺项清单，
`runs/demo/output/queue.csv` 看转派队列，`runs/demo/output/drafts/` 看每张草稿。

> 16 张工单里有 12 个**故意埋的坑**（重复编号、空时间、版本冲突、替代链断、跨批次授权、回填时间、单位混用、文件名陷阱等），
> 用于验证“失败封闭”。说明见 [`data/demo/README.md`](data/demo/README.md)。

---

## 六个需求怎么落到代码里

| 需求 | 实现 | 测试 |
| --- | --- | --- |
| **REQ-1** 有效期 + 确认状态替代文件名 | `core/versioning.py` 排序键只含 confirmed / void / effective_from / confirmed_at / received_at / version_id；不读文件名与 mtime | `test_versioning.py`（含“最新版”陷阱） |
| **REQ-2** 交接点统一编号与责任清单 | 别名映射 + `raw` 原行保留；重复编号、空时间、链断、单位差异逐条入 `issues` | `test_ingest.py`、`test_validation.py` |
| **REQ-3** 双时间戳 + 快照兜底 | `Ticket.occurred` / `received` 四态；回填超阈值单独标记；读取失败加载上次快照并标注时间 | `test_timeutil.py`、`test_ingest.py` |
| **REQ-4** 兜底触发进队列，不默认通过 | `core/routing.py` 断言每条工单都有分派；阻塞问题全部进队列 | `test_routing.py`、`test_validation.py` |
| **REQ-5** 工时 / 返工 / 确认完整率并列 | `core/metrics.py` 三项同时输出并写公式；报告不提供单一效率结论 | `test_metrics.py` |
| **REQ-6** 只出草稿、不自动发布收费或资格决定 | `core/drafting.py` 固定水印 + 收费/资格阻塞；`publish()` 恒抛 `BlockedAction`；配置校验拒绝开启写回 | `test_drafting.py`、`test_review.py`、`test_config.py` |

逐条追溯（原文、证据编号、残余风险）见 [`docs/requirements-traceability.md`](docs/requirements-traceability.md)。

---

## 流程图

- [`docs/flowchart.md`](docs/flowchart.md)：5 张 Mermaid 图（GitHub 直接渲染）
  1. 现状链路与三处断点
  2. 目标流水线：只读、只出草稿、失败进队列
  3. 版本判定决策树
  4. 工单状态机
  5. 数据流与审计链
- [`docs/flowchart.html`](docs/flowchart.html)：同一内容的离线可视化版本，无外部依赖，可直接打印。

```mermaid
flowchart LR
    A["脱敏只读导出"] --> B["字段映射<br/>保留原行"]
    B --> C["数据核对<br/>重复 / 空时间 / 单位 / 链"]
    C --> D{"版本判定<br/>有效期 + 确认状态"}
    D -->|"可定位"| E["草稿<br/>未确认 · 不可对外"]
    D -->|"不可定位"| F["人工队列<br/>原因 · 责任人 · 时限"]
    E --> G{"收费 / 资格"}
    G -->|"是"| H["禁止对外<br/>业务负责人 + 审核方"]
    G -->|"否"| I["审核人确认 / 退回"]
    F --> I
    H --> I
    I --> J["周报<br/>工时 · 返工 · 完整率"]
```
---

## 设计方案（v1）

[`docs/solution-v1/`](docs/solution-v1/README.md) 是面向业务与采购的一套完整交付：业务挖掘报告、行业分析、两张流程图（现状 / 数智化转型后）、总体架构图、报价单与设计方案。文档中的案例、人物和数字均为合成样本，行业统计仅引用可核查的公开来源。

| 文件 | 内容 |
| --- | --- |
| [01-业务挖掘报告.docx](docs/solution-v1/01-业务挖掘报告.docx) | 36 条访谈事实、六角色权责、八环节断点、六条需求假设与证据缺口 |
| [02-行业分析.docx](docs/solution-v1/02-行业分析.docx) | 会展行业边界、数字化成熟度、技术趋势、合规约束与对本方案的启示 |
| [03-流程图说明.docx](docs/solution-v1/03-流程图说明.docx) | 现状流程图、数智化转型后流程图、总体架构图与逐图说明 |
| [04-报价单.xlsx](docs/solution-v1/04-报价单.xlsx) | 7 项交付、26 个工作日的工作分解、税率与付款节奏、假设与不含项 |
| [05-设计方案.docx](docs/solution-v1/05-设计方案.docx) | 目标、架构、数据与功能设计、安全、实施计划、验收与风险 |
| [03-图表/](docs/solution-v1/03-图表) | 三张 1700px 宽的 PNG 原图，可直接插入汇报材料 |

### 项目说明文件（三种格式）

[`docs/`](docs) 用**同一份内容**保存三种格式：客户简报、现状信息请求表、业务发现访谈问题库、
利益相关者资料与分工，以及六位受访者的 31 组访谈问答。

| 文件 | 格式 | 内容 |
| --- | --- | --- |
| [说明文件.md](docs/说明文件.md) | Markdown | 完整文档：四部分简报 + 六人访谈记录，可评审可打印 |
| [说明文件.json](docs/说明文件.json) | JSON | 同一内容的唯一数据源（`项目基本简报` / `六人访谈记录` 两大块） |
| [说明文件.csv](docs/说明文件.csv) | CSV | 长表（505 行）：一行一个字段值，按「模块 / 分类 / 编号」筛选统计 |

配套交付（课程要求的分件）：

| 文件 | 内容 |
| --- | --- |
| [项目基本简报/](docs/2-项目基本简报) | 4 份：客户简报、现状信息请求表、业务发现访谈问题库、利益相关者资料与分工 |
| [典型事件采访记录.txt](docs/3-典型事件采访记录.txt) | 林亦舟 3 轮采访原话，量化到分钟与家数，可直接下载 |
| [典型事件整理.docx](docs/3-典型事件整理.docx) | 把上述记录整理成结构化文档：时间线 / 根因 / 量化 / 改造后对照 / 代码落点 |
| [流程图-改造前.png](docs/5-流程图-改造前.png) | 现状流程图，融入典型事件 T-2026-0417（旧说明 15:10 已失效仍被引用） |
| [流程图-改造后.png](docs/5-流程图-改造后.png) | 同一事件的改造后流程：版本判定拦截、统一编号主动更正、19 分钟闭环 |

---

## 测试与部署

测试按五类场景组织（正常 / 边界 / 对抗 / 权限 / 故障），共 33 条用例，全部通过；另有 142 项自动化用例兜底。

| 文件 | 内容 |
| --- | --- |
| [测试方案.md](test/1-测试方案.md) / [测试方案.docx](test/1-测试方案.docx) | 目标、阈值、方法、场景矩阵、缺陷记录、风险与证据索引 |
| [正常场景测试.docx](test/2-1-正常场景测试.docx) | 6 例：登录→会话→问答→引用→落库，58.9 ms |
| [边界场景测试.docx](test/2-2-边界场景测试.docx) | 6 例：收费/资格类提问全部拦截，E_BOUNDARY_BLOCKED |
| [对抗场景测试.docx](test/2-3-对抗场景测试.docx) | 5 例：提示词注入、诱导编造、超长、空输入，0 编造 |
| [权限场景测试.docx](test/2-4-权限场景测试.docx) | 5 例：咨询员越权 403、审核方 200、写操作 CSRF |
| [故障场景测试.docx](test/2-5-故障场景测试.docx) | 5 例：暂停试点、坏运行目录、审计篡改、恢复 |
| [MVP部署地址.md](test/3-MVP部署地址.md) / [部署说明.docx](test/3-部署说明.docx) | 访问地址、启动步骤、上线自检、公网方案 |

每份场景文档都含一张执行过程图（`test/2-图/`）与量化结果表，满足“有图有过程”。

---

## 架构方案（v2）：展商咨询工单助手

[`docs/architecture-v2/`](docs/architecture-v2/README.md) 是同一项目的架构选型文档，主题是**展商咨询工单助手**（FastAPI 异步后端、LLM 经 API 接入且可替换、展会通知与规则文档向量化检索、咨询员/审核方两角色）。它是 v1 方案的上位技术与选型说明，与本仓库的核心 CLI 没有代码依赖。

| 文件 | 内容 |
| --- | --- |
| [01-架构选型方案.docx](docs/architecture-v2/01-架构选型方案.docx) | 四层架构、目录 tree、5 张核心表 + 5 张支撑表、第一周 MVP、选型对比与风险 |
| [02-图表/四层架构图.png](docs/architecture-v2/02-图表/四层架构图.png) | 1700×1320 PNG：入口层 / 服务层 / 智能体编排层 / 数据模型层 + 请求路径与两条红线 |

核心取舍：**判定与生成分离**（版本与适用性用 SQL/规则判定）、**先过滤再相似**（`status=active` + 生效区间先过滤，再向量召回）、**工具即权限边界**（注册表里没有对外发送的工具，只到回复草稿为止）、**回答可回放**（引用、提示词版本、模型与用量随消息落库）。

---

## 裸问答原型（v3）

[`src/rag_qa.py`](src/rag_qa.py) 是阶段 1 的单文件实现（实现位于 `src/expo_trace/rag_qa.py`，根下同名文件只是命令行入口）：读 `data/policy/展商咨询规则.md` → 结构感知切片（500 字 / 80 重叠）→ 向量化 → FAISS（可选）或 numpy 索引 → BM25 + 向量混合检索 top3 → 拼提示词 → 调用可配置的 LLM，回答带 `[编号]` 引用，没有依据时直接拒答。

```bash
python -m pip install numpy
python src/rag_qa.py --selftest                  # 29 项离线自检
python src/rag_qa.py -q "展商住宿代订标准是多少？"    # mock 模式，只看链路
python src/rag_qa.py -q "发票丢了怎么办？" --provider deepseek
```

`call_llm()` 走 OpenAI 兼容协议，`openai / deepseek / ollama / mock` 四选一；切片、嵌入、混合检索、提示词与拒答判据都标了 `[核心·阶段2复用]`，可直接搬进 FastAPI 服务。详细说明见 [docs/rag-prototype.md](docs/rag-prototype.md)。

---

## 阶段 2 设计（待确认）

三份提示词（员工聊天入口、管理后台、Agent 工具）来自外部模板；[`docs/phase2/`](docs/phase2/README.md) 已把对象逐项替换为**展商咨询工单**，与本项目的需求发现材料一致：

| 文档 | 内容 | 关键决定 |
| --- | --- | --- |
| [chat-api.md](docs/phase2/chat-api.md) | `POST /chat` SSE、SQLite 会话表、最近 6 轮、前端状态机 | 先定版本再检索；无引用不回答；收费/资格直接转人工 |
| [admin-console.md](docs/phase2/admin-console.md) | 7 个页面、接口清单、JWT 角色矩阵、知识库与模板版本 | 职责分离：能改模板的不能暂停，能暂停的不能改模板 |
| [agent-tools.md](docs/phase2/agent-tools.md) | 10 个 Function Calling 工具、调用顺序、`context_token` | 写操作必须有一次性 token；工具层拒绝跳步，不靠提示词自觉 |

阶段 1 说"不做向量检索"、阶段 2 又做，顺序是反的：**版本判定是闸门，检索只在已确认版本的文本内取条款**，不参与版本效力判断。

---

## 命令行

| 命令 | 用途 |
| --- | --- |
| `expo-trace run` | 跑完整流水线，生成周报、队列、草稿、审计记录 |
| `expo-trace status` | 查看运行状态与人工确认进度 |
| `expo-trace review --ticket T-1001 --reviewer 傅景 --decision confirm --item ...` | 提交人工确认/退回 |
| `expo-trace feedback --ticket T-1005 --kind 误报 --reporter 傅景 --note ...` | 登记误报/漏报/未确认，进入周报与审计 |
| `expo-trace pause / resume --actor 傅景` | 审核方暂停 / 恢复试点 |
| `expo-trace report` | 基于运行目录重跑并更新周报（不改输入） |
| `expo-trace audit verify` | 校验审计哈希链，定位断点 |
| `expo-trace audit show --ticket T-1001` | 查看谁查过、用哪版、谁确认 |
| `expo-trace sample --size 80` | 生成确定性抽查计划 |
| `expo-trace web --port 8000` | 启动阶段 2 Web 服务（需 `pip install -e ".[web]"`） |

退出码：`0` 成功 · `2` 输入/配置错误 · `3` 试点已暂停 · `4` 确认被拒绝 · `5` 已阻止的越界动作。
完整参数与产物 schema 见 [`docs/api.md`](docs/api.md)。

---

## 仓库结构

```text
expo-ticket-trace/
├── README.md                     # 本文件
├── LICENSE                       # MIT（纯许可证文本，便于 GitHub 识别）
├── NOTICE                        # 数据为合成样本的声明
├── .gitignore
├── CHANGELOG.md
├── CONTRIBUTING.md
├── SECURITY.md                   # 安全模型、已知风险、事件处置
├── requirements.txt              # 运行时零依赖；开发工具可选
├── pyproject.toml                # 打包与 expo-trace 入口
├── src/
│   ├── expo_trace/               # 展商工单工具（包）
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── main.py               # CLI 入口
│   │   ├── core/                 # ingest / versioning / validation /
│   │   │                         # routing / drafting / review /
│   │   │                         # metrics / acceptance / report / audit
│   │   └── utils/                # YAML 子集、时间四态、脱敏、哈希
│   ├── rag_qa.py                 # 制度裸问答原型（切片/混合检索/LLM 调用）
│   └── web/                      # 阶段 2：聊天界面与管理后台（可选依赖）
├── docs/
│   ├── design.md                 # 设计思路与取舍
│   ├── api.md                    # CLI / Python API / 产物 schema
│   ├── flowchart.md              # 5 张 Mermaid 流程图
│   ├── flowchart.html            # 离线可视化版本
│   ├── pilot-runbook.md          # 四周试点手册（2 人 / 每周 ≤4h）
│   ├── requirements-traceability.md
│   ├── rag-prototype.md          # v3 原型说明（原 v3-裸问答原型/README.md）
│   ├── phase2/                   # 阶段 2 设计：聊天接口 / 管理后台 / Agent 工具
│   ├── 2-项目基本简报/            # 客户简报 / 信息请求 / 问题库 / 分工（编号 1-6 的文档同名编号）
│   ├── solution-v1/              # v1 交付：业务挖掘 / 行业分析 / 流程图 / 报价单 / 方案
│   └── architecture-v2/          # v2 交付：展商咨询工单助手四层架构选型
├── tests/                        # 142 项 unittest（25 项 Web 测试缺依赖时跳过）
├── examples/demo.py              # 跑得起来的分步演示
├── scripts/                      # build.sh / deploy.sh / verify.sh
├── config/default.yaml           # 非机密默认配置
├── data/
│   ├── demo/export/              # 12 个坑的合成样本
│   └── policy/展商咨询规则.md      # v3 原型的合成规则原文
└── .github/                      # CI、Issue 模板、PR 模板
```

> 目录对应需求方给的模板（`my-tool/` → `expo-ticket-trace/`、`my_tool/` → `expo_trace/`），
> 并补充了 `pyproject.toml` 与追溯/手册文档。

### 交付物放在哪（整合说明）

三批文档与代码没有覆盖 `src/expo_trace/` 的任何核心文件，只按“代码进 `src/`、脚本/示例进 `examples/`、文档进 `docs/`、样例数据进 `data/`”归位：

| 原位置 | 现位置 | 说明 |
| --- | --- | --- |
| `v1设计方案/` | `docs/solution-v1/` | 5 份 Word/Excel + 3 张 PNG，内部相对链接已随之生效 |
| `v2-展商咨询工单助手架构方案/` | `docs/architecture-v2/` | 架构选型 docx + 架构图 |
| `v3-裸问答原型/rag_qa.py` | `src/rag_qa.py` | 单文件原型，默认路径改为仓库根下的 `data/policy/` 与 `.rag-index/` |
| `v3-裸问答原型/data/展商咨询规则.md` | `data/policy/展商咨询规则.md` | 合成规则原文 |
| `v3-裸问答原型/README.md` | `docs/rag-prototype.md` | 命令示例改为从仓库根运行 |

被更新的既有文件只有 3 个：`README.md`（本章节与结构树）、`CHANGELOG.md`（路径与整合记录）、`.gitignore`（索引目录）。
>

---

## 配置

`config/default.yaml` 是非机密默认配置，关键项：

| 键 | 含义 |
| --- | --- |
| `pilot.batch` | 只处理这一个批次（默认 `2026-S1`） |
| `safety.read_only` / `draft_only` | 必须为 `true`，否则拒绝启动 |
| `safety.auto_publish` / `write_back` / `external_message` | 必须为 `false` |
| `safety.watermark` | 草稿固定标识“未确认 · 不可对外” |
| `quality.backfill_hours` | 回填时间差阈值（默认 8 小时） |
| `quality.sample_size` | 抽查量（默认 80，正式是否沿用需审批） |
| `routing.sla_hours` / `owners` | 队列时限与责任人映射 |
| `review.reviewers` / `pause_roles` | 可确认人员 / 可暂停试点的审核方 |

配置里**没有**“允许自动发布”的开关；即使手工改成 `true`，`Config.validate()` 也会拒绝启动。

---

## 试点与验收

- 预算：**4 周、2 名业务骨干、每周 ≤4 小时**；超出即重新评估（f03）。
- 工具侧验收：`expo-trace run --strict`，6 条需求的工具侧检查全过才返回 0。
- 业务侧验收：**未执行**。80 条问答抽查、旧版本占比、检索耗时、快照保留期、例外认定权仍需真实试点核实。
- 每周复盘三项指标 + 误报/漏报/未确认项；周报不得只报工时（f51 / f55）。误报/漏报用 `expo-trace feedback` 登记，进入周报与审计链。
- 审核方保留随时暂停权（f04）。

操作步骤见 [`docs/pilot-runbook.md`](docs/pilot-runbook.md)。

---

## 开发

```bash
python -m unittest discover -s tests -t .    # 142 项；未装 Web 依赖时 25 项跳过
python -m compileall -q src
python examples/demo.py                       # 分步演示（含确认、暂停、快照兜底）
```

- 代码风格：`ruff`（line-length 100），中文 docstring；
- 提交前请确认没有新增“写回 / 自动发布 / 外部消息”代码路径；
- 判定规则改动必须同时补测试与 `CHANGELOG.md`。

贡献方式见 [`CONTRIBUTING.md`](CONTRIBUTING.md)。

---

## 数据与合规

- `data/` 下全部为**合成样本**，不对应任何真实展会、企业或个人信息；手机号、邮箱、证件号在进入运行目录前已掩码。
- 工具只读取脱敏只读导出；不连接生产库、不调用外部模型、不发送任何网络请求。
- 若用于真实数据，请先确认授权范围、保存期限与审计取证要求（f32 / f43 / f45）。

## 许可证

[MIT](LICENSE)。`data/` 为合成样本，随仓库一并按 MIT 提供。
